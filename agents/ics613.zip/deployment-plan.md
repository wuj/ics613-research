# Production VPS Deployment Plan: Local Produce Exchange

## Execution status (2026-06-07)

The site is live at https://localharvest.exchange. Phases 1 and 2 are
done exactly as written below. Phases 3-5 are covered by a temporary
local workaround while repo admin is pending: the deploy key from Phase
3 step 1 is installed and working, but instead of GitHub Actions, the
script `C:\Users\jeffr\MCS\ics613\deploy\deploy-local.sh` performs the
same build, copy, and remote-script steps from this machine (docs:
`C:\Users\jeffr\MCS\ics613\deploy\README.md`). The remote script it
installs is identical to Appendix A4, and the VPS layout is exactly
what this plan specifies, so the switch from the workaround to Actions
(Phases 3-5 below, rewritten as a cutover) only needs the repo secrets
and the Phase 4 PR; nothing on the VPS changes. Verified working: first and second deploys end to end,
migration cd9306b0de55 applied, seed, health and database smoke tests
over the public URL, TLS for apex and www, SPA fallback, http
redirect, reboot survival, and crash self-healing of both the backend
process and the database container.

## Context

The ICS 613 final project (FastAPI backend + React/Vite frontend + PostgreSQL 18.4) works in dev but has no production environment. The goal is a basic, simple production server on the existing dedicated VPS ("vps2": Vultr, 45.77.209.138, Debian 13.5, 961MB RAM + 3GB swap, 23GB free disk, currently bare). After this plan executes, every merge to main that passes lint, build, and tests auto-deploys over SSH via GitHub Actions (including applying any new database migrations), and the app is served over HTTPS with a purchased SSL certificate, working exactly as it does in dev.

Decisions confirmed with the user:
- Target: vps2; Claude has SSH + passwordless sudo and standing permission to install anything (dedicated box).
- VPS access details: `ssh vps2` works from this machine because of an alias in `C:\Users\jeffr\.ssh\config` that maps vps2 to host 45.77.209.138, user `jeff`, with the user's private key at `C:\Users\jeffr\ssh\id_rsa` (note the folder is `ssh`, not `.ssh`). All VPS commands in this plan run through that alias. This personal key is separate from the GitHub Actions deploy key created in Phase 3.
- PostgreSQL runs via the repo's existing `docker-compose.yml` (postgres:18.4) to match dev.
- Database schema is managed by Alembic, committed 2026-06-06 (`backend/alembic.ini`, `backend/migrations/`). The seed script no longer creates tables; it only inserts demo rows. Every deploy runs `alembic upgrade head` on the VPS before seeding, so merging a PR that contains a new migration applies it automatically. This step is required, not optional: without it, the first deploy's seed would fail on a missing table.
- Frontend builds in GitHub Actions; the VPS never gets Node.
- SSL cert is purchased (not Let's Encrypt). The CSR has been generated and the issued cert files are now available. DNS already points the domain at the VPS.
- GitHub secrets set via `gh` CLI. The user (wuj) currently has push-only on `kennank27/ICS613_Summer2026_FinalProject_Team4` and will obtain admin; secret-setting steps wait on that, everything else proceeds.

Architecture: nginx terminates TLS, serves `frontend/dist` statics (with SPA fallback for React Router), and proxies `/api/` to uvicorn on 127.0.0.1:8000 (systemd service, 1 worker, run as `deploy` user). Postgres container binds 127.0.0.1 only. Same-origin means no CORS changes; frontend already uses relative `/api/*` paths; `backend/app/db.py` already loads `.env` from the app root, so the dev layout is reproduced verbatim on the VPS and no database code changes are needed. Schema changes flow through Alembic: `backend/migrations/env.py` reuses the engine from `db.py`, so migrations read the same `.env` and need no extra configuration on the VPS.

Naming: app dir `/opt/produce-exchange/app`, systemd unit `produce-backend.service`, deploy user `deploy`, domain `localharvest.exchange`.

## Phase 0: Collect from user at execution start

1. DONE: domain is `localharvest.exchange` (cert covers apex + www).
2. Confirmation that repo admin has been granted (needed only for Phase 3 step 2 and merging in Phase 4; can arrive late).

## Phase 1: VPS provisioning (over `ssh vps2`, sudo as jeff)

1. Packages, base first: `sudo apt-get update && sudo apt-get install -y ca-certificates curl gnupg rsync nginx ufw openssl` (openssl is preinstalled on Debian and already used for the CSR, but listing it makes the dependency explicit). Then add Docker's official Debian apt repo and install Docker, exactly:
   ```bash
   sudo install -m 0755 -d /etc/apt/keyrings
   curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
   sudo chmod a+r /etc/apt/keyrings/docker.gpg
   echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian trixie stable" | sudo tee /etc/apt/sources.list.d/docker.list
   sudo apt-get update
   sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
   ```
   (The second `apt-get update` is required: apt only learns about the new repo after it. Without it, `docker-ce` is not found.) Note: on Debian, the apt install starts the Docker daemon automatically. After the install, create `/etc/docker/daemon.json` with log rotation so container logs cannot fill the small disk:
   ```json
   {
     "log-driver": "json-file",
     "log-opts": {
       "max-size": "10m",
       "max-file": "3"
     }
   }
   ```
   Then run `sudo systemctl enable docker` and `sudo systemctl restart docker` (the restart is required: the daemon is already running from the install, so it must reload to pick up the log settings; safe here because no containers exist yet). Confirm with `sudo docker info --format '{{.LoggingDriver}}'` (sudo because jeff is not in the docker group; only `deploy` gets that membership).
2. Create `deploy` user (`useradd --create-home --shell /bin/bash deploy`), add to `docker` group (root-equivalent, acceptable on a dedicated box). Create `/opt/produce-exchange/app` owned by `deploy`, with `chmod o+rx` on the path so nginx (www-data) can traverse to `frontend/dist`.
3. Sudoers drop-in `/etc/sudoers.d/deploy` (mode 0440) allowing exactly these absolute commands as root, NOPASSWD: `/usr/bin/systemctl restart produce-backend.service` and `/usr/bin/systemctl status produce-backend.service`. After the unit exists, test from the `deploy` user with `sudo -n /usr/bin/systemctl status produce-backend.service`; an inactive-service exit code is acceptable, but a password prompt or "not allowed" error is not.
4. As deploy: install uv (`curl -LsSf https://astral.sh/uv/install.sh | sh`), then `uv python install 3.14.2` (Debian 13 ships 3.13; `backend/.python-version` pins 3.14.2 and uv auto-selects it).
5. Firewall: first check Vultr-side (`nft list ruleset` + remind user to check Vultr panel cloud firewall). Before enabling UFW, find the live SSH port with `sudo sshd -T | grep '^port '`, then allow that exact port with `sudo ufw allow <port>/tcp`. Also run `sudo ufw allow 80/tcp` and `sudo ufw allow 443/tcp`, then `sudo ufw --force enable`. Keep the current SSH session open, open a second SSH login, and only close the first session after the second login succeeds. Postgres stays safe regardless: compose publishes on 127.0.0.1 only.
6. Create `/opt/produce-exchange/app/.env` (owner deploy, mode 600): `POSTGRES_USER=produce`, `POSTGRES_PASSWORD=<openssl rand -hex 24>`, `POSTGRES_DB=produce_exchange`, `POSTGRES_PORT=5432`. This is the only place the real password lives; `db.py` resolves `.env` two parents above `backend/app/`, i.e. this app root. Important: the postgres image reads these variables only once, when it initializes an empty data volume. After that first start, the role and password are stored inside the volume, and editing `.env` alone desyncs the backend from the database (auth failures). To rotate the password later (as jeff, who is not in the docker group, so sudo is required): first `sudo docker compose exec db psql -U produce -d produce_exchange -c "ALTER ROLE produce WITH PASSWORD 'newvalue'"`, then update `.env` to match, then restart the backend. Recreating the volume instead (`sudo docker compose down --volumes`) destroys all data and is only acceptable right after a backup.
7. Create `/opt/produce-exchange/app/docker-compose.override.yml` (VPS-only, never committed): adds `restart: unless-stopped` to the `db` service so the container survives reboots. Keeps the repo's compose file untouched for dev machines.
   ```yaml
   services:
     db:
       restart: unless-stopped
   ```
8. systemd unit `/etc/systemd/system/produce-backend.service` (full contents: Appendix A1):
   - `[Unit]`: `Wants=network-online.target docker.service`, `After=network-online.target docker.service`, `ConditionPathExists=/opt/produce-exchange/app/backend/.venv/bin/python`
   - `[Service]`: `User=deploy`, `WorkingDirectory=/opt/produce-exchange/app/backend`
   - `[Service]`: `Environment=LOG_LEVEL=INFO`
   - `[Service]`: `ExecStart=/opt/produce-exchange/app/backend/.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1 --proxy-headers --forwarded-allow-ips 127.0.0.1` (1 worker for 961MB RAM; no `--reload`)
   - `[Service]`: `Restart=always`, `RestartSec=3`
   - `[Install]`: `WantedBy=multi-user.target`
   - `daemon-reload` + `enable` but do NOT start (no code on the box yet; `pool_pre_ping` + lazy connect in db.py means strict db ordering is unneeded).

## Phase 2: SSL - CSR, then cert install

1. DONE: key + CSR generated on the VPS (key never left the server):
   - Private key: `/etc/ssl/private/produce.key` (RSA 2048, root-owned, mode 600).
   - CSR: `/etc/ssl/produce/localharvest.exchange.csr` (CN=localharvest.exchange, SANs localharvest.exchange + www). Submitted to the cert seller by the user.
2. DONE: issued cert files received, stored locally at `C:\Users\jeffr\MCS\ics613\ssl\`:
   - `localharvest_exchange.crt` - the server (leaf) certificate itself. Issuer: Sectigo Public Server Authentication CA DV R36. Valid 2026-06-06 to 2026-12-21. Covers both SANs.
   - `localharvest_exchange.ca-bundle` - the intermediate chain (Sectigo DV R36 intermediate + Sectigo Root R46 cross-signed by USERTrust), which browsers need to link the leaf cert to a trusted root.
   - Verified 2026-06-06: cert public key matches the VPS private key (DER sha256 identical), and the full chain validates OK against Debian's system trust store.
3. Install on the VPS: copy the issued cert files to a temporary location, install them with root-owned permissions, then build `/etc/ssl/produce/fullchain.pem` with the leaf cert first and the bundle second:
   ```powershell
   scp C:\Users\jeffr\MCS\ics613\ssl\localharvest_exchange.crt vps2:/tmp/localharvest_exchange.crt
   scp C:\Users\jeffr\MCS\ics613\ssl\localharvest_exchange.ca-bundle vps2:/tmp/localharvest_exchange.ca-bundle
   ssh vps2 "sudo install -d -m 755 /etc/ssl/produce && sudo install -m 644 /tmp/localharvest_exchange.crt /etc/ssl/produce/localharvest_exchange.crt && sudo install -m 644 /tmp/localharvest_exchange.ca-bundle /etc/ssl/produce/localharvest_exchange.ca-bundle && sudo sh -c 'cat /etc/ssl/produce/localharvest_exchange.crt /etc/ssl/produce/localharvest_exchange.ca-bundle > /etc/ssl/produce/fullchain.pem' && sudo chmod 644 /etc/ssl/produce/fullchain.pem && rm /tmp/localharvest_exchange.crt /tmp/localharvest_exchange.ca-bundle"
   ```
   Then confirm the assembled file parses as three certificates before nginx ever loads it: `ssh vps2 "openssl crl2pkcs7 -nocrl -certfile /etc/ssl/produce/fullchain.pem | openssl pkcs7 -print_certs -noout"` should list the leaf plus the two chain certs with no errors. This catches transfer corruption or a bad concatenation earlier than the live TLS check.
4. nginx site `/etc/nginx/sites-available/produce-exchange` (full contents: Appendix A2; symlink to sites-enabled, remove `default`, `nginx -t`, reload):
   - port 80 server: 301 redirect to https
   - port 443 ssl + http2: `ssl_certificate /etc/ssl/produce/fullchain.pem`, key from /etc/ssl/private; `server_name localharvest.exchange www.localharvest.exchange`
   - `root /opt/produce-exchange/app/frontend/dist`; `location / { try_files $uri $uri/ /index.html; }` (React Router 7 needs SPA fallback)
   - `location = /api { proxy_pass http://127.0.0.1:8000; }` and `location /api/ { proxy_pass http://127.0.0.1:8000; }`, both with Host/X-Real-IP/X-Forwarded-For/X-Forwarded-Proto headers (no trailing URI on proxy_pass so `/api/...` passes through intact, matching the backend's `/api` prefix)
   - gzip for css/js/json/svg; X-Content-Type-Options, X-Frame-Options DENY, Referrer-Policy headers.
   - After `nginx -t` passes and nginx reloads, run the live TLS check (note: openssl runs from Git Bash locally, not PowerShell, or over ssh on the VPS; `</dev/null` stops s_client from sitting open waiting on stdin): `openssl s_client -connect localharvest.exchange:443 -servername localharvest.exchange -verify_hostname localharvest.exchange -verify_return_error -showcerts </dev/null`.

## Phase 3: SSH deploy key + GitHub secrets (needs repo admin)

1. DONE 2026-06-07 (the key exists, the pubkey is deploy's authorized_keys, and the workaround script deploy-local.sh authenticates with it on every deploy; transfer lesson recorded below). Generate locally outside the Git repo, for example: `New-Item -ItemType Directory -Force "$env:USERPROFILE\.ssh"` and `ssh-keygen -t ed25519 -N "" -C "github-actions-deploy" -f "$env:USERPROFILE\.ssh\produce_exchange_github_actions"`. Install the pubkey on the VPS with explicit ownership and modes so sshd's StrictModes check can never reject the login (a group-writable dir or file is what sshd refuses). The pubkey lives on this Windows machine, so transfer it by pipe, exactly:
   ```powershell
   Get-Content "$env:USERPROFILE\.ssh\produce_exchange_github_actions.pub" | ssh vps2 "cat > /tmp/deploy_key.pub"
   ssh vps2 "sudo install -d -m 700 -o deploy -g deploy /home/deploy/.ssh && sudo install -m 600 -o deploy -g deploy /tmp/deploy_key.pub /home/deploy/.ssh/authorized_keys && rm /tmp/deploy_key.pub"
   ```
   (`install` overwrites `authorized_keys`, which is correct here: the deploy account's only credential is this one key. If a second key is ever needed, append instead and re-apply `chown deploy:deploy` + `chmod 600`.) Test before relying on it: `ssh -i "$env:USERPROFILE\.ssh\produce_exchange_github_actions" deploy@45.77.209.138 "echo deploy-login-ok"`. Do not create `deploy_key` inside `ICS613_Summer2026_FinalProject_Team4`; if a key is generated near the repo by mistake, stop and confirm `git -C C:\Users\jeffr\MCS\ics613\ICS613_Summer2026_FinalProject_Team4 status --short` does not show it. Execution lesson from 2026-06-07: the `Get-Content | ssh` pipe above corrupted the file, because PowerShell appends CRLF when piping to native commands and sshd then reads a stray `\r`; the working transfer pipes through Git Bash with `tr -d '\r'`. Any future file transfer to the VPS must go through Git Bash, never a PowerShell pipe.
2. Set 4 repo secrets via gh (PowerShell forms):
   - `DEPLOY_SSH_KEY` = `Get-Content -Raw "$env:USERPROFILE\.ssh\produce_exchange_github_actions" | gh secret set DEPLOY_SSH_KEY --repo kennank27/ICS613_Summer2026_FinalProject_Team4`
   - `DEPLOY_HOST` = `gh secret set DEPLOY_HOST --repo kennank27/ICS613_Summer2026_FinalProject_Team4 --body "45.77.209.138"`
   - `DEPLOY_USER` = `gh secret set DEPLOY_USER --repo kennank27/ICS613_Summer2026_FinalProject_Team4 --body "deploy"`
   - `DEPLOY_KNOWN_HOSTS` = output of `ssh-keyscan -t ed25519 45.77.209.138`, but first compare its fingerprint with the trusted server key from `ssh vps2 "sudo ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub"`. Use `$knownHosts = ssh-keyscan -t ed25519 45.77.209.138` and `$knownHosts | ssh-keygen -lf -` for the local scan fingerprint. After the fingerprints match, set the secret with `gh secret set DEPLOY_KNOWN_HOSTS --repo kennank27/ICS613_Summer2026_FinalProject_Team4 --body "$knownHosts"`. This pins the host key and avoids keyscanning inside the workflow.
3. Do NOT delete the local private key here (the original plan did): deploy-local.sh authenticates with this key, and the workaround must keep working until the first Actions deploy is green. Deletion moved to Phase 5 step 3, the cutover completion.

## Phase 4: Repo changes (branch + PR; all committed content in beginner-friendly, plain-ASCII style per CLAUDE.md)

Before editing, go to the actual Git repo root: `cd C:\Users\jeffr\MCS\ics613\ICS613_Summer2026_FinalProject_Team4`. Every path in this phase is relative to that folder.
1. **Edit `.github/workflows/unit-tests.yml`**: under `on:`, add `workflow_call:` and REMOVE `push: branches: [main]` (deploy.yml runs the same checks on every main push; keeping both would double-run). `pull_request` and `workflow_dispatch` stay. Risk note: if branch protection lists the old check on main pushes, re-verify required-checks config (PR checks unaffected).
2. **New `.github/workflows/deploy.yml`** (full contents: Appendix A3):
   - `on: push: branches: [main]` plus `workflow_dispatch` (manual redeploy)
   - `concurrency: group: deploy-production, cancel-in-progress: false` (never overlap deploys)
   - Job `checks`: `uses: ./.github/workflows/unit-tests.yml` (reusable call - no duplicated steps, no workflow_run complexity)
   - Job `deploy` (needs: checks, ubuntu-latest, timeout 15m): add `if: github.ref == 'refs/heads/main'` so manual dispatch cannot deploy a non-main branch; checkout@v6; setup-node@v6 (node 22, npm cache on frontend/package-lock.json); install rsync explicitly with `sudo apt-get update && sudo apt-get install -y rsync`; `npm --prefix frontend ci && npm --prefix frontend run build` (jobs share no files, so this job builds its own dist); create SSH files with `mkdir -p ~/.ssh`, `chmod 700 ~/.ssh`, write `~/.ssh/id_ed25519`, `chmod 600 ~/.ssh/id_ed25519`, write `~/.ssh/known_hosts`, and `chmod 644 ~/.ssh/known_hosts`; then three ordered steps so the new UI never goes live ahead of a healthy backend: (a) rsync `--relative -az --delete` sending `backend docker-compose.yml scripts` to `/opt/produce-exchange/app/` (the `backend` argument already carries `backend/alembic.ini` and `backend/migrations/`, so migration files reach the VPS with no extra workflow step), excluding `.env`, `docker-compose.override.yml`, `backend/.venv`, `__pycache__`, `.pytest_cache`, `.ruff_cache` (the `backend/.venv` exclude is the load-bearing one, since that folder lives inside the synced `backend/` tree; `.env` and the override file sit outside the synced folders where `--delete` cannot reach, and their excludes are guards against future source-list changes - comment all of this); (b) `ssh deploy@host 'bash /opt/produce-exchange/app/scripts/deploy-remote.sh'` to migrate, restart, and health-check; (c) only after that script succeeds, a second rsync sending `frontend/dist` to the same destination. nginx serves `frontend/dist` straight from disk, so files are live the moment they land; copying the frontend last means a deploy that fails before the backend restart (sync, compose, migrate, seed) leaves the old UI and the still-running old backend together; a failure at or after the restart (the restart itself, the health check, or the smoke test) leaves the old UI up while the backend is stopped or already running the new code, which needs a revert or a forward fix rather than being safe on its own. The planned skew after a good restart (old UI on new backend for a few seconds) is safe while API changes stay additive.
3. **New `scripts/deploy-remote.sh`** (full contents: Appendix A4; committed; reviewable in PRs, testable by hand, keeps quoting out of YAML). Source: copy `C:\Users\jeffr\MCS\ics613\deploy\deploy-remote.sh` into the repo unchanged; it is byte-identical to Appendix A4 and to the copy the workaround already runs on the VPS, so the first Actions deploy overwrites the VPS copy with the same bytes. `set -euo pipefail`, then:
   - `APP_ROOT="/opt/produce-exchange/app"` and `cd "$APP_ROOT"` before any relative path commands
   - preflight: exit 1 with a clear message if `$APP_ROOT/.env` is missing or unreadable, or if any of the four required keys (POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_DB, POSTGRES_PORT) has no value in it. The fallback is per variable - `docker-compose.yml` and `db.py` each default every unset variable separately - so a present-but-incomplete `.env` is as dangerous as a missing one: a first deploy on a box that skipped Phase 1.6 would initialize the database volume with default credentials and report success. Failing loudly before `docker compose up` prevents that.
   - `~/.local/bin/uv sync --locked --no-dev --directory backend` (skips pytest/ruff in prod)
   - `docker compose up -d --wait db` (picks up compose changes; `--wait` uses the pg_isready healthcheck)
   - `cd "$APP_ROOT/backend"` and `.venv/bin/alembic upgrade head` to apply any new migrations. No flags or config beyond the repo files: alembic is a main dependency (so `--no-dev` installs it), `alembic.ini` sits in this folder, and `migrations/env.py` reuses the app engine plus the root `.env`. env.py wraps the whole upgrade in one transaction, and the operations autogenerate writes (create, alter, and drop of tables, columns, indexes, and constraints) are transactional in Postgres, so when one of those fails the database rolls back to the previous revision, `set -e` stops the script, and the old backend keeps running on the old schema. A few Postgres operations cannot run inside a transaction (for example `CREATE INDEX CONCURRENTLY`, which Alembic allows only through an autocommit block); work already committed that way does not roll back, which is one more reason for the backup-before-migration rule.
   - `.venv/bin/python -m app.seed` to insert the demo rows when the table is empty (the seed script no longer creates tables; migrations own the schema)
   - `sudo -n /usr/bin/systemctl restart produce-backend.service` (the one allowed sudo command)
   - retry loop (10 x 2s): `curl --silent --fail http://127.0.0.1:8000/api/health`; exit 1 with message if never healthy
   - DB-backed smoke test: `curl --silent --fail --show-error -X POST http://127.0.0.1:8000/api/sample-endpoint -H "Content-Type: application/json" --data '{"foo":"deploy-smoke","baz":1}'`; exit 1 if it fails.
4. **New `docs/DEPLOYMENT.md`** (start from `C:\Users\jeffr\MCS\ics613\deploy\README.md`, written when the workaround went live; replace its deploy-local.sh sections with the Actions flow): architecture sketch, VPS layout, secret names, provisioning summary, cert rotation steps, manual redeploy via workflow_dispatch (main branch only), rollback by reverting the merge and rerunning deploy, the manual pg_dump backup and restore commands (see the "Database backup and restore" section of this plan) plus the password-rotation procedure from Phase 1.6, Docker log rotation, and a database migrations section covering: how a schema change ships (add or edit the models, import any new model module in `backend/app/models/__init__.py` - env.py only sees tables that import registers, and autogenerate writes a `drop_table` for tables it cannot see, so a forgotten import shows up as a surprise drop in the generated file - then run `npm run db:revision -- "short message"`, review the generated file in `backend/migrations/versions/`, commit it with the code change; the deploy then runs `alembic upgrade head` automatically), how to check the applied revision on the VPS (`ssh vps2 "cd /opt/produce-exchange/app/backend && sudo -u deploy .venv/bin/alembic current"`; sudo -u deploy because only that user can read the `.env` holding the database password), why reverting a merge does not undo a migration (the schema stays at head, and when the revert removes a migration file the next deploy fails at `alembic upgrade head` with an unknown-revision error; fix forward with a new revision or restore the backup, and treat manual `alembic downgrade` as a last resort), never editing a migration that has already run in production, and taking a manual backup before merging any PR that contains a migration. Also document the seed-on-every-deploy behavior: if anyone empties the `sample_data` table in production on purpose, the next deploy re-inserts the three demo rows, because the seed only skips inserting when at least one row exists.
5. **`backend/app/main.py`** - DONE: the `LOG_LEVEL` change (plain `get_log_level()` function defaulting to DEBUG; production sets `LOG_LEVEL=INFO` in the systemd unit) is committed on main as f16076c. Nothing in this item remains for the PR.
6. **No other code changes**: `db.py` unchanged (DB is localhost in both envs; the hardcoded 127.0.0.1 host is correct). No committed `.env.production` - the real `.env` lives only on the VPS (Phase 1.6); optionally add a short "Production" comment block to `.env.example`. No CORS (same origin via nginx; verified `main.py` has no CORS middleware).

## Phase 5: First Actions deploy + cutover from the workaround

The 2026-06-07 workaround deploys already performed the true first deploy (migration cd9306b0de55 applied, demo rows seeded, service running), so the first Actions run is a redeploy onto a live site: the venv exists, the database is at head, and the site keeps serving the whole time except the few seconds of backend restart.

1. Claude opens the Phase 4 PR and stops there: the user merges PRs themselves, always (standing preference, applies to every PR in this project). After the user reports the merge (or `gh pr view` shows it merged), Claude watches `gh run watch` - checks job, then the deploy job copies the backend, runs the remote script, and copies the frontend only after the health checks pass.
2. Confirm the deploy log shows both database steps behaving as no-ops on the live database: `alembic upgrade head` connects and applies nothing (a `Running upgrade` line appears only if the merged PR itself ships a new migration), and the seed step prints `Sample data is already present. Nothing to do.` Then re-run the Verification list below against the public URL.
3. Cutover completion - retire the workaround once step 2 is green:
   - Delete the local private key: `Remove-Item "$env:USERPROFILE\.ssh\produce_exchange_github_actions"` (keep the `.pub`; the private key's only copy then lives in the `DEPLOY_SSH_KEY` secret).
   - Mark the workaround retired: in `C:\Users\jeffr\MCS\ics613\deploy\README.md` and at the top of `deploy-local.sh`, note that deploys now run from GitHub Actions and that manual redeploys use the workflow_dispatch button on the Deploy workflow (main branch only). Do not delete the folder: vps-files\ stays the record of the hand-installed VPS configs.
   - Update the project memory file so future sessions know Actions is the deploy path.
   - Losing the key removes nothing essential: jeff's own `ssh vps2` + sudo still reaches everything, and a replacement deploy key can be minted and installed per Phase 3 step 1 if an offline deploy path is ever needed again.

## Database backup and restore (manual, no automation)

Code rolls back by reverting main, but data does not: the Compose-managed database volume (declared as `produce_db_data` in docker-compose.yml; Docker prefixes the real volume name with the Compose project name, on the VPS `app_produce_db_data`) holds the only copy of production rows. Two commands cover this, run from the local machine (Git Bash). Inside the container, connections over the local socket need no password (the postgres image initializes local auth as trust), so these work as-is:

- Backup (run before schema-changing deploys, password rotation, or anything touching the volume):
  `ssh vps2 "cd /opt/produce-exchange/app && sudo docker compose exec -T db pg_dump -U produce produce_exchange" > backup-$(date +%Y%m%d-%H%M%S).sql`
  The sudo is required because `ssh vps2` logs in as jeff, who is not in the docker group (only `deploy` is). Keep the .sql files on the local machine, not the VPS.
- Restore (into a running db container; drops nothing by itself, so for a clean restore recreate the volume first with `sudo docker compose down --volumes && sudo docker compose up -d --wait db`):
  `ssh vps2 "cd /opt/produce-exchange/app && sudo docker compose exec -T db psql -U produce -d produce_exchange" < backup-FILE.sql`

After a clean-volume restore, the next deploy's seed step finds rows present and skips itself, so restored data is not overwritten. The dump also contains Alembic's `alembic_version` bookkeeping table, so a restored database remembers which migrations it already has, and the next deploy applies only newer ones.

## Verification

1. `curl --fail https://localharvest.exchange/api/health` returns `{"status":"ok"}` (exact route verified: `GET /api/health` in `backend/app/routers/health.py`).
2. DB-backed smoke test succeeds: `curl --fail --show-error -X POST https://localharvest.exchange/api/sample-endpoint -H "Content-Type: application/json" --data '{"foo":"verify","baz":1}'`.
3. Migration state matches the repo: `ssh vps2 "cd /opt/produce-exchange/app/backend && sudo -u deploy .venv/bin/alembic current"` prints the newest revision id from `backend/migrations/versions/` (currently cd9306b0de55) marked `(head)`.
4. Load the site in a browser over https; exercise the sample endpoint page; hit a deep client-side route directly to confirm SPA fallback.
5. `openssl s_client -connect localharvest.exchange:443 -servername localharvest.exchange -verify_hostname localharvest.exchange -verify_return_error -showcerts </dev/null` (from Git Bash or the VPS) shows the full chain in correct order; repeat with `-servername www.localharvest.exchange -verify_hostname www.localharvest.exchange` for the www variant.
6. End-to-end pipeline test: merge a trivial PR (docs typo), watch Actions run checks then deploy, confirm the change is live.
7. Reboot test: `sudo reboot`; confirm docker restarts the db container (`restart: unless-stopped`), systemd starts `produce-backend`, nginx serves the site, `/api/health` and `/api/sample-endpoint` are green.

## Risks

- **RAM (961MB + 3GB swap)**: all backend deps ship as wheels (psycopg[binary]) so `uv sync` is light; postgres 18 defaults (~128MB shared_buffers) + 1 uvicorn worker + nginx fits. Never raise the worker count on this box; lower shared_buffers via compose override if pressure appears.
- **rsync --delete**: `--delete` removes VPS-side files only inside the folders being synchronized (`backend/` and `scripts/`), so the load-bearing exclude is `backend/.venv`, which exists only on the VPS and sits inside the synced tree. The app-root `.env` and `docker-compose.override.yml` are outside the synced folders and beyond `--delete`'s reach today; their excludes stay as guards in case the source list changes, and the deploy-remote.sh preflight fails loudly if `.env` ever goes missing or loses a key anyway. Rollback by reverting the bad merge on `main` and redeploying works for code-only merges. If the merge added a migration that already ran, the redeploy fails at `alembic upgrade head` with an unknown-revision error (the database's current revision id is gone from `backend/migrations/versions/`), so roll forward with a new revision or restore the backup instead. A release-directory plus `current` symlink model is stronger, but out of scope for the class VPS.
- **Migrations**: the deploy applies `alembic upgrade head` and only then restarts the backend, so for a few seconds the old code serves requests against the new schema. Keep migrations additive (create tables and columns; do not drop or rename in the same PR as the code that stops using them). A failed migration is contained for the operations autogenerate writes: env.py runs the whole upgrade in one transaction and normal Postgres DDL rolls back, so the database returns to the previous revision and the deploy stops before the restart. Operations that cannot run in a transaction (for example `CREATE INDEX CONCURRENTLY` through an autocommit block) do not get that rollback, so always take the manual backup first when a migration needs one. Never edit a migration that has already run in production; write a new revision instead. `npm run db:reset` destroys the data volume and is dev-only.
- **Docker log growth**: Docker log rotation in `/etc/docker/daemon.json` is required on this 23GB disk. Verify it with `sudo docker info --format '{{.LoggingDriver}}'` and inspect `/var/lib/docker/containers` if disk use grows.
- **Cert chain order**: wrong concatenation breaks some clients while browsers may still pass; verification step 4 catches it.
- **Repo admin**: Phase 3 step 2 and merging Phase 4 block until granted; all other phases proceed.

## Critical files

- `.github/workflows/unit-tests.yml` (edit: add workflow_call, drop push:main)
- `.github/workflows/deploy.yml` (new)
- `scripts/deploy-remote.sh` (new)
- `docs/DEPLOYMENT.md` (new)
- `backend/app/main.py` (environment-driven log level: DONE, committed as f16076c; listed for context only)
- `backend/app/db.py` (no change; defines the `.env` location contract the VPS layout honors)
- `backend/alembic.ini` + `backend/migrations/` (no change; already committed. The deploy rsync ships them inside `backend`, and deploy-remote.sh runs `alembic upgrade head`)
- VPS-only (not committed): `/etc/systemd/system/produce-backend.service`, `/etc/nginx/sites-available/produce-exchange`, `/opt/produce-exchange/app/.env`, `/opt/produce-exchange/app/docker-compose.override.yml`, `/etc/sudoers.d/deploy`, `/etc/ssl/produce/fullchain.pem`, `/etc/ssl/private/produce.key`

## Appendix: exact file contents

These are the four artifacts the phase bullets specify. Copy-paste ready. A1 and A2 are VPS-only; A3 and A4 get committed to the repo, so they follow the repo's beginner-friendly, plain-ASCII style.

### A1. `/etc/systemd/system/produce-backend.service` (Phase 1.8)

```ini
# Runs the FastAPI backend with uvicorn. nginx proxies /api requests here.
# The app reads database settings from /opt/produce-exchange/app/.env on
# its own (python-dotenv), so no EnvironmentFile line is needed.

[Unit]
Description=Local Produce Exchange backend (uvicorn)
Wants=network-online.target docker.service
After=network-online.target docker.service
# Skip startup cleanly until the first deploy has created the venv.
ConditionPathExists=/opt/produce-exchange/app/backend/.venv/bin/python

[Service]
User=deploy
Group=deploy
WorkingDirectory=/opt/produce-exchange/app/backend
Environment=LOG_LEVEL=INFO
ExecStart=/opt/produce-exchange/app/backend/.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1 --proxy-headers --forwarded-allow-ips 127.0.0.1
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

### A2. `/etc/nginx/sites-available/produce-exchange` (Phase 2.4)

```nginx
# Serves the built React frontend and proxies /api to the FastAPI backend.

# Port 80 only redirects to https.
server {
    listen 80;
    listen [::]:80;
    server_name localharvest.exchange www.localharvest.exchange;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
    server_name localharvest.exchange www.localharvest.exchange;

    ssl_certificate     /etc/ssl/produce/fullchain.pem;
    ssl_certificate_key /etc/ssl/private/produce.key;

    root /opt/produce-exchange/app/frontend/dist;
    index index.html;

    gzip on;
    gzip_types text/css application/javascript application/json image/svg+xml;

    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options DENY always;
    add_header Referrer-Policy strict-origin-when-cross-origin always;

    # React Router does client-side routing, so any unknown path must
    # fall back to index.html instead of returning 404.
    location / {
        try_files $uri $uri/ /index.html;
    }

    # A request to exactly /api also goes to the backend, so the SPA
    # fallback above never hides an API mistake behind the frontend page.
    location = /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # No trailing slash or path after the port number: nginx then passes
    # the original /api/... path through unchanged.
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### A3. `.github/workflows/deploy.yml` (Phase 4.2, committed)

```yaml
name: Deploy

on:
  push:
    branches:
      - main
  # Allows a manual redeploy from the GitHub Actions tab.
  workflow_dispatch:

# Never run two deploys at the same time. A new run waits for the
# current one to finish instead of cutting it off halfway.
concurrency:
  group: deploy-production
  cancel-in-progress: false

jobs:
  checks:
    name: Lint, build, and test
    uses: ./.github/workflows/unit-tests.yml

  deploy:
    name: Deploy to the VPS
    needs: checks
    # Guard so a manual dispatch from a non-main branch cannot deploy.
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    timeout-minutes: 15

    steps:
      - name: Check out repository
        uses: actions/checkout@v6

      - name: Set up Node.js
        uses: actions/setup-node@v6
        with:
          node-version: 22
          cache: npm
          cache-dependency-path: frontend/package-lock.json

      - name: Install rsync
        run: sudo apt-get update && sudo apt-get install -y rsync

      # The checks job built the frontend too, but jobs do not share
      # files, so this job builds its own copy to upload.
      - name: Build frontend
        run: |
          npm --prefix frontend ci
          npm --prefix frontend run build

      - name: Set up SSH
        run: |
          mkdir -p ~/.ssh
          chmod 700 ~/.ssh
          echo "${{ secrets.DEPLOY_SSH_KEY }}" > ~/.ssh/id_ed25519
          chmod 600 ~/.ssh/id_ed25519
          echo "${{ secrets.DEPLOY_KNOWN_HOSTS }}" > ~/.ssh/known_hosts
          chmod 644 ~/.ssh/known_hosts

      # --delete only removes files inside the folders being synchronized
      # (backend/ and scripts/), so the exclude that matters today is
      # backend/.venv, which exists only on the VPS. The .env and
      # docker-compose.override.yml excludes are guards in case the
      # source list ever changes; --delete cannot reach the app root now.
      # The frontend is left out of this copy on purpose: nginx serves it
      # straight from disk, so it is copied last, after the backend is
      # migrated and healthy.
      - name: Copy backend files to the VPS
        run: |
          rsync -az --delete --relative \
            --exclude ".env" \
            --exclude "docker-compose.override.yml" \
            --exclude "backend/.venv" \
            --exclude "__pycache__" \
            --exclude ".pytest_cache" \
            --exclude ".ruff_cache" \
            backend docker-compose.yml scripts \
            "${{ secrets.DEPLOY_USER }}@${{ secrets.DEPLOY_HOST }}:/opt/produce-exchange/app/"

      - name: Install, migrate, restart, and check health on the VPS
        run: |
          ssh "${{ secrets.DEPLOY_USER }}@${{ secrets.DEPLOY_HOST }}" \
            "bash /opt/produce-exchange/app/scripts/deploy-remote.sh"

      # Runs only when the step above passed its health checks. This is
      # the moment the new UI becomes visible. A failure before the
      # backend restart leaves the old UI and the still-running old
      # backend together. A failure at or after the restart is not as
      # forgiving: the old backend process is already gone, so the API
      # may be down (failed restart) or already serving the new code
      # (failed smoke test) until someone reverts or fixes forward.
      # After a good restart, the old UI runs against the new backend
      # for the few seconds before this copy, which is safe as long as
      # API changes stay additive.
      - name: Copy the new frontend to the VPS
        run: |
          rsync -az --delete --relative \
            frontend/dist \
            "${{ secrets.DEPLOY_USER }}@${{ secrets.DEPLOY_HOST }}:/opt/produce-exchange/app/"
```

### A4. `scripts/deploy-remote.sh` (Phase 4.3, committed)

```bash
#!/usr/bin/env bash
# Runs on the VPS during every deploy. The GitHub Actions workflow calls
# this script over SSH after copying the backend files, and copies the
# new frontend only after this script finishes successfully.

set -euo pipefail

APP_ROOT="/opt/produce-exchange/app"
UV="$HOME/.local/bin/uv"

cd "$APP_ROOT"

# Stop at once if the production .env is missing or unreadable. Without
# it, Docker Compose and the app both fall back to the produce/produce
# defaults, and a first deploy would initialize the database volume with
# those default credentials while reporting success.
if [ ! -r "$APP_ROOT/.env" ]; then
    echo "Missing or unreadable $APP_ROOT/.env. Refusing to deploy." >&2
    exit 1
fi

# The same fallback happens one variable at a time: any key missing from
# .env quietly gets its default. So a present-but-incomplete .env is as
# dangerous as a missing one. Check that each required key has a value.
for required_key in POSTGRES_USER POSTGRES_PASSWORD POSTGRES_DB POSTGRES_PORT; do
    if ! grep -q "^${required_key}=." "$APP_ROOT/.env"; then
        echo "No ${required_key} value in $APP_ROOT/.env. Refusing to deploy." >&2
        exit 1
    fi
done

# Install backend dependencies into backend/.venv. --no-dev skips
# test-only tools like pytest and ruff that production never runs.
"$UV" sync --locked --no-dev --directory backend

# Make sure the database container matches the compose file and is
# healthy before anything talks to it. --wait uses the healthcheck.
docker compose up -d --wait db

# Apply any new database migrations. Alembic reads alembic.ini from this
# folder, and migrations/env.py connects with the same settings as the
# app, so the root .env file is all the configuration it needs. The
# upgrade runs inside one transaction, and the table and column changes
# autogenerate writes can all roll back in Postgres: if one fails, the
# database returns to where it was and the script stops here, before the
# restart, so the old backend keeps running against the old schema.
# (Operations that cannot run in a transaction, like CREATE INDEX
# CONCURRENTLY, are the exception; back up before shipping one.)
cd "$APP_ROOT/backend"
.venv/bin/alembic upgrade head

# Insert the demo rows. Tables come from the migrations above; the seed
# script only adds data, and it skips the inserts when rows are already
# present, so this is safe on every deploy.
.venv/bin/python -m app.seed

# Restart the backend. The sudoers file on the VPS allows the deploy
# user to run exactly this one command as root.
sudo -n /usr/bin/systemctl restart produce-backend.service

# Give uvicorn a moment, then confirm the API answers.
attempt=1
while [ "$attempt" -le 10 ]; do
    if curl --silent --fail http://127.0.0.1:8000/api/health; then
        echo ""
        echo "Health check passed."
        break
    fi
    if [ "$attempt" -eq 10 ]; then
        echo "Backend did not become healthy after the restart." >&2
        exit 1
    fi
    attempt=$((attempt + 1))
    sleep 2
done

# One request that needs the database, so a broken database connection
# fails the deploy instead of being found later by a user.
echo "Running the database smoke test."
curl --silent --fail --show-error -X POST http://127.0.0.1:8000/api/sample-endpoint \
    -H "Content-Type: application/json" \
    --data '{"foo":"deploy-smoke","baz":1}'
echo ""
echo "Deploy finished."
```
