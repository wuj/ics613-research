#!/usr/bin/env bash
# Deploys the Local Produce Exchange app from this Windows machine to the
# VPS. This is the manual stand-in for the planned GitHub Actions deploy:
# the same steps in the same order, run from Git Bash instead of a runner.
#
# From Git Bash:    bash /c/Users/jeffr/MCS/ics613/deploy/deploy-local.sh
# From PowerShell:  & "C:\Program Files\Git\bin\bash.exe" C:\Users\jeffr\MCS\ics613\deploy\deploy-local.sh

set -euo pipefail

REPO="/c/Users/jeffr/MCS/ics613/ICS613_Summer2026_FinalProject_Team4"
DEPLOY_DIR="$(cd "$(dirname "$0")" && pwd)"
KEY="/c/Users/jeffr/.ssh/produce_exchange_github_actions"
REMOTE="deploy@45.77.209.138"
APP="/opt/produce-exchange/app"

# All remote commands run as the deploy user with the deploy key, exactly
# like the planned GitHub Actions workflow will.
run_remote() {
    ssh -i "$KEY" -o IdentitiesOnly=yes "$REMOTE" "$1"
}

echo "==> Building the frontend"
cd "$REPO"
npm --prefix frontend ci
npm --prefix frontend run build

echo "==> Copying backend, compose file, and deploy script to the VPS"
# Remove the synced code folders first so source files deleted from the
# repo do not linger on the VPS (tar overwrites but never deletes).
# backend/.venv is kept: rebuilding it on every deploy would be slow,
# and uv sync updates it in place right after this copy.
run_remote "rm -rf $APP/backend/app $APP/backend/migrations $APP/backend/tests && mkdir -p $APP/scripts"
tar -czf - \
    --exclude='backend/.venv' \
    --exclude='__pycache__' \
    --exclude='.pytest_cache' \
    --exclude='.ruff_cache' \
    backend docker-compose.yml \
    | ssh -i "$KEY" -o IdentitiesOnly=yes "$REMOTE" "tar -xzf - -C $APP"
scp -i "$KEY" -o IdentitiesOnly=yes "$DEPLOY_DIR/deploy-remote.sh" "$REMOTE:$APP/scripts/deploy-remote.sh"

echo "==> Running the remote deploy script (install, migrate, seed, restart, health check)"
run_remote "bash $APP/scripts/deploy-remote.sh"

echo "==> Copying the new frontend build"
# The new build lands in dist.new and is swapped in with mv, so the live
# site never serves a half-copied folder. The previous build stays in
# dist.prev in case the new UI needs an instant rollback.
run_remote "rm -rf $APP/frontend/dist.new && mkdir -p $APP/frontend/dist.new"
tar -czf - -C frontend dist \
    | ssh -i "$KEY" -o IdentitiesOnly=yes "$REMOTE" "tar -xzf - -C $APP/frontend/dist.new --strip-components=1"
run_remote "cd $APP/frontend && rm -rf dist.prev && if [ -d dist ]; then mv dist dist.prev; fi && mv dist.new dist"

echo "==> Public health check"
curl --silent --fail https://localharvest.exchange/api/health
echo ""
echo "Deploy finished. Site: https://localharvest.exchange"
