# Deploying Local Produce Exchange to the VPS

This folder holds the working deployment process for the ICS 613 final
project. It is the manual stand-in for the GitHub Actions flow described
in `..\deployment-plan.md`: the VPS layout, the remote script, and the
step order are identical, but the build and copy steps run from this
machine instead of a GitHub runner. Once repo admin is granted and the
Phase 3/4 workflow lands, GitHub Actions takes over and nothing on the
VPS has to change.

The live site: https://localharvest.exchange

## Files in this folder

- `deploy-local.sh` - run this to deploy. Builds the frontend, copies
  the code to the VPS, runs the remote script, then swaps in the new
  frontend.
- `deploy-remote.sh` - runs on the VPS during every deploy (installed
  to `/opt/produce-exchange/app/scripts/`). Installs dependencies,
  applies migrations, seeds, restarts the backend, and health-checks it.
  Identical to the version planned for the repo (Appendix A4 of the
  plan), so committing it later changes nothing.
- `vps-files/` - copies of every hand-installed VPS config file, kept
  here as the provisioning record:
  - `produce-backend.service` -> `/etc/systemd/system/produce-backend.service`
  - `nginx-produce-exchange.conf` -> `/etc/nginx/sites-available/produce-exchange`
  - `docker-compose.override.yml` -> `/opt/produce-exchange/app/docker-compose.override.yml`
  - `sudoers-deploy` -> `/etc/sudoers.d/deploy`

## How to deploy

From Git Bash:

    bash /c/Users/jeffr/MCS/ics613/deploy/deploy-local.sh

From PowerShell:

    & "C:\Program Files\Git\bin\bash.exe" C:\Users\jeffr\MCS\ics613\deploy\deploy-local.sh

Before deploying, stop the frontend dev server if it is running (the
window running `npm run frontend` or `npm run dev`; Ctrl+C is enough).
A running Vite dev server keeps a native module file locked, and the
`npm ci` step fails on Windows with an EPERM unlink error until that
process exits. The backend and db dev processes do not interfere.

The script deploys whatever is currently in the local working tree at
`C:\Users\jeffr\MCS\ics613\ICS613_Summer2026_FinalProject_Team4`, so
check out the commit you want first. Steps, in order:

1. `npm ci` + `npm run build` in `frontend/` (type check + Vite build).
2. Copy `backend/`, `docker-compose.yml`, and `deploy-remote.sh` to
   `/opt/produce-exchange/app/` as the `deploy` user. The code folders
   (`backend/app`, `backend/migrations`, `backend/tests`) are removed
   on the VPS first so deleted source files do not linger;
   `backend/.venv` is kept and updated in place.
3. Run `deploy-remote.sh` on the VPS: check `.env`, `uv sync`,
   `docker compose up -d --wait db`, `alembic upgrade head`, seed,
   restart the systemd service, wait for `/api/health`, then POST the
   database smoke test.
4. Only after step 3 passes: copy `frontend/dist` and swap it in with
   `mv`, keeping the old build at `dist.prev`.
5. Final check against the public URL.

A failure in steps 1-3 leaves the old UI and old backend untouched
(the old backend keeps running until the restart inside step 3).

## VPS layout (what provisioning installed)

Box: vps2 (Vultr, 45.77.209.138, Debian 13, 961MB RAM + 3GB swap).
Login: `ssh vps2` (alias in `C:\Users\jeffr\.ssh\config`, user jeff).

- Packages: nginx, ufw, rsync, curl, gnupg, ca-certificates, and Docker
  Engine + compose plugin from Docker's official apt repo.
- `/etc/docker/daemon.json`: json-file logging capped at 3 x 10MB per
  container so logs cannot fill the 23GB disk.
- User `deploy` (in the `docker` group): owns
  `/opt/produce-exchange/app`, runs the backend, receives deploys.
  Its only login credential is the deploy key (below).
- `/etc/sudoers.d/deploy`: lets deploy run exactly
  `systemctl restart produce-backend.service` and
  `systemctl status produce-backend.service` as root, nothing else.
- uv for the deploy user (`~/.local/bin/uv`) with Python 3.14.2
  installed (the version `backend/.python-version` pins).
- UFW: allows 22 (SSH), 80, and 443; everything else closed. Postgres
  is additionally unreachable because Docker publishes it on 127.0.0.1
  only.
- `/etc/sudoers.d/jeff-nopasswd`: passwordless sudo for the jeff
  account, set up so provisioning and maintenance can run over plain
  `ssh vps2` commands without a password prompt each time.
- `/opt/produce-exchange/app/.env` (mode 600, owner deploy): the only
  copy of the real database password. Never committed, never copied by
  deploys.
- systemd unit `produce-backend.service` (enabled): uvicorn, 1 worker,
  127.0.0.1:8000, `LOG_LEVEL=INFO`, auto-restart.
- TLS: private key `/etc/ssl/private/produce.key` (never left the VPS),
  cert chain `/etc/ssl/produce/fullchain.pem` (Sectigo leaf +
  intermediate bundle, valid until 2026-12-21, covers apex + www).
- nginx site `produce-exchange`: redirects port 80 to https, serves
  `frontend/dist` with an SPA fallback to index.html, and proxies
  `/api/` to 127.0.0.1:8000.

## The deploy SSH key

`C:\Users\jeffr\.ssh\produce_exchange_github_actions` (ed25519, no
passphrase) is the deploy user's only authorized key. deploy-local.sh
uses it for every remote step. When GitHub Actions takes over, this same
private key becomes the `DEPLOY_SSH_KEY` repo secret and the local copy
can be deleted.

## Self-healing (tested 2026-06-07)

The server recovers from these failures on its own; each was tested by
forcing the failure and watching the recovery:

- Reboot: docker starts the db container (`restart: unless-stopped` in
  the override file), systemd starts `produce-backend.service`
  (enabled), nginx starts. Verified end to end after `sudo reboot`:
  health and database smoke test green with no manual step.
- Backend process dies: systemd `Restart=always` starts a new uvicorn
  within 3 seconds. Verified with SIGKILL to the running process.
- Database crashes: the docker restart policy starts the container
  again, and the backend's `pool_pre_ping` reconnects on the next
  request instead of serving stale connection errors. Verified by
  killing postgres inside the container (exit and restart, then a
  passing database smoke test).

One case stays manual on purpose: `docker stop` counts as an operator
decision, so the restart policy does not undo it. Start it again with
`cd /opt/produce-exchange/app && sudo docker compose up -d db`.

## Rollback

- Code: check out the last good commit locally and run the deploy
  script again. This reruns migrations, but `alembic upgrade head` on an
  already-migrated database does nothing.
- Frontend only: on the VPS,
  `cd /opt/produce-exchange/app/frontend && mv dist dist.bad && mv dist.prev dist`.
- A merge that added a migration cannot be rolled back by redeploying
  old code: the database schema stays at the newer revision. Fix forward
  with a new migration, or restore the backup taken before the deploy.

## Database backup and restore (manual)

Run from Git Bash on this machine. Backup before schema-changing
deploys, password rotation, or anything touching the volume:

    ssh vps2 "cd /opt/produce-exchange/app && sudo docker compose exec -T db pg_dump -U produce produce_exchange" > backup-$(date +%Y%m%d-%H%M%S).sql

Restore into a running db container (for a clean restore, recreate the
volume first with `sudo docker compose down --volumes && sudo docker compose up -d --wait db`):

    ssh vps2 "cd /opt/produce-exchange/app && sudo docker compose exec -T db psql -U produce -d produce_exchange" < backup-FILE.sql

Keep the .sql files on this machine, not the VPS. The dump includes
Alembic's `alembic_version` table, so a restored database knows which
migrations it already has. After a clean-volume restore the next
deploy's seed step sees rows and skips itself.

## Database password rotation

The postgres image reads `.env` only when it initializes an empty
volume; after that the password lives inside the volume, so editing
`.env` alone breaks the backend. Rotate in this order (as jeff):

1. `ssh vps2 "cd /opt/produce-exchange/app && sudo docker compose exec db psql -U produce -d produce_exchange -c \"ALTER ROLE produce WITH PASSWORD 'newvalue'\""`
2. Edit `/opt/produce-exchange/app/.env` to match.
3. `ssh vps2 "sudo systemctl restart produce-backend.service"`

## Certificate rotation

The cert expires 2026-12-21. With the new issued files in
`C:\Users\jeffr\MCS\ics613\ssl\`:

    scp C:\Users\jeffr\MCS\ics613\ssl\localharvest_exchange.crt vps2:/tmp/
    scp C:\Users\jeffr\MCS\ics613\ssl\localharvest_exchange.ca-bundle vps2:/tmp/
    ssh vps2 "sudo install -m 644 /tmp/localharvest_exchange.crt /etc/ssl/produce/ && sudo install -m 644 /tmp/localharvest_exchange.ca-bundle /etc/ssl/produce/ && sudo sh -c 'cat /etc/ssl/produce/localharvest_exchange.crt /etc/ssl/produce/localharvest_exchange.ca-bundle > /etc/ssl/produce/fullchain.pem' && sudo chmod 644 /etc/ssl/produce/fullchain.pem && rm /tmp/localharvest_exchange.crt /tmp/localharvest_exchange.ca-bundle && sudo nginx -t && sudo systemctl reload nginx"

The private key only changes if a new CSR was generated; reusing the
existing CSR keeps `/etc/ssl/private/produce.key` valid.

## Database migrations

How a schema change ships: edit or add model files, make sure any new
model module is imported in `backend/app/models/__init__.py` (Alembic
only sees tables that import registers; a forgotten import shows up as
a surprise `drop_table` in the generated file), run
`npm run db:revision -- "short message"`, review the file under
`backend/migrations/versions/`, commit it with the code change. The
next deploy applies it via `alembic upgrade head`.

Check what the production database is at:

    ssh vps2 "cd /opt/produce-exchange/app/backend && sudo -u deploy .venv/bin/alembic current"

Rules: never edit a migration that has already run in production (write
a new revision); take a backup before any deploy that includes a
migration; keep migrations additive (no drops or renames in the same
change as the code that stops using them).

Seed behavior: every deploy runs the seed script. It only inserts the
three demo rows when the table is empty, so emptying `sample_data` in
production on purpose lasts only until the next deploy.

## Switching to GitHub Actions later

Everything VPS-side is already in its final shape. The switch is
written as executable steps in deployment-plan.md Phases 3-5; when
repo admin is granted, Claude runs them end to end:

1. Set the four repo secrets (`DEPLOY_SSH_KEY`, `DEPLOY_HOST`,
   `DEPLOY_USER`, `DEPLOY_KNOWN_HOSTS`) per Phase 3 step 2.
2. Open the Phase 4 PR: `workflow_call` in unit-tests.yml, new
   deploy.yml, `scripts/deploy-remote.sh` (copy the one in this
   folder, unchanged), `docs/DEPLOYMENT.md` (start from this README).
3. The user merges the PR (Claude opens it but never merges); then
   Claude watches the first Actions deploy (Phase 5). On the live
   database both DB steps are no-ops: alembic applies nothing and the
   seed prints "Sample data is already present. Nothing to do."
4. Cutover completion: delete the local private key (the
   `DEPLOY_SSH_KEY` secret becomes its only copy), mark this folder's
   deploy-local.sh retired, and from then on manual redeploys use the
   workflow_dispatch button on the Deploy workflow. Everything else in
   this README (backup, rotation, migrations, self-healing) stays
   current; only the deploy driver changes.
