---
name: reconcile-use-cases
description: Reconcile the ICS 613 Local Produce Exchange backup high-level use cases with the read-only current-state use cases. Use when the user asks Codex to sync, align, refresh, update, reconcile, map, or backfill `ics613-research/artifacts/use-cases.md` against `ics613-research/current-state/current-state-use-cases.md`. Preserve the full backup plan and maintain its current-state mapping.
---

# Reconcile Use Cases

## Purpose

Use this skill to keep the user's backup use cases complete, requirements-faithful, and mapped to the team's current-state use-case slice.

Unlike the Team Charter, these two documents are not parallel copies. The backup is the full plan. The current-state document is a smaller, differently modeled slice. Do not merge the current-state slice directly into the full plan if doing so would create duplicate or contradictory use cases. Preserve team work through the backup's mapping section.

## Files

- Edit only: `ics613-research/artifacts/use-cases.md`
- Read only: `ics613-research/current-state/current-state-use-cases.md`
- Read for format: `ics613-research/templates/use-case-template.md`
- Read for requirements: `ics613-research/requirements.md`
- Read for settled decisions and mappings: `references/project-context.md`

## Hard Rules

1. Never edit the current-state use cases.
2. Never edit files outside the backup use cases unless the user explicitly asks.
3. Preserve every current-state contribution in the backup's mapping.
4. Keep the backup as the full plan unless the user changes that decision.
5. Do not inject narrower current-state use cases as duplicate full-plan use cases.
6. Match by goal, not by use-case number.
7. Stop and ask before resolving a significant conflict or unclear structural change.
8. Keep all prose ASCII-only and plain-spoken.

## Workflow

1. Read all files listed above. Read current-state fresh every run.
2. Keep the full-plan defaults unless the user says otherwise:
   - 24 backup use cases
   - full claim lifecycle
   - requester role named `Claimant`
   - `Admin` included where the full plan needs it
3. Sync shared account use cases. UC-01 through UC-05 should match current-state wording when the goal is the same.
4. Update the backup's mapping section. It should map each current-state use case to the full-plan use case by goal, list full-plan use cases outside current scope, and carry open decisions.
5. If current-state adds, removes, renames, regroups, or renumbers use cases, update the mapping. Do not copy its numbering scheme into the full plan unless the user asks.
6. If current-state adds a use case with no full-plan counterpart, record it in the mapping and ask whether to add a full-plan use case.
7. If no changes are needed, do not churn the file. Report that the backup is already aligned.

## Structural Changes

Mirror shared document skeleton changes where doing so helps manual backfill: introduction, actors, coverage sections, mapping section, assumptions, and open questions. Do not mirror item groupings or IDs that differ on purpose. The mapping is the bridge between the current-state slice and the full plan.

## Conflict Handling

If anything does not reconcile cleanly, stop before editing that part. Explain the problem plainly, give at least two concrete options, recommend the option that makes the user's later manual backfill easiest, and ask what to do.

Common conflicts:

- queue model versus full claim lifecycle
- `Recipient` versus `Claimant`
- current-scope-only item with no full-plan counterpart
- current-state narrowing the project below requirements
- numbering or grouping drift that makes mapping unclear

## Report Format

After a successful reconciliation, keep the report short and use these groups:

- `Synced from current-state`: wording or shared use cases carried into the backup
- `Mapping updates`: changes made to the mapping section
- `Decisions that need the user`: unresolved model, role, scope, or new conflicts
- `Minor calls I made`: small choices the user can reverse
- `Still placeholders`: planned `TBD` or non-use-case notes left as-is

End by confirming the backup remains the full plan and is mapped to current-state by goal.
