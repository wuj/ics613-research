# Reconcile Use Cases: Project Context

Read this file after `SKILL.md` when reconciling the backup use cases.

## Project

- Course: ICS 613, Advanced Software Engineering, Summer 2026.
- Team: Team 4.
- User: Jeff Wu.
- Project: Local Produce Exchange.
- Product: invite-only web app where a trusted community shares surplus food. Members post listings, others request or claim a quantity, and the two coordinate pickup through a private message thread.
- Stack: React and TypeScript frontend; Python with FastAPI, SQLAlchemy, and Pydantic backend; PostgreSQL database.
- Due date context: early June 2026. "11th hour" means just before the deadline.

## Document Relationship

- Backup full plan: `ics613-research/artifacts/use-cases.md`
- Current-state slice: `ics613-research/current-state/current-state-use-cases.md`

The backup has 24 use cases, UC-01 through UC-24. It uses Guest, Member, Poster, Claimant, and Admin. It uses the full claim lifecycle.

The current-state document has 12 use cases, its own UC-01 through UC-12. It uses Guest, Member, Poster, and Recipient. It uses a request-queue model.

## Expected Differences

1. Scope: full plan versus narrowed current slice.
2. Model: full claim lifecycle versus request queue that stops at approve or deny.
3. Role name: Claimant plus Admin versus Recipient and no Admin.
4. Numbering: only UC-01 through UC-05 line up by number. Match the rest by goal.

## Goal Mapping

Keep this mapping current in the backup mapping section:

| Current-scope UC | Full-plan UC | Note |
| --- | --- | --- |
| UC-01 Register with an invite token | UC-01 | Same |
| UC-02 Log in | UC-02 | Same |
| UC-03 Log out | UC-03 | Same |
| UC-04 Invite a new member | UC-04 | Same; same open question about who may invite |
| UC-05 Manage member profile | UC-05 | Same |
| UC-06 Browse, search, and filter active listings | UC-09 | Same goal, different number |
| UC-07 View listing details | UC-10 | Same goal; full plan also shows photos |
| UC-08 Submit a request for an item | UC-11 Claim produce | Same core goal; current-scope adds queue placement and duplicate-request guard; role name differs |
| UC-09 View the request queue for a listing | No direct equivalent | Nearest are UC-14 and UC-20; queue model would need a full-plan view-queue use case |
| UC-10 Approve or deny the next request in the queue | UC-14 | Same goal; current-scope handles queue order |
| UC-11 Withdraw a queued request | UC-13 Cancel a claim | Same goal; current-scope allows only REQUESTED, full plan allows REQUESTED or APPROVED; role differs |
| UC-12 Send and read messages in the exchange thread | UC-16 | Same goal, different number and name |

## Full-Plan Use Cases Outside Current Scope

UC-06 Create a listing, UC-07 Edit a listing, UC-08 Deactivate own listing, UC-12 Confirm pickup, UC-15 Complete an exchange, UC-17 View status notifications, UC-18 Leave a rating and review, UC-19 View reviews, UC-20 View dashboard, UC-21 Suspend a user, UC-22 Deactivate a listing as admin, UC-23 Generate basic reports, UC-24 View pickup reminders.

## Settled Defaults

- Keep the backup as the full plan.
- Keep the full claim lifecycle because it matches the requirements.
- Use `Claimant` in the full plan.

## Open Questions To Preserve

- Is the queue model only the current iteration, or is it meant to replace the lifecycle?
- Should the team use `Claimant` or `Recipient` as the official term?
- Does the team commit to the full plan or only the current slice?
- Should the full plan add a standalone view-the-queue use case if the queue model stays?

## Reminder

These are defaults, not a substitute for reading the live files. Always preserve new current-state contributions through the mapping and ask about real conflicts.
