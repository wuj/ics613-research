---
name: reconcile-user-stories
description: Reconcile the ICS 613 Local Produce Exchange backup user stories with the read-only current-state user stories. Use when the user asks Codex to sync, align, refresh, update, reconcile, map, or backfill `ics613-research/artifacts/user-stories.md` against `ics613-research/current-state/current-state-user-stories.md`. Preserve the full 25 to 30 story backup and maintain its current-state mapping.
---

# Reconcile User Stories

## Purpose

Use this skill to keep the user's backup user stories complete, requirements-faithful, inside the course-required story count, and mapped to the team's current-state story slice.

Unlike the Team Charter, these two documents are not parallel copies. The backup is the full plan. The current-state document is a smaller, differently modeled slice. Do not merge the current-state slice directly into the full plan if doing so would create duplicate or contradictory stories. Preserve team work through the backup's mapping section.

## Files

- Edit only: `ics613-research/artifacts/user-stories.md`
- Read only: `ics613-research/current-state/current-state-user-stories.md`
- Read for format: `ics613-research/templates/user-story-template.md`
- Read for requirements: `ics613-research/requirements.md`
- Read for settled decisions and mappings: `references/project-context.md`

## Hard Rules

1. Never edit the current-state user stories.
2. Never edit files outside the backup user stories unless the user explicitly asks.
3. Preserve every current-state contribution in the backup's mapping.
4. Keep the backup as the full 25 to 30 story plan unless the user changes that decision.
5. Do not inject narrower current-state stories as duplicate full-plan stories.
6. Match by goal, not by story number.
7. Stop and ask before resolving a significant conflict or unclear structural change.
8. Keep all prose ASCII-only and plain-spoken.

## Workflow

1. Read all files listed above. Read current-state fresh every run.
2. Keep the full-plan defaults unless the user says otherwise:
   - 25 backup stories, inside the required 25 to 30
   - full claim lifecycle
   - requester role named `Claimant`
   - `Admin` included where the full plan needs it
3. Sync shared account stories. US-01 through US-05 should match current-state wording when the goal is the same. Milestone labels may still differ on purpose.
4. Update the backup's mapping section. It should map each current-state story to the full-plan story by goal, list full-plan stories outside current scope, carry open decisions, and keep the non-story technical-deliverable note.
5. If current-state adds, removes, renames, regroups, or renumbers stories, update the mapping. Do not copy its numbering scheme into the full plan unless the user asks.
6. If current-state adds a story with no full-plan counterpart, record it in the mapping and ask whether to add a full-plan story while staying inside the 25 to 30 count.
7. If no changes are needed, do not churn the file. Report that the backup is already aligned.

## Structural Changes

Mirror shared document skeleton changes where doing so helps manual backfill: introduction, actors, grouped story sections, master story list, coverage sections, mapping section, assumptions, and open questions. Do not mirror item groupings, IDs, or milestone labels that differ on purpose. The mapping is the bridge between the current-state slice and the full plan.

## Conflict Handling

If anything does not reconcile cleanly, stop before editing that part. Explain the problem plainly, give at least two concrete options, recommend the option that makes the user's later manual backfill easiest, and ask what to do.

Common conflicts:

- queue model versus full claim lifecycle
- `Recipient` versus `Claimant`
- current-scope-only story with no full-plan counterpart
- current-state narrowing the project below requirements
- current-state putting all stories in R1 while the full plan spreads stories across milestones
- numbering or grouping drift that makes mapping unclear

## Report Format

After a successful reconciliation, keep the report short and use these groups:

- `Synced from current-state`: wording or shared stories carried into the backup
- `Mapping updates`: changes made to the mapping section
- `Decisions that need the user`: unresolved model, role, scope, milestone, or new conflicts
- `Minor calls I made`: small choices the user can reverse
- `Still placeholders`: planned `TBD`, assumptions, or notes left as-is

End by confirming the backup remains the full plan, holds 25 to 30 stories, and is mapped to current-state by goal.
