# Reconcile User Stories: Project Context

Read this file after `SKILL.md` when reconciling the backup user stories.

## Project

- Course: ICS 613, Advanced Software Engineering, Summer 2026.
- Team: Team 4.
- User: Jeff Wu.
- Project: Local Produce Exchange.
- Product: invite-only web app where a trusted community shares surplus food. Members post listings, others request or claim a quantity, and the two coordinate pickup through a private message thread.
- Course rule: user stories deliverable requires 25 to 30 stories.
- Due date context: early June 2026. "11th hour" means just before the deadline.

## Document Relationship

- Backup full plan: `ics613-research/artifacts/user-stories.md`
- Current-state slice: `ics613-research/current-state/current-state-user-stories.md`

The backup has 25 stories, US-01 through US-25. It uses Guest, Member, Poster, Claimant, and Admin. It uses the full claim lifecycle and traces to the full-plan use cases.

The current-state document has 12 stories, its own US-01 through US-12. It uses Guest, Member, Poster, and Recipient. It uses a request-queue model and traces to the current-scope use cases.

## Expected Differences

1. Scope: full 25-story plan versus narrowed 12-story current slice.
2. Model: full claim lifecycle versus request queue that stops at approve or deny.
3. Role name: Claimant plus Admin versus Recipient and no Admin.
4. Numbering: only US-01 through US-05 line up by number. Match the rest by goal.

## Goal Mapping

Keep this mapping current in the backup mapping section:

| Current-scope US | Full-plan US | Note |
| --- | --- | --- |
| US-01 Register with an invite token | US-01 | Same |
| US-02 Log in | US-02 | Same |
| US-03 Log out | US-03 | Same |
| US-04 Invite a new member | US-04 | Same; full plan R2, current scope R1; same invite-issuer open question |
| US-05 View and update member profile | US-05 | Same; full plan R2, current scope R1 |
| US-06 Browse, search, and filter active listings | US-10 | Same goal, different number |
| US-07 View listing details | US-11 | Same goal; full plan also shows photos |
| US-08 Submit a request for an item | US-12 Submit a claim | Same core goal; current scope adds queue placement and duplicate-request scenario; role differs |
| US-09 View the request queue for a listing | No direct equivalent | Nearest are US-15 and US-21; queue model would need a full-plan view-queue story |
| US-10 Approve or deny the next request in the queue | US-15 | Same goal; current scope handles queue order |
| US-11 Withdraw a queued request | US-13 Cancel a claim | Same goal; current scope allows only REQUESTED, full plan allows REQUESTED or APPROVED; role differs |
| US-12 Send and read messages in the exchange thread | US-17 | Same goal, different number |

## Full-Plan Stories Outside Current Scope

US-06 Create a listing, US-07 Add and manage photos, US-08 Edit a listing, US-09 Deactivate own listing, US-14 Confirm pickup, US-16 Complete an exchange, US-18 View status notifications, US-19 Leave a rating and review, US-20 View reviews, US-21 View dashboard, US-22 Suspend a user, US-23 Deactivate a listing as admin, US-24 Generate basic reports, US-25 View pickup reminders.

## Settled Defaults

- Keep the backup as the full plan.
- Keep 25 stories unless the user asks to change the count. Stay inside 25 to 30.
- Keep the full claim lifecycle because it matches the requirements.
- Use `Claimant` and include `Admin` in the full plan.

## Open Questions To Preserve

- Is the queue model only the current iteration, or is it meant to replace the lifecycle?
- Should the team use `Claimant` or `Recipient` as the official term?
- Does the team commit to the full plan or only the current slice?
- Should milestones stay split across R1, R2, and stretch in the full plan while current-state keeps all 12 stories in R1?
- Should the full plan add a standalone view-the-queue story if the queue model stays?

## Reminder

These are defaults, not a substitute for reading the live files. Always preserve new current-state contributions through the mapping and ask about real conflicts.
