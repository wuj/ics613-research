# Reconcile Team Charter: Project Context

Read this file after `SKILL.md` when reconciling the backup Team Charter.

## Project

- Course: ICS 613, Advanced Software Engineering, Summer 2026.
- Team: Team 4.
- Members: Kennan Kaneshiro, Shea Stevens, Matt Ong, Kim Cates, and Jeff Wu.
- Project: Local Produce Exchange.
- Product: invite-only web app where a trusted community shares surplus food before it goes to waste.
- Stack: React and TypeScript frontend; Python with FastAPI, SQLAlchemy, and Pydantic backend; PostgreSQL database.
- Due date context: early June 2026. "11th hour" means just before the deadline.

## Product Summary

Members post surplus produce listings. Other members claim a quantity. Claims move through a lifecycle: REQUESTED, APPROVED, PICKED_UP, COMPLETED, plus DENIED and CANCELLED paths. Each exchange has a private message thread. Both sides can review after completion. The app includes a member dashboard and an admin role.

## Charter Sections

1. Team Purpose
2. Project Scope and Objectives
3. Team Members and Roles
4. Team Values
5. Communication Plan
6. Working Agreements
7. Decision-Making Process
8. Development Workflow
9. Quality Standards
10. Project Artifacts
11. Conflict Resolution and Accountability
12. Risks and Mitigation
13. Milestones and Timeline
14. Team Commitment Statement
15. Signatures

## Role Mapping

Use these as proposed roles unless current-state or the user changes them:

- Kennan Kaneshiro: Backend Lead, based on backend, SQL, and connection work.
- Shea Stevens: Database Lead, based on database administration work.
- Matt Ong: Frontend Lead, proposed because current-state had no role detail.
- Kim Cates: Team Lead and Scrum Master, proposed because current-state had no role detail.
- Jeff Wu: QA and DevOps Lead, based on Docker, Make, and GitHub Actions work.

Keep role assignments as proposals until confirmed by the team.

## Recurring Decisions

- Use `Team 4`, not `Team X`.
- Goals and Values may exceed the template's suggested counts when needed to preserve team content and backup fill. Flag the count. If the user wants to trim, suggest cutting `Process discipline` from Goals and `Build work we can demo` from Values.
- Keep current-state In Scope items even when they read like design notes. Flag the `request queue` item because it may overlap with over-claim protection in the claim lifecycle.
- Pull request approvals: default to at least one approval for a five-person class team. Flag this if current-state still says `two to three approvals?`. Offer one approval, two approvals, or one normally and two for core business rules.
- Branch name: use `main`, not `master`, unless current-state and the repo prove otherwise.
- Section 13 milestones: use the current-state 11-row breakdown and map richer backup notes into those rows. Owners stay `TBD`.
- June 15 milestone: keep current-state label `Cross-Team Requirements Review Packet`. If needed, flag that a June 16 presentation/report may be a related but separate item.
- Section 14 commitment statement: use the plain rewrite already approved by the user unless current-state has a new team contribution.

## Current-State Links To Preserve

- Code repository: https://github.com/kennank27/ICS613_Summer2026_FinalProject_Team4
- Meeting notes: https://drive.google.com/drive/folders/1s7VIsUajSrPqejtY_euqD7INBDaIAaNj?usp=drive_link

## Reminder

These are defaults, not a substitute for reading the live files. Always preserve new current-state contributions and ask about real conflicts.
