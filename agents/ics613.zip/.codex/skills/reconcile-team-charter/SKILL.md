---
name: reconcile-team-charter
description: Reconcile the ICS 613 Local Produce Exchange backup Team Charter with the read-only current-state Team Charter. Use when the user asks Codex to sync, align, refresh, update, reconcile, or backfill `ics613-research/artifacts/team-charter.md` from `ics613-research/current-state/current-state-team-charter.md`, especially for an 11th-hour submission. Read current-state but never edit it.
---

# Reconcile Team Charter

## Purpose

Use this skill to keep the user's backup Team Charter complete, aligned with the team's current-state charter, and ready for manual backfill by the user near the deadline.

The current-state charter and backup charter are parallel copies of the same deliverable. Make the backup mirror the current-state structure and wording where the team has contributed, then fill the remaining gaps in the backup.

## Files

- Edit only: `ics613-research/artifacts/team-charter.md`
- Read only: `ics613-research/current-state/current-state-team-charter.md`
- Read for structure: `ics613-research/templates/team-charter-template.md`
- Read for requirements: `ics613-research/requirements.md`
- Read for settled decisions: `references/project-context.md`

## Hard Rules

1. Never edit the current-state charter.
2. Never edit files outside the backup charter unless the user explicitly asks.
3. Preserve every current-state contribution in the backup.
4. When the backup and current-state express the same item, prefer current-state wording.
5. Backfill every section so the backup can stand alone.
6. Stop and ask before resolving a significant conflict or unclear structural change.
7. Keep all prose ASCII-only and plain-spoken.

## Workflow

1. Read all files listed above. Read current-state fresh every run.
2. Compare structure before content. Mirror current-state section order, heading style, subsection names, table columns, and table rows in the backup.
3. Reconcile section by section. Pull in current-state wording first, then keep or add backup content as fill.
4. Preserve current-state links, names, responsibilities, table shapes, milestones, and any newly added team material.
5. Leave people-only cells as placeholders:
   - role assignments in Section 3 are proposals unless already confirmed
   - milestone owners in Section 13 stay `TBD`
   - signatures and dates in Section 15 stay blank or placeholder
6. If no changes are needed, do not churn the file. Report that the backup is already aligned.
7. After editing, report what changed in the groups below.

## Conflict Handling

If anything does not reconcile cleanly, stop before editing that part. Explain the problem plainly, give at least two concrete options, recommend the option that makes the user's later manual backfill easiest, and ask what to do.

Examples that require asking:

- current-state contradicts the backup on a real project decision
- current-state adds, removes, renames, or reorders sections in a way whose intent is unclear
- two pieces of content overlap but are not clearly the same
- a table shape changes and the matching backup structure is ambiguous

## Report Format

After a successful reconciliation, keep the report short and use these groups:

- `Pulled in from current-state`: team contributions preserved in the backup
- `Proposals to confirm`: drafted items that need team sign-off
- `Decisions that need the user`: unresolved conflicts, with a recommendation and clear question
- `Minor calls I made`: small choices the user can reverse
- `Still placeholders`: people-only items left blank or `TBD`

End by confirming whether the backup is ready for the user's manual backfill.
