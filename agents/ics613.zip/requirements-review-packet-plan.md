# Plan: Build the Requirements Review Packet

## Context

The course requires each team to submit a Requirements Review Packet with five items: user stories, acceptance criteria, user roles/personas, open questions and assumptions, and known risks (ics613-research\requirements.md:355-361). All of the content exists across three artifacts: team-charter.md, use-cases.md, and user-stories.md. The task is extraction and reformatting only: build one markdown file per required item in a new folder, `ics613-research/artifacts/requirements-review-packet/`, without modifying any source file.

The audience is the other team acting as reviewers in the cross-team requirements peer review, so the README cover page states the packet's purpose and each file stands on its own for a reviewer who has not seen our other artifacts.

The source artifacts are team-owned and change fast (on 2026-06-07 teammates added five stories, US-26 to US-30, and two use cases, UC-25 and UC-26, inserted topically rather than in ID order). The packet is therefore a generated artifact: a project skill (`.claude/skills/generate-requirements-packet/`) builds it from whatever the sources say at run time, and rebuilds it whenever the sources change. Every list, count, and table is derived from the current sources on each run; any specific IDs or counts in this plan are dated examples, never targets.

User decisions (confirmed):
- Stories and acceptance criteria are split with no duplication between the two files.
- Roles file contains roles only, taken from the use-cases actors section; no invented personas.
- Exactly the 5 required files; the domain model is not included or linked as content.
- Numbered filenames (01- through 05-) plus a short README.md cover page.
- The skill is manual-only: the user runs it as `/generate-requirements-packet`; the model does not invoke it on its own (see "Skill frontmatter").
- Deliverables only: the packet references nothing outside itself and never mentions tooling (see "Deliverables only").
- No markdown links anywhere in the packet (decided 2026-06-07, reversing the earlier internal-links decision): US-IDs and UC-IDs are plain text, and references that would leave the packet become plain text.
- Internal cross-references in carried text are minimally generalized, each edit listed in the run report (see "Source fidelity").

## Attribution header (top of every packet file)

Scope: the 6 packet files only. The existing artifacts are not modified.

Every packet file opens with the same attribution block, byte-for-byte identical except for the document title on the first line. The block occupies lines 3 through 5 of every file (line 1 is the title, line 2 is blank), so the validator can compare it mechanically. Source of the facts: the title slide of the Project Initiation Presentation PDF. These facts are pinned constants in the skill spec; they do not change when the markdown sources change.

```
# <Document title>

**Team:** Team 4 | Local Produce Exchange, "Surplus"\
**Course:** ICS 613 Software Engineering | University of Hawai'i at Manoa | Summer 2026\
**Members:** Kennan Kaneshiro, Shea Stevens, Matt Ong, Kim Cates, Jeff Wu
```

- The three attribution lines are identical in every file; only the title line varies.
- Lines 3 and 4 end with a single backslash, the markdown hard line break, so the three lines render one per line instead of collapsing into one paragraph. Line 5 has no trailing backslash.
- Label format and project-name wording (Local Produce Exchange, "Surplus") chosen by the user on 2026-06-07.
- The school name uses the ASCII spelling (straight apostrophe, no macron), per the project's ASCII-only rule.

## Deliverables only

The packet files are the deliverables and nothing else. Concretely:

- No reference to any file outside the packet: no links to other folders, no file names of the source documents, no repo paths.
- No markdown links anywhere in the packet, not even between the six packet files; US-IDs and UC-IDs are plain text. The README names the packet files in plain text.
- No mention of tooling or team channels anywhere in the packet: nothing about Claude, AI, skills, scripts, generation, Discord, Google Docs, or GitHub. Connecting prose reads as if a person assembled the documents.
- No machine state in the packet: the source-state file lives in the skill folder, and packet files contain no HTML comments.
- The README names the source documents as documents ("the team's charter, use cases, and user stories"), never as file names.

## Source fidelity

Carried-over content preserves source wording exactly, with exactly three permitted mechanical changes:

1. **Markdown escaping repairs:** write `PICKED_UP` not `PICKED\_UP`, plain hyphens not `\-`.
2. **ASCII normalization:** teammate edits introduce non-ASCII punctuation. Curly quotes and apostrophes become straight quotes, including inside headings. A long dash (em or en) becomes the nearest meaning-preserving ASCII punctuation: a comma, a colon, parentheses, or a sentence break; never a hyphen or a double hyphen, per the project prose rule. No word changes.
3. **Minimal generalization of internal references:** when carried text points at a source document's internal section, a course document, or a team tool, trim the reference minimally (dated examples: the charter's "follow the escalation steps in Section 11" becomes "follow the team's escalation steps"; the US-08 note "models the requirements Sample User Story #1" is dropped as pure traceability). Every such edit is listed in the run report.

**Malformed source content is not fixed and does not pause generation.** Teammate-written scenarios may have missing Given/When/Then keywords, typos that change meaning, or garbled grammar (dated examples: "Restaurants the quantity back", "the account can then longer log in", steps with no Then). These carry through verbatim (after the three mechanical changes above), and the run report lists each suspected malformation as an FYI the user can raise with the team. We cannot change what other people wrote; the packet reflects the sources as they are.

Generation pauses and asks the user only when structure prevents faithful extraction: an unparseable story or use-case heading, a duplicate US or UC ID, a story with no scenarios at all, a missing metadata field (source use case, priority, actor, milestone), or a story citing a use case that does not exist.

## Files to create

All in `ics613-research/artifacts/requirements-review-packet/`. Derive everything from the current sources at run time.

### README.md (cover page)
- Title `Requirements Review Packet`, attribution block.
- One short paragraph: this packet is for the cross-team requirements peer review, where the reviewing team looks for ambiguity, missing requirements, unrealistic scope, inconsistent workflows, unclear user roles, and missing edge cases.
- Numbered list of the 5 packet files in assignment order, each the document title with its file name in parentheses, plain text, no links.
- One line: assembled from the team's charter, use cases, and user stories without changing them.

### 01-user-stories.md
Source: user-stories.md. For every story heading in the source, in source order (which is topical, not numeric ID order):
- `#### US-NN: <title>` as the source titles it (after ASCII normalization), the story statement, and the metadata bullets: source use case or use cases (plain-text UC-IDs, keeping any parentheticals), priority, actor, milestone.
- No scenarios and no per-story criteria pointer; the intro says the criteria are in the acceptance criteria document under the same US-ID.
- Mirror the source's section groupings, whatever they are at run time.

### 02-acceptance-criteria.md
Source: user-stories.md. Same groupings and story order as 01. For every story:
- `#### US-NN: <title>`, then every scenario with source wording preserved per "Source fidelity". No "Story:" line; the statement is in 01 under the same US-ID.
- Settled-rule notes stay with their story (dated examples: "a denial is final", "email or SMS notifications are out of scope").
- Open questions and assumptions move to 04; pure-traceability notes are dropped per "Source fidelity". The classification rule lives in the skill's reference.md.

### 03-user-roles-personas.md
Source: the use-cases actors-and-roles section.
- The role context from the source intro (contextual roles, the meaning of "exchange", quantity available vs remaining, the suspended-account rule) and every role the source defines.
- A role-to-story table derived from the stories' Actor fields; every story appears exactly once; US-IDs are plain text.

### 04-open-questions-assumptions.md
Sources: the per-story notes blocks in user-stories.md and the parenthetical "(Assumption: ...)" notes in use-cases.md.
- One table: ID (OQA-NN, numbered in document order), Type (Open question, Assumption, or both), Item, Affected stories and use cases, Status (Open).
- Affected-items rule: each row lists the story ID(s) whose notes raised the item plus each such story's source use case ID(s) from its metadata. For a parenthetical that appears only in a use case, the row lists that UC-ID plus the story IDs that cite the UC as their source use case (equivalently, the use case's related-stories line). US-IDs and UC-IDs are plain text.
- Deduplicate: when a story note and a use-case parenthetical record the same item, one row covers both and lists all the IDs.

### 05-known-risks.md
Source: the charter's risks-and-mitigation section.
- One table: Risk, Mitigation; one row per charter risk, wording per "Source fidelity".
- When a risk names business rules that specific stories enforce, name those US-IDs in plain text after the rule name. Derivation rule: take each rule the risk names (e.g., over-claim prevention, allowed status transitions, no cancellation after pickup) and name every story whose scenarios test that rule, found by searching the scenarios for the rule's terms (quantity exceeding, status changes and wrong-status rejections, cancel and withdraw guards). This is a judgment call re-derived each run (new stories like US-26 can join a mapping); the run report lists the mapping chosen.

## No-links rule

The packet contains no markdown links at all (user decision, 2026-06-07, replacing the earlier ID-linking design). Every US-ID and UC-ID is plain text. Cross-references name a document in plain words ("the acceptance criteria document") or give an ID, and the README lists the packet files by title and file name without linking them. The validator fails on any link syntax in a packet file.

## Skill frontmatter

So the skill is reproducible from this plan, its SKILL.md frontmatter is exactly:

```yaml
---
name: generate-requirements-packet
description: Generate or regenerate the cross-team Requirements Review Packet (ics613-research/artifacts/requirements-review-packet/) from the team charter, use cases, and user stories for the ICS 613 Local Produce Exchange project. Use when the user asks to generate, build, regenerate, refresh, or update the requirements review packet, or to check whether the packet is stale against its sources. Creates the packet if missing; if it exists, detects source changes, spec changes, or hand edits via stored hashes and regenerates all six files, overwriting them. Never modifies the source artifacts; when sources contain errors, inconsistencies, or contradictions, asks the user how to handle them in the packet.
disable-model-invocation: true
---
```

- The directory name `generate-requirements-packet` is the slash command; `name` matches it.
- `disable-model-invocation: true` makes the skill manual-only: only the user can run it, by typing `/generate-requirements-packet` (optionally with `force`). The model cannot trigger it, so an overwrite of the packet can never happen as a side effect of conversation.
- The skill folder bundles `reference.md` (the per-file generation spec) and `validate.py` (the deterministic validator), and creates and updates `source-state.txt` (machine state; it does not exist until the first generation).

## Iteration and regeneration (the skill)

- **First run (no packet):** generates all 6 files from the current sources.
- **Later runs:** computes SHA-256 hashes of eleven files: the three source artifacts, the two spec files (SKILL.md, reference.md), and the six packet files. Compares them to `source-state.txt` in the skill folder.
  - Any input hash differs (sources or spec), or any packet file is missing, or the user forces it: regenerate all 6 files. No partial updates.
  - Input hashes match but a packet hash differs: a hand edit. Name the edited files and ask the user: regenerate (losing the edits) or stop.
  - All eleven match: still run validate.py (so a validator fix always takes effect), then report the packet is current with the validation result. validate.py itself is not hashed; it checks output without shaping it, and running it every time closes the gap a stale-skip would leave.
- **Pinned inputs, not hashed:** ics613-research/requirements.md (the assignment's 5-item list) and the PDF title-slide attribution facts are constants baked into the spec. If they change, the user updates the spec; that changes the spec hashes, which triggers regeneration.
- **Sources are read-only, always.** The skill never edits anything outside the packet folder and its own state file. Teammate errors cannot be fixed by this workflow; see "Source fidelity" for what carries verbatim and what pauses.
- **Structural problems pause generation** (the list in "Source fidelity"): the skill stops, explains with source lines, offers options (carry through verbatim, record in 04 as an open question, or omit), recommends one, and asks the user. Omissions are recorded on the `omissions:` line of the state file, and verification exempts them.
- **Known exceptions, never flagged:** the empty assumptions tables at the bottom of the two sources (content lives inline); preconditions that also have exception flows (the chosen authoring pattern); the US-10/UC-10 order-received language (a poster convention, still listed in 04 as an assumption because the sources frame it as one). Known wording gaps the user reviewed and left unfixed carry through without asking: R1 stories depending on R2 features; "available" vs "remaining" (US-07/US-08); US-18 Scenario 1 lacking "for this exchange"; US-25's photo-display benefit clause; "open request" vs "pending request". If a teammate edits one of these passages, judge the new wording on its own.
- **Hand edits to packet files are lost on regeneration.** The packet folder is output.

### Source-state file format

`.claude/skills/generate-requirements-packet/source-state.txt`, written by the skill right after generating and before validating (the validator checks it), and rewritten after any regeneration:

```
team-charter.md sha256=<HASH>
use-cases.md sha256=<HASH>
user-stories.md sha256=<HASH>
SKILL.md sha256=<HASH>
reference.md sha256=<HASH>
packet/README.md sha256=<HASH>
packet/01-user-stories.md sha256=<HASH>
packet/02-acceptance-criteria.md sha256=<HASH>
packet/03-user-roles-personas.md sha256=<HASH>
packet/04-open-questions-assumptions.md sha256=<HASH>
packet/05-known-risks.md sha256=<HASH>
omissions: none
```

Hashes are uppercase hex. Omission entries are semicolon-separated, each starting with the omitted ID, reason in parentheses, e.g., `omissions: US-31 (left out per user decision 2026-06-08)`. ID forms: US-NN, UC-NN, OQA-NN, or RISK-N, where RISK-N counts the charter's risk bullets top to bottom (risks have no IDs of their own). The file lives outside the packet so the deliverables carry no machine state.

## Verification

Split between a deterministic script and judgment checks. Every count compares against the current sources.

**Deterministic: `python .claude/skills/generate-requirements-packet/validate.py` from the workspace root** (on this machine `python` is not on PATH; use `py`). Python standard library only. It checks:

- All six packet files exist.
- All eleven stored hashes match the files on disk (sources unchanged, spec unchanged, no hand edits).
- 01 and 02 contain exactly the source's stories, same IDs, same source order, minus recorded omissions.
- Per-story scenario counts in 02 match the source, minus omissions.
- The role table in 03 covers every source story exactly once, minus omissions.
- The risk row count in 05 matches the charter's risks section, minus omissions.
- Attribution lines 3-5 byte-identical across all six files.
- Zero non-ASCII characters and zero HTML comments in the packet.
- No forbidden tooling words in the packet, matched on word boundaries, case-insensitive: "claude", "anthropic", "ai", "discord", "github", "skill(s)", "script(s)", and the phrase "google doc(s)". Subtler tooling mentions (e.g., "generation") are covered by the judgment checks.
- No markdown links anywhere in the packet.
- Informational only: row count in 04 versus assumption parentheticals in the use cases and marker notes in the stories, to judge 04's completeness by hand.

**Judgment checks, performed by the skill after the script passes:**

- Every open question and assumption from the source notes appears in 04, deduplicated per the affected-items rule; nothing flagged that the sources treat as settled; no known exception raised as a new item.
- Settled-rule notes sit in 02 with the right story; dropped traceability notes and generalized references are each listed in the run report.
- Carried wording matches the source apart from the three mechanical changes; suspected malformations are listed as FYIs.
- Connecting prose follows "Deliverables only".
