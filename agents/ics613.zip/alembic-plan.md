# Add Alembic migrations to ICS613_Summer2026_FinalProject_Team4

## Scope

This is a plan for `ICS613_Summer2026_FinalProject_Team4`, not for the parent
folder that holds this planning file.

Run every command below from:

```sh
cd ICS613_Summer2026_FinalProject_Team4
```

## Context

The team project uses FastAPI, SQLAlchemy 2.0, PostgreSQL 18.4 in Docker, and
uv for backend dependencies. It currently creates tables with
`Base.metadata.create_all()` inside `backend/app/seed.py`. That call can create
missing tables, but it cannot apply incremental schema changes. When someone
edits a model, teammates need a recorded migration they can run.

Assumption confirmed with the user: no one has a database, tables, or data yet.
There is no pre-Alembic baseline problem for the first rollout. The first
migration creates the existing `sample_data` table.

If that assumption becomes false before this plan is implemented, do not run the
baseline migration against an existing pre-Alembic database that already has
`sample_data`. Choose one of these paths instead:

- If local data can be discarded, run `npm run db:reset`, then continue with
  the normal first-time workflow.
- If local data must be kept, verify that the existing schema matches the
  baseline migration, then run `uv run --locked --directory backend alembic stamp head`.

## Requirements

1. Alembic installs via `npm run setup`, so it must be a locked backend
   dependency. `uv sync --locked` must install it.
2. `npm run db:migrate` brings an empty database or an Alembic-managed stale
   database to the latest schema with `alembic upgrade head`.
3. Pre-Alembic databases are handled by reset or stamp, not by blindly running
   the baseline migration.
4. New code follows the project's beginner-friendly style: explicit control
   flow, plain if/else, double-quoted Python strings, and ASCII prose.
5. Keep the setup minimal. Stock Alembic behavior is fine wherever it works.

## Design decisions

- Location: `backend/alembic.ini` and `backend/migrations/`. Alembic is a
  backend concern. `uv run --directory backend` sets the working directory
  there.
- Path handling: `script_location = %(here)s/migrations`,
  `prepend_sys_path = %(here)s`, and `path_separator = os` are required
  together. `path_separator = os` matters on Windows because paths such as
  `C:\Users\...` contain a colon.
- Database URL: `migrations/env.py` imports the existing `engine` from
  `app.db`. No database URL is stored in `alembic.ini`. This keeps `.env`
  loading, default values, and SQLAlchemy `URL.create()` escaping in one place.
  Importing the engine does not connect to the database.
- Autogenerate: `target_metadata = Base.metadata`. `backend/app/models/__init__.py`
  imports every model module so `import app.models` registers all tables.
  Future model modules must be added there.
- `seed.py`: remove `Base.metadata.create_all(engine)`. Migrations become the
  only normal path for table creation. The seed script inserts demo data only.
- Tests: SQLite seed tests must create their own test schema. They cannot rely
  on `seed.py` after `create_all()` is removed.
- `script.py.mako` stays as generated. Stock Alembic renders single-quoted
  strings; edit generated migration files to double quotes before committing.
- CI: keep the current unit-test workflow. It has no PostgreSQL service and the
  backend tests use SQLite. A future CI change can add a PostgreSQL service and
  run `alembic upgrade head` as a smoke test.

## Steps

### 1. Add the dependency

Run from `ICS613_Summer2026_FinalProject_Team4`:

```sh
uv add --directory backend "alembic>=1.16,<2.0"
```

This edits `backend/pyproject.toml` and regenerates `backend/uv.lock`. Do not
edit the lock file by hand.

Verify:

```sh
npm run setup
uv run --locked --directory backend alembic --version
```

### 2. Scaffold Alembic

```sh
uv run --locked --directory backend alembic init migrations
```

This creates:

- `backend/alembic.ini`
- `backend/migrations/README`
- `backend/migrations/env.py`
- `backend/migrations/script.py.mako`
- `backend/migrations/versions/`

Rewrite `alembic.ini`, `env.py`, and `README` as described below. Leave
`script.py.mako` as generated.

### 3. Update `backend/alembic.ini`

Keep the generated logging sections. Trim unrelated sample comments, but keep
these Alembic settings:

```ini
# Alembic settings. The database URL is not stored here. migrations/env.py
# reuses the engine from app/db.py so the root .env file keeps working.

[alembic]
# %(here)s is the folder that holds this file, backend/.
script_location = %(here)s/migrations

# Put backend/ on the import path so env.py can import app.
prepend_sys_path = %(here)s

# Use the operating system path separator. This is required for Windows paths.
path_separator = os
```

Do not keep `sqlalchemy.url`; `env.py` does not read it.

### 4. Update `backend/migrations/env.py`

Use an online-only env file. Alembic should fail with a clear message if someone
tries offline SQL generation.

```python
# Alembic runs this file for every migration command. It connects to the
# database with the same settings as the app and tells Alembic which
# tables the models define, so autogenerate can compare them.

from logging.config import fileConfig

from alembic import context

# Importing app.models registers every table on Base.metadata.
# Without this import, autogenerate would think no tables exist.
import app.models  # noqa: F401
from app.db import engine
from app.models.base import Base

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata

if context.is_offline_mode():
    raise RuntimeError("Offline mode is not used in this project. Run without --sql.")

connection = engine.connect()
try:
    context.configure(connection=connection, target_metadata=target_metadata)
    with context.begin_transaction():
        context.run_migrations()
finally:
    connection.close()
```

### 5. Update `backend/app/models/__init__.py`

```python
# Import every model module here so that importing app.models registers
# all tables on Base.metadata. Alembic autogenerate depends on this.
# When you add a new model file, add it to this list.

from app.models.base import Base
from app.models.sample_data import SampleData

__all__ = ["Base", "SampleData"]
```

### 6. Update `backend/app/seed.py`

- Remove `Base.metadata.create_all(engine)`.
- Remove the now-unused `engine` and `Base` imports.
- Update the header comment: tables are created by migrations; run
  `npm run db:migrate` first.
- Update the failure hint to mention `npm run db:migrate` before
  `npm run db:seed`.

### 7. Update SQLite seed tests

`backend/tests/test_seed.py` currently depends on `seed.py` creating the
schema. After `create_all()` moves out of `seed.py`, the test setup must create
its own schema. Also read the whole test file: remove or rewrite any test that
asserts `seed_database()` creates tables, because that behavior no longer
exists.

Update the helper like this:

```python
from app.models.base import Base
```

```python
def set_sqlite_seed_database(monkeypatch):
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine)
    monkeypatch.setattr(seed, "SessionLocal", session_factory)
    return session_factory
```

Do not monkeypatch `seed.engine`, because `seed.py` no longer imports it.

### 8. Update root `package.json`

Add migration scripts next to the existing database scripts. Also make
`db:up` wait until PostgreSQL is healthy, so `db:migrate` cannot run before the
database accepts connections.

```json
"db": "docker compose up db",
"db:up": "docker compose up -d --wait db",
"db:down": "docker compose down",
"db:reset": "docker compose down --volumes",
"db:migrate": "uv run --locked --directory backend alembic upgrade head",
"db:revision": "uv run --locked --directory backend alembic revision --autogenerate -m",
"db:seed": "uv run --locked --directory backend python -m app.seed"
```

`db:revision` usage:

```sh
npm run db:revision -- "add users table"
```

If quoting fails in a shell, use a hyphenated message:

```sh
npm run db:revision -- add-users-table
```

### 9. Generate the baseline migration

Generate the baseline from an empty database, not from a database where the old
seed script already created `sample_data`.

```sh
npm run db:reset
npm run db:up
npm run db:revision -- "create sample_data table"
```

Review the generated file in `backend/migrations/versions/`. It must contain:

- `op.create_table("sample_data", ...)` with a unique constraint on `slug`
- `op.drop_table("sample_data")` in `downgrade()`

Alembic renders single-quoted strings. Edit the generated migration before
committing it so Python strings use double quotes and comments use plain
project wording.

If the generated migration is empty, the database was not empty. Reset the
database and generate it again.

Commit the migration file. This is revision 1 for the team.

### 10. Update `backend/migrations/README`

Keep this file short:

```text
Alembic migration files live in versions/.

Run migrations from the project root:

npm run db:migrate

When a model changes, generate a revision, review it, run it, and commit it
with the model change.
```

### 11. Update `README.md`

- Development database workflow:
  - First time and after every pull: `npm run db:up`, then
    `npm run db:migrate`.
  - Seed demo rows after migrations: `npm run db:seed`.
- Scripts table:
  - Add `db:migrate`: apply new database migrations.
  - Add `db:revision`: create a new migration after model changes.
  - Reword `db:seed`: insert demo data. It no longer creates tables.
- Schema change workflow:
  - Edit or add a model in `app/models/`.
  - Register new model modules in `app/models/__init__.py`.
  - Run `npm run db:revision -- "message"`.
  - Read the generated migration before trusting it, and edit generated strings
    to double quotes before committing.
  - Run `npm run db:migrate`.
  - Commit the migration file with the model change.
- Troubleshooting:
  - Reset flow becomes `npm run db:reset`, `npm run db:up`,
    `npm run db:migrate`, `npm run db:seed`.
  - Mention that Alembic stores the current migration in `alembic_version`.
- Project structure:
  - Add `backend/alembic.ini`.
  - Add `backend/migrations/`.
  - Update the `seed.py` description.

## Files created or modified

Create:

- `backend/alembic.ini`
- `backend/migrations/README`
- `backend/migrations/env.py`
- `backend/migrations/script.py.mako` (created by `alembic init`, left as
  generated)
- `backend/migrations/versions/<rev>_create_sample_data_table.py`

Modify:

- `backend/pyproject.toml` and `backend/uv.lock`, through `uv add`
- `backend/app/models/__init__.py`
- `backend/app/seed.py`
- `backend/tests/test_seed.py`
- `package.json`
- `README.md`

## Verification

1. `npm run setup` succeeds.
2. `uv run --locked --directory backend alembic --version` prints the Alembic
   version.
3. `npm run db:reset`, then `npm run db:up` starts PostgreSQL and waits for it.
4. `npm run db:migrate` creates `alembic_version` and `sample_data`.
5. `npm run db:seed` inserts the 3 demo rows.
6. `npm run backend`, then hit the sample endpoint and confirm rows are returned.
7. `npm run db:revision -- "noop check"` against the migrated database creates
   an empty upgrade and downgrade. Delete that generated file.
8. `npm run lint` passes.
9. `npm test` passes.
10. Repeat `npm run db:reset`, `npm run db:up`, and `npm run db:migrate`. The
    same migration command must rebuild the schema from an empty database.

## Risks

- Alembic or one of its dependencies may not resolve on Python 3.14. This
  should fail at `uv add` or `npm run setup`.
- Hand-editing `pyproject.toml` without regenerating `uv.lock` breaks
  `uv sync --locked`. Use `uv add`.
- Autogenerate only sees models imported by `app/models/__init__.py`. The README
  workflow and the no-op revision check reduce that risk.
- `docker compose up -d --wait db` requires a Docker Compose version that
  supports `--wait`. Docker Desktop should provide it. If a teammate has an
  older Compose version, add a separate wait command that runs `pg_isready`
  inside the database container.
- The first migration assumes an empty database. Existing pre-Alembic databases
  need reset or `alembic stamp head` after schema verification.
