---
name: reconcile-use-cases
description: Reconcile and align the backup high-level use cases (ics613-research/artifacts/use-cases.md) with the read-only current-state use cases for the ICS 613 Local Produce Exchange project. Use when the user asks to reconcile, sync, align, refresh, update, or backfill the backup use-cases document against the current state, or to keep the backup use cases ready for an 11th-hour submission. Reads the current-state use cases but never modifies them; edits only the backup use-cases document.
---

# Reconcile Use Cases

## What this skill does

The user is on a five-person team in ICS 613 (Advanced Software Engineering). One deliverable is a high-level use cases document. There are two copies:

- The **current-state use cases** is the shared team document at `ics613-research/current-state/current-state-use-cases.md`. The team maintains it. It is a deliberately narrowed current-scope slice.
- The **backup use cases** is the user's own complete version at `ics613-research/artifacts/use-cases.md`, kept in case the team contributes nothing and the user must submit something on their own to protect their grade.

The plan: near the deadline, if the team still has not contributed, the user copies content from the finished backup into the current-state document by hand. The skill's job is to keep the backup complete and aligned closely enough to the current-state document that this manual backfill is a quick pass, not a fresh analysis or rewrite.

**Important difference from the team charter.** The two use-case documents are NOT parallel copies of the same thing, the way the two charters were. The backup is the full plan; the current-state document is a smaller, differently-modeled slice. So this skill does NOT blindly merge current-state into the backup. It keeps the backup as the full, requirements-faithful plan and maintains an explicit mapping (Section 8 of the backup) that lines the two up by goal and flags the differences. Merging current-state's narrower-model use cases into the backup would make the backup contradict itself, which the use-case template's own quality bar forbids.

## Files

- Backup use cases, the ONLY file this skill may edit:
  `ics613-research/artifacts/use-cases.md`
- Current-state use cases, strictly READ ONLY:
  `ics613-research/current-state/current-state-use-cases.md`
- Use case template, reference for the field format and quality bar:
  `ics613-research/templates/use-case-template.md`
- Course requirements, reference for roles, the claim lifecycle, and business rules:
  `ics613-research/requirements.md`

For project context, the goal-based mapping, and the settled decisions, read `reference.md` in this skill folder.

## Hard rules (do not break these)

1. **Never modify the current-state document.** Treat it as read-only. Read it, never write to it. The user does all backfilling into current-state by hand.
2. **Only modify the backup document** at `ics613-research/artifacts/use-cases.md`.
3. **Never lose a team contribution.** Everything in the current-state document counts as real team work. Because the two documents use different models, you preserve current-state's contributions by referencing them in the backup's mapping section, not by merging contradictory use cases into the backup.
4. **Do not inject current-state's narrower-model use cases into the backup as duplicates.** That would make the backup contradict itself.
5. **Flag and ask on anything significant.** If current-state has changed, if a new current-state use case has no backup counterpart, or if the model, role, or scope conflict shifts, stop, explain it, give a suggestion, and ask.

## The four differences to expect

1. **Scope.** The backup is the full plan (UC-01 through UC-24). Current-state is a smaller slice (its own UC-01 through UC-12) that omits listing creation and editing, pickup and completion, reviews, the dashboard, admin, and notifications on purpose, and uses seeded listings.
2. **Model.** The backup uses the full claim lifecycle (REQUESTED, APPROVED, PICKED_UP, COMPLETED, plus DENIED and CANCELLED), which the requirements call for. Current-state uses a request-queue model that stops at approve or deny.
3. **Role name.** The backup calls the requester Claimant (matches the requirements) and includes an Admin role. Current-state calls that role Recipient and has no Admin.
4. **Numbering.** The use case numbers do not match between the two documents, except for the five account use cases (UC-01 through UC-05). Match by goal, never by number.

## Procedure

1. **Read all four files** above, plus `reference.md` in this folder. Read current-state fresh every time, since the team may have changed it.

2. **Keep the backup as the full plan.** Do not delete its use cases, and do not change its claim-lifecycle model or its Claimant role unless the user says so. These are the settled defaults (see below).

3. **Keep the account use cases in sync.** UC-01 through UC-05 should read the same in both documents. If current-state changed one of them, carry that wording into the backup.

4. **Maintain the mapping (Section 8 of the backup).** It has three parts: a table mapping each current-state use case to its backup counterpart by goal with a note on the difference; a list of backup use cases that are not in the current scope; and the open decisions. Update all three if current-state changed. If current-state added a use case with no backup twin (for example, its standalone view-the-queue use case), record it in the mapping and flag it.

5. **Match by goal, not by number.** UC-08 means different things in each document.

6. **Write the backup, then report.** If current-state has not changed since the last reconciliation, say so and do not churn the file.

## Handling structural changes in current-state

The current-state document's structure can change as the team works: a teammate may add, remove, reorder, or rename a section, regroup items, or change a table's columns or rows. The skill must handle structural changes, not just content changes. Every run, after reading current-state fresh, check whether its structure changed since the backup was last aligned. When it did, reshape the backup to follow current-state's current structure, because the whole point is that the user can backfill into current-state by hand at the 11th hour without a fresh analysis. A teammate's structural change is itself a real contribution, so never ignore or discard it. If a structural change is large or its intent is unclear, do not guess; stop and ask the user how to handle it.

Because the backup is the full plan and current-state is a narrower, differently-modeled slice, the backup cannot become identical to current-state, and should not try to. Handle structure at two levels:

- Shared document skeleton (the top-level sections and their order, such as the introduction, actors, the grouped items, the master list, the coverage tables, and the assumptions). Mirror it: if the team adds, removes, reorders, or renames a top-level section in current-state, make the same change in the backup and keep the backup's fuller content inside it.
- Item groupings and numbering (which items sit in which group, and their IDs). These differ on purpose, so do not copy them. Instead keep the mapping section current: if current-state regroups, renumbers, renames, or adds items, update the mapping so every current-state item still points to its backup counterpart by goal, and flag any current-state item that has no backup counterpart.

The mapping is what keeps the manual backfill quick, so it must always reflect current-state's current structure.

## When something does not reconcile cleanly

If you ever hit a reconciliation problem, do not guess and do not silently resolve it. Problems include, but are not limited to: a real conflict between the two documents, drift where they have diverged, information that overlaps or is duplicated, an item in one document with no counterpart in the other, a structural change you are unsure how to mirror, or anything ambiguous. When this happens:

1. Stop.
2. Tell the user the problem in plain terms.
3. Give two or more concrete options for resolving it.
4. Recommend one of them.
5. Ask the user what to do before making the change.

Judge every option, and pick the recommendation, by one yardstick: which choice keeps the user's manual 11th-hour backfill easiest. That goal comes first, ahead of tidiness or completeness. Only continue once the user has decided.

## Settled defaults (the path the user chose)

- Backup scope: the full plan, 24 use cases.
- Core model: the full claim lifecycle (requirements-faithful).
- Requester role: Claimant.

These are defaults the user approved. They can change any of them; if they do, update the backup and the mapping to match.

## Things that stay as-is or as placeholders

- "Related user stories: TBD" stays throughout, because the user stories are a later deliverable.
- The assumptions and open-questions tables, and the non-use-case commitment tables.

## How to report back

After writing the backup, give the user a short, scannable summary with these groups:
- **Synced from current-state:** anything you carried into the backup (for example, an account use case the team edited).
- **Mapping updates:** what changed in Section 8.
- **Decisions that need the user:** the model, role, and scope questions, or any new conflict, each with a suggestion and a clear question.
- **Minor calls you made:** small choices the user can reverse.
- **Still placeholders:** the TBD items above.

End by confirming the backup is the full plan, is mapped to the current scope by goal, and is ready for a quick manual backfill if it is ever needed.

## Writing style (matches the project CLAUDE.md)

- ASCII characters only. No em dashes, en dashes, curly quotes, ellipsis characters, or emojis. Use straight quotes and plain punctuation. Do not use a pair of hyphens as a dash. Use hyphens only for real compound words.
- Plain, layman-friendly prose. Short, direct sentences.
- Keep each use case high level and follow the field format in the use case template.
