# Reconcile Use Cases: project context and decisions

This file holds background and the reconciliation decisions already agreed with the user, so a future run stays consistent. These are starting points and defaults; the user can override any of them.

## Project context

- Course: ICS 613, Advanced Software Engineering, Summer 2026.
- Team: Team 4, five members. The user is Jeff Wu.
- Project: Local Produce Exchange. An invite-only web app where a trusted community shares surplus food. Members post listings, others request or claim a quantity, and the two coordinate pickup through a private message thread.
- Stack: React and TypeScript front end; Python with FastAPI, SQLAlchemy, and Pydantic for the backend; PostgreSQL for the database.
- The use cases are part of the Core Requirements for the inception deliverable, due early June 2026. The "11th hour" means just before that deadline.
- This skill is one of three siblings: reconcile-team-charter, reconcile-use-cases, and reconcile-user-stories. All three share the same goal and the same hard rules; only the reconciliation mechanics differ, because the documents differ.

## The two documents

- Backup, the full plan, the only file the skill edits: `ics613-research/artifacts/use-cases.md`. 24 use cases (UC-01 through UC-24). Full claim lifecycle. Roles: Guest, Member, Poster, Claimant, Admin.
- Current-state, the current-scope slice, read-only: `ics613-research/current-state/current-state-use-cases.md`. 12 use cases (its own UC-01 through UC-12). Request-queue model. Roles: Guest, Member, Poster, Recipient.

## The four differences

1. Scope: full plan (24) versus current slice (12). The slice omits listing create/edit/deactivate, pickup, completion, reviews, dashboard, admin, notifications, and photos; it uses seeded listings.
2. Model: full claim lifecycle (backup, requirements-faithful) versus request queue that stops at approve or deny (current-state).
3. Role name: Claimant plus Admin (backup) versus Recipient and no Admin (current-state).
4. Numbering: does not match except for the five account use cases. Match by goal.

## Goal-based mapping (current-scope UC to full-plan UC)

This is the mapping kept in Section 8 of the backup.

| Current-scope UC | Full-plan UC | Note |
| --- | --- | --- |
| UC-01 Register with an invite token | UC-01 | Same |
| UC-02 Log in | UC-02 | Same |
| UC-03 Log out | UC-03 | Same |
| UC-04 Invite a new member | UC-04 | Same; same open question about who may invite |
| UC-05 Manage member profile | UC-05 | Same |
| UC-06 Browse, search, and filter active listings | UC-09 | Same goal, different number |
| UC-07 View listing details | UC-10 | Same goal; full plan also shows photos |
| UC-08 Submit a request for an item (Recipient) | UC-11 Claim produce (Claimant) | Same core goal; current-scope adds queue placement and a duplicate-request guard; role name differs |
| UC-09 View the request queue for a listing (Poster) | No direct equivalent | Nearest is UC-14 and UC-20; the queue model would need a view-queue use case added to the full plan |
| UC-10 Approve or deny the next request in the queue (Poster) | UC-14 | Same goal; current-scope handles in queue order |
| UC-11 Withdraw a queued request (Recipient) | UC-13 Cancel a claim (Claimant) | Same goal; current-scope allows only REQUESTED, full plan allows REQUESTED or APPROVED; role differs |
| UC-12 Send and read messages in the exchange thread | UC-16 | Same goal, different number and name |

## In the full plan but not in the current scope

UC-06 Create a listing, UC-07 Edit a listing, UC-08 Deactivate own listing, UC-12 Confirm pickup, UC-15 Complete an exchange, UC-17 View status notifications, UC-18 Leave a rating and review, UC-19 View reviews, UC-20 View dashboard, UC-21 Suspend a user, UC-22 Deactivate a listing as admin, UC-23 Generate basic reports, UC-24 View pickup reminders (stretch).

## Settled decisions (the recommended path the user chose)

- Scope: keep the backup as the full plan.
- Model: keep the full claim lifecycle (requirements-faithful).
- Role: keep Claimant.

## Open questions still on the table

- Model: is the queue model only the current iteration, or is it meant to replace the lifecycle? The second case conflicts with requirements.md:33 and should go to the team or instructor.
- Role name: Claimant or Recipient as the team's official term.
- Scope: does the team commit to the full plan or the current slice?
- The standalone view-the-queue use case (current-state UC-09) has no full-plan twin. If the queue model stays, the full plan needs one added.

## Reminder

These are starting points from earlier sessions. Read both live documents every time. If current-state has changed, preserve every team contribution by mapping it, and flag anything new that conflicts with these defaults.
