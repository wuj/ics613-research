# Reconcile User Stories: project context and decisions

This file holds background and the reconciliation decisions already agreed with the user, so a future run stays consistent. These are starting points and defaults; the user can override any of them.

## Project context

- Course: ICS 613, Advanced Software Engineering, Summer 2026.
- Team: Team 4, five members. The user is Jeff Wu.
- Project: Local Produce Exchange. An invite-only web app where a trusted community shares surplus food. Members post listings, others request or claim a quantity, and the two coordinate pickup through a private message thread.
- The user stories are part of the Core Requirements for the inception deliverable, due early June 2026. The course requires 25 to 30 user stories. The "11th hour" means just before that deadline.
- This skill is one of three siblings: reconcile-team-charter, reconcile-use-cases, and reconcile-user-stories. All three share the same goal and the same hard rules; only the reconciliation mechanics differ, because the documents differ.

## The two documents

- Backup, the full plan, the only file the skill edits: `ics613-research/artifacts/user-stories.md`. 25 stories (US-01 through US-25). Full claim lifecycle. Roles: Guest, Member, Poster, Claimant, Admin. Traces to the full-plan use cases.
- Current-state, the current-scope slice, read-only: `ics613-research/current-state/current-state-user-stories.md`. 12 stories (its own US-01 through US-12). Request-queue model. Roles: Guest, Member, Poster, Recipient. Traces to the current-scope use cases.

## The four differences

1. Scope: full plan (25, inside the required 25 to 30) versus current slice (12). The slice omits listing create/photos/edit/deactivate, pickup, completion, reviews, dashboard, admin, notifications, and the stretch reminder; it uses seeded listings.
2. Model: full claim lifecycle (backup, requirements-faithful) versus request queue that stops at approve or deny (current-state).
3. Role name: Claimant plus Admin (backup) versus Recipient and no Admin (current-state).
4. Numbering: does not match except for the five account stories. Match by goal.

## Goal-based mapping (current-scope US to full-plan US)

This is the mapping kept in Section 7 of the backup.

| Current-scope US | Full-plan US | Note |
| --- | --- | --- |
| US-01 Register with an invite token | US-01 | Same |
| US-02 Log in | US-02 | Same |
| US-03 Log out | US-03 | Same |
| US-04 Invite a new member | US-04 | Same; full plan R2, current scope R1; same invite-issuer open question |
| US-05 View and update member profile | US-05 | Same; full plan R2, current scope R1 |
| US-06 Browse, search, and filter active listings | US-10 | Same goal, different number |
| US-07 View listing details | US-11 | Same goal; full plan also shows photos |
| US-08 Submit a request for an item (recipient) | US-12 Submit a claim (claimant) | Same core goal; current scope adds queue placement and a duplicate-request scenario; role differs |
| US-09 View the request queue for a listing (poster) | No direct equivalent | Nearest is US-15 and US-21; the queue model would need a view-queue story added to the full plan |
| US-10 Approve or deny the next request in the queue (poster) | US-15 | Same goal; current scope handles in queue order |
| US-11 Withdraw a queued request (recipient) | US-13 Cancel a claim (claimant) | Same goal; current scope allows only REQUESTED, full plan allows REQUESTED or APPROVED; role differs |
| US-12 Send and read messages in the exchange thread | US-17 | Same goal, different number |

## In the full plan but not in the current scope

US-06 Create a listing, US-07 Add and manage photos, US-08 Edit a listing, US-09 Deactivate own listing, US-14 Confirm pickup, US-16 Complete an exchange, US-18 View status notifications, US-19 Leave a rating and review, US-20 View reviews, US-21 View dashboard, US-22 Suspend a user, US-23 Deactivate a listing as admin, US-24 Generate basic reports, US-25 View pickup reminders (stretch).

## Settled decisions (the recommended path the user chose)

- Scope: keep the backup as the full plan (25 stories, inside the required 25 to 30).
- Model: keep the full claim lifecycle (requirements-faithful).
- Role: keep Claimant and Admin.

## Open questions still on the table

- Model: is the queue model only the current iteration, or is it meant to replace the lifecycle? The second case conflicts with requirements.md:33 and should go to the team or instructor.
- Role name: Claimant or Recipient as the team's official term.
- Scope: does the team commit to the full plan or the current slice?
- Milestones: the current scope puts all 12 stories in R1; the backup spreads across R1, R2, and a stretch.
- The standalone view-the-queue story (current-state US-09) has no full-plan twin. If the queue model stays, the full plan needs one added.

## Reminder

These are starting points from earlier sessions. Read both live documents every time. If current-state has changed, preserve every team contribution by mapping it, and flag anything new that conflicts with these defaults.
