# Reference: review report generation spec

This file holds the full spec for generating the three review outputs. Everything here is a derivation rule applied to the incoming packet as it exists at run time. Where an example names specific IDs, counts, or wording, it is a dated example, never a target; re-derive from the current incoming files every run.

## Attribution block

All three outputs open with the same attribution block, byte-for-byte identical except for the document title on the first line. The block occupies lines 3 through 6 of every file: line 1 is the title, line 2 is blank, lines 3 to 6 are the attribution. validate.py compares those exact lines.

```
# <Document title>

**Team:** Team 4 | Local Produce Exchange, "Surplus"\
**Course:** ICS 613 Software Engineering | University of Hawai'i at Manoa | Summer 2026\
**Members:** Kennan Kaneshiro, Shea Stevens, Matt Ong, Kim Cates, Jeff Wu\
**Reviewed team:** <reviewed-team value from source-state.txt>
```

- Lines 3, 4, and 5 end with a single backslash, the markdown hard line break, so the four lines render one per line instead of collapsing into one paragraph. Line 6 has no trailing backslash.
- Lines 3 to 5 are the packet skill's pinned constants; only the trailing backslash on line 5 is new here (the sibling's block ends at the members line, this one adds the reviewed-team line below it).
- The school name uses the ASCII spelling: straight apostrophe in "Hawai'i", no macron in "Manoa". The official spelling uses non-ASCII characters, which the project's ASCII-only rule forbids.
- These facts come from the title slide of the Project Initiation Presentation PDF and are pinned constants here. If the user says the team facts changed, update this block in this file first, then regenerate; that edit changes this file's hash, which triggers the rebuild.

Document titles:

- `Requirements Review Report`
- `Findings Log`
- `Requirements Review Presentation Outline`

## Reviewed-team identity rule

The reviewed team is identified from the packet content when stated (a cover page, document headers, file names). When the packet does not state it, carry forward the `reviewed-team:` line from the prior state file. When neither exists, pause and ask the user.

Record the identity in `source-state.txt` as `reviewed-team: Team N | <their project name>`, or whatever identification is available, so regeneration is deterministic. If a later run finds packet content contradicting the recorded identity, pause and ask (SKILL.md pause condition 4).

## Deliverables-only rules and the quoting rule

The report alone is fully external:

- No markdown links.
- No file names and no ".md" mentions. Their documents are named by content ("the user stories document"). See the report spec for the allowed location forms.
- No HTML comments and no machine state.
- No mention of the findings log, the presentation outline, or any internal document. The report never says more detail exists elsewhere.

Forbidden words, two tiers:

- **Tier 1, never allowed in the report, no exemption** (words that only describe our tooling, never a requirement of theirs): skill, skills, script, scripts. If a needed quote contains one, paraphrase around it and note that in the run report.
- **Tier 2, allowed in the report only inside quoted or directly referenced packet content, and only when recorded on the state file's `quoted-words:` line**: ai, claude, anthropic, codex, openai, chatgpt, copilot, github, discord, and the phrase "google doc(s)". Rationale: the reviewed team's requirements may legitimately involve these products and services (an AI feature, GitHub login, a ChatGPT integration), and a scope-risk finding must be able to name the service it judges risky. The recorded list keeps every exemption explicit and mechanically checkable (the standard library cannot extract PDF text, so "exempt if present in their files" is not checkable; the recorded list is).

The findings log and the presentation outline are internal: they keep ASCII-only, the attribution block, no HTML comments, and no markdown links, but they are exempt from the forbidden-words and ".md"/file-name checks, because precise citation requires the incoming file names.

All quoted packet text gets the sibling skill's three mechanical changes, so the ASCII check stays absolute:

1. **Markdown escaping repairs**: `PICKED_UP` not `PICKED\_UP`, plain hyphens not `\-`.
2. **ASCII normalization**: curly quotes and apostrophes become straight quotes. A long dash (em or en) becomes the nearest meaning-preserving ASCII punctuation: a comma, a colon, parentheses, or a sentence break; never a hyphen or a double hyphen. No word changes.
3. **Minimal generalization of internal references**: quoted text pointing at the other team's internal tooling or course documents is trimmed minimally when carrying it verbatim would break the report's external-facing rules.

Every normalization or generalization applied is listed in the run report.

## Inventory step

List and read every file in `ics613-research/peer-review/incoming-packet/` in full. Map each file (and each section, for combined documents) to the five required items plus one recognized optional item:

1. User stories
2. Acceptance criteria
3. User roles/personas
4. Open questions and assumptions
5. Known risks
6. Domain model (optional; the assignment calls it nice-to-include)

One file may cover several items; several files may cover one item.

- A required item covered nowhere becomes a finding: Category Missing case, Severity High, Location "not present in the packet", Quote "none (item absent from the packet)".
- A domain model, when present, is never odd content and never a pause: it feeds the consistency lens below. Its absence is never a finding, because it is optional.
- Consistent duplicate coverage (two files covering the same item without conflict): review the union.
- Conflicting duplicates with no version cue: pause (SKILL.md pause condition 5).

The inventory table (file, items covered, ID scheme observed) goes in the run report, never in an output.

## Review methodology

The assignment suggests five review lenses. This skill runs seven, adding checks for the two packet items the suggestions skip (open questions/assumptions and known risks), so every required packet item gets judged, not just inventoried.

1. **User stories**: Is the actor explicit? Is the wanted behavior observable? Is the benefit stated? Does the story describe what, not how? Is it small enough to test?
2. **Acceptance criteria**: Do they exist at all? Are they in testable form (Given/When/Then or equivalent)? Is there at least one failure or rejection path where the story has a failure mode (read-only or purely informational stories may not need one; do not flag those)? Are boundaries and quantities concrete enough to decide done? Do any criteria contradict the story statement?
3. **Roles/personas**: Build their role list; compare against the assignment baseline (member, owner/poster, admin, guest); check role-to-story coverage; flag roles with no stories, stories with no clear role, and permission rules with no enforcing scenario.
4. **Edge cases**: A domain-seeded checklist adapted to THEIR domain: permissions and unauthorized access, empty states, concurrency and double-claim races, lifecycle and illegal status transitions, cancellation windows, account suspension effects on in-flight items, data validation (zero or negative quantities, past dates), notification failure paths.
5. **Consistency**: Cross-story contradiction scan (conflicting rules, terminology drift, status-name mismatches between documents); dependency scan (a story relying on a feature, entity, or role nothing in the backlog provides); when a domain model is present, cross-check it both ways: entities and relationships the stories rely on appear in the model, and model elements no story touches are noted as possible scope or gap signals.
6. **Open questions and assumptions**: Is each item specific and tied to identifiable stories or use cases? Does any assumption hide a decision that blocks implementation? Are risky assumptions stated without a plan to confirm them? Are obvious unknowns absent from the list entirely?
7. **Known risks**: Is each risk concrete, with a mitigation that names an action rather than an intention? Do the risks cover the project's apparent technical and schedule exposure, or are evident risks missing (judged against the scope-risk checklist below)?

Scope-risk checklist (concrete detection cues, adapted to THEIR domain): external integrations and third-party services, authentication complexity (OAuth, multi-provider login), media upload and storage, real-time features and messaging, email or SMS notifications, payments, unbounded phrasing ("all users", "any report", "every listing" with no limit), unbounded admin or reporting features, and features a story implies but no story in the backlog provides.

Strengths are collected in the same pass: concrete testable criteria, well-bounded scope, complete role coverage.

Category mapping: every finding takes exactly one of Strength, Ambiguity, Missing case, Scope risk.

- Contradictions and inconsistencies are Ambiguity.
- Backlog-dependency gaps are Missing case.
- Oversized or technically risky features are Scope risk.
- Weak or missing assumptions and risks map by their nature: an assumption hiding a decision is Ambiguity, a missing risk or unlisted unknown is Missing case, an underestimated feature named by a risk is Scope risk.

Severity:

- **High**: would mislead implementation or break a core flow.
- **Medium**: needs clarification before the affected story is built.
- **Low**: polish or minor wording.
- Strengths take **n/a**.

## Findings log spec

Title `Findings Log`, the attribution block, one short intro line, then one block per finding:

```
### F-NN: <short title>
- Category: <Strength | Ambiguity | Missing case | Scope risk>
- Severity: <High | Medium | Low | n/a>
- Location: <incoming file name, plus their section heading, their ID, or page number>
- Quote: "<verbatim supporting text, ASCII-normalized>"
- Finding: <one to three plain sentences naming the problem or strength>
- Question: <one clarifying question for the Q&A, or none for strengths>
```

- IDs are sequential from F-01 in log order. Log order groups by category (Strengths, then Ambiguities, then Missing cases, then Scope risks), severity-descending within each category.
- The Quote value may instead be `none (item absent from the packet)` for a missing required item, or `none (coverage: <what was searched and not found, and across which items>)` for an absence finding no single quote can prove (a role with no stories, a missing failure path).
- A contradiction or inconsistency finding carries one quoted segment per conflicting passage, each followed by its location in parentheses, all on the one Quote line; the Location field lists every involved location.
- Exactly six fields, fixed names and order, parseable with plain loops. The validator only requires the Quote value to start with a double quote or "none".

## Report spec

Title `Requirements Review Report`, the attribution block, then exactly five `## ` sections in order: Summary, Strengths, Ambiguities, Missing Cases, Scope Risks.

Report prose follows the writing-style rules in SKILL.md: plain, layman-friendly, ASCII-only, written so anyone in the class can follow it without a software background. Methodology terms are translated into everyday phrasing, and any unavoidable technical term is defined in plain words at first use.

- **Summary**: two or three paragraphs: what was reviewed (their documents named by content), the overall impression, and the shape of the findings in prose. No counts that imply a separate log exists.
- **Strengths**: genuine strengths only, never padded; three to five when that many exist, fewer when fewer exist. Each is a short paragraph led by its F-ID in bold (`**F-01:** ...`).
- **Ambiguities / Missing Cases / Scope Risks**: an intro sentence each, then one short block per included finding: `**F-NN, high:** ...` with their ID or location in plain text, the issue, why it matters, and the quote when it earns its space.
- Allowed location forms in the report: a document named by content ("the user stories document"), the other team's section headings and IDs, and page numbers. When their packet holds several similar documents, distinguish by stated title or by order ("the second user stories document"). Only literal file names and ".md" strings stay banned: the ban covers our repo internals and keeps the ".md" check mechanical even when their files are markdown, and the allowed forms keep every citation findable.
- A section with no findings says so in one plain sentence (for example, "The review found no scope risks in this packet.") instead of padding or inventing items.
- **Sizing**: target 1000-1600 body words; hard validator bounds 900-2200 body words (900 is about two pages of content, the assignment's typical minimum). Body words exclude the title line, the attribution block, and heading lines, so scaffolding never counts toward the floor.
- **Inclusion rule, in order**: every High finding appears; then every non-empty category (Strengths included) gets at least its top finding, so no category with findings goes silent; then the remaining budget fills with Medium findings by severity and log order across categories. Low findings stay in the log only. The report never mentions that more detail exists elsewhere.
- **Reaching the floor without padding**: when real findings run short of 900 words, add depth, not filler. Expand the evidence and the consequences of the findings that exist, and give the Strengths section the same evidence-backed treatment as the issues (a strong packet earns specific praise with quotes, not a shorter report). Never invent findings, repeat points, or add filler sentences. If an unusually strong packet still cannot support 900 words of substantive prose, stop and ask the user: deepen further, or lower the floor in this spec (a spec edit changes the hash and triggers regeneration).

## Presentation outline spec

Title `Requirements Review Presentation Outline`, the attribution block, a `Total time: 10 minutes.` line, then sequential `## Slide N: <title>` sections with talking-point bullets and a closing `Time: M:SS` bullet per slide. The slide times must sum to exactly 10:00.

Suggested shape (flexes with the findings):

1. Title and reviewed team (0:30)
2. What we reviewed and how (1:00)
3. Summary impression (1:00)
4. Strengths (1:30)
5. Ambiguities (2:00)
6. Missing cases (2:00)
7. Scope risks (1:00)
8. Questions for the team (0:45; pulls the top Question fields from the findings log, which is allowed because the outline is internal)
9. Closing (0:15)

## Source-state file format

`source-state.txt` in this skill folder, written right after generating and before validating (the validator checks it), and rewritten after any regeneration. Plain lines, no markers:

```
reviewed-team: Team N | <their project name>
items: user-stories=found; acceptance-criteria=found; roles-personas=found; open-questions-assumptions=missing; known-risks=found; domain-model=absent
incoming/<file-1> sha256=<HASH>
incoming/<file-2> sha256=<HASH>
SKILL.md sha256=<HASH>
reference.md sha256=<HASH>
output/requirements-review-report.md sha256=<HASH>
output/findings-log.md sha256=<HASH>
output/presentation-outline.md sha256=<HASH>
quoted-words: none
excluded: none
```

- `incoming/` lines: one per file actually present in the incoming folder, names relative to that folder, sorted case-insensitively. The name-set comparison catches adds, removals, and renames; the hashes catch edits.
- `output/` hashes detect hand edits. validate.py is not hashed: it checks output without shaping it, and it runs on every invocation, including when the review is current.
- `items:`: the inventory verdict, semicolon-separated, one entry per required packet item marked `found` or `missing`, plus `domain-model` marked `present` or `absent` (the optional item; absent is never a finding). This line is the skill's attestation of what the inventory concluded, the same trust model as `quoted-words:`; the validator uses it to confirm missing items became findings.
- `quoted-words:`: `none`, or semicolon-separated tier-2 words carried into the report inside quotes.
- `excluded:`: `none`, or semicolon-separated incoming file names the user chose to skip, reason in parentheses; excluded files are still hashed above so changes re-trigger the decision.
- Hashes are uppercase hex (SHA-256).

## Verification

Run the deterministic validator first, from the workspace root:

```
python .claude/skills/generate-review-report/validate.py
```

On this machine `python` is not on PATH; use `py` instead.

It checks: the incoming folder exists and is non-empty; SKILL.md, reference.md, and all three outputs exist; source-state.txt parses (hash lines, `reviewed-team:`, `items:` naming all five required items, `quoted-words:`, `excluded:`); the incoming name set matches the stored labels in both directions; every stored hash matches disk; the attribution block (lines 3-6) is correct and byte-identical across the three outputs; zero non-ASCII characters; zero HTML comments; zero markdown links; report-only word bans (no ".md", no tier-1 words, no unrecorded tier-2 words); the report has exactly the five sections in order; the findings log blocks parse with sequential IDs and valid fields; report-to-log traceability (every report F-ID exists in the log in the matching category, every High finding appears in the report, every non-empty category is represented); the report body word count sits within 900-2200; the outline's slides are numbered sequentially and their times sum to 10:00; and every `items:` entry marked `missing` has a matching High-severity Missing case finding.

It also prints informational lines that never fail: word count versus the 1000-1600 target, findings counts, log-only Mediums and Lows, `excluded:` and `quoted-words:` entries, outline slide count (suggested 7-12), and a banned-prose scan of all three outputs (the CLAUDE.md banned phrases, hollow intensifiers, and stand-in "thing(s)"), printing each hit with file and line so the judgment pass has a worklist. The scan is informational rather than hard because hits inside quoted packet text are legitimate, and telling quote from prose is a judgment call.

Fix any failure by regenerating correctly, never by editing the incoming files, and rewrite source-state.txt after any regeneration.

Then the judgment checks the script cannot do:

1. Quoted text matches the packet apart from the three mechanical changes; every normalization and generalization is listed for the run report.
2. Categories are assigned sensibly per the category mapping; severities follow the severity rule.
3. No finding prescribes a design or a solution; each names the problem and a clarifying question.
4. The report is self-contained: no reference to the findings log or any internal document, and every included finding readable on its own.
5. Every required item the inventory marked missing appears as a High-severity Missing case finding, and the `items:` line matches what the inventory concluded.
6. A present domain model was used in the consistency lens, both directions.
7. The report and outline prose reads at a general-audience level: everyday words, short sentences, technical terms defined at first use, no methodology shorthand carried verbatim.
8. Every hit from the validator's banned-prose scan is either inside a quote (allowed) or rewritten; the banned phrases, intensifiers, hedges, and stand-in "thing(s)" never appear in our own prose.
