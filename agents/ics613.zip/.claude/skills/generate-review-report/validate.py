"""Validator for the Requirements Review Report outputs.

Run from the workspace root:

    python .claude/skills/generate-review-report/validate.py

(on machines where "python" is not on PATH, use "py" instead)

Checks that the three review outputs (the report, the findings log,
and the presentation outline) match the incoming packet files and the
recorded state in source-state.txt. Uses only the Python standard
library, so it behaves the same under PowerShell, Git Bash, or WSL.

If a check fails, fix it by regenerating the outputs correctly.
Never fix a failure by editing the incoming packet files.

Exit code 0 means every hard check passed. Exit code 1 means at least
one hard check failed, or the outputs are missing.
"""

import hashlib
import os
import sys

# Folder paths, relative to the workspace root.
PEER_REVIEW_DIR = os.path.join("ics613-research", "peer-review")
INCOMING_DIR = os.path.join(PEER_REVIEW_DIR, "incoming-packet")
SKILL_DIR = os.path.join(".claude", "skills", "generate-review-report")
STATE_FILE = os.path.join(SKILL_DIR, "source-state.txt")

REPORT_PATH = os.path.join(PEER_REVIEW_DIR, "requirements-review-report.md")
LOG_PATH = os.path.join(PEER_REVIEW_DIR, "findings-log.md")
OUTLINE_PATH = os.path.join(PEER_REVIEW_DIR, "presentation-outline.md")

# The three outputs: state-file label, path, pinned document title.
OUTPUT_TABLE = [
    ["output/requirements-review-report.md", REPORT_PATH,
     "Requirements Review Report"],
    ["output/findings-log.md", LOG_PATH,
     "Findings Log"],
    ["output/presentation-outline.md", OUTLINE_PATH,
     "Requirements Review Presentation Outline"],
]

# The attribution block, lines 3 to 6 of every output. Lines 3 to 5
# are pinned constants (the packet skill's block, with a trailing
# backslash added to the members line). Line 6 is the prefix plus the
# reviewed-team value from source-state.txt.
ATTRIBUTION_LINE_3 = "**Team:** Team 4 | Local Produce Exchange, \"Surplus\"\\"
ATTRIBUTION_LINE_4 = ("**Course:** ICS 613 Software Engineering |"
                      " University of Hawai'i at Manoa | Summer 2026\\")
ATTRIBUTION_LINE_5 = ("**Members:** Kennan Kaneshiro, Shea Stevens,"
                      " Matt Ong, Kim Cates, Jeff Wu\\")
REVIEWED_TEAM_PREFIX = "**Reviewed team:** "

# Tier-1 words: never allowed in the report, no exemption.
TIER1_WORDS = ["skill", "skills", "script", "scripts"]

# Tier-2 words: allowed in the report only when recorded on the
# state file's quoted-words: line, compared lowercase as whole words.
TIER2_WORDS = [
    "ai",
    "claude",
    "anthropic",
    "codex",
    "openai",
    "chatgpt",
    "copilot",
    "github",
    "discord",
]

# Tier-2 phrases, compared lowercase on word boundaries.
FORBIDDEN_PHRASES = ["google doc", "google docs"]

# Findings log field names, in the required order.
EXPECTED_FIELDS = ["Category", "Severity", "Location", "Quote",
                   "Finding", "Question"]

ALLOWED_CATEGORIES = ["Strength", "Ambiguity", "Missing case", "Scope risk"]
ALLOWED_SEVERITIES = ["High", "Medium", "Low", "n/a"]

# The report's five sections, in order.
REPORT_SECTIONS = ["Summary", "Strengths", "Ambiguities",
                   "Missing Cases", "Scope Risks"]

# The five required packet items, as named on the items: state line.
REQUIRED_ITEMS = [
    "user-stories",
    "acceptance-criteria",
    "roles-personas",
    "open-questions-assumptions",
    "known-risks",
]

# Report body word bounds. The hard bounds fail; the target is
# informational.
WORD_FLOOR = 900
WORD_CEILING = 2200
WORD_TARGET_LOW = 1000
WORD_TARGET_HIGH = 1600

# Banned prose terms from the project CLAUDE.md: vague praise, effort
# metaphors, hollow intensifiers and hedges, and the stand-in noun
# "thing(s)". Scanned informationally: hits inside quoted packet text
# are legitimate, so a person judges each hit.
BANNED_PROSE = [
    "clean", "cleaner", "cleanly",
    "does the work", "heavy lifting", "carries the weight",
    "quietly", "silently",
    "shines when",
    "the real payoff", "the headline benefit",
    "connective tissue", "papercuts",
    "pleasant", "nice", "neat", "elegant",
    "the right call",
    "honest", "pragmatic",
    "free win", "just works",
    "actually", "really", "very", "quite", "truly", "basically",
    "literally", "essentially", "simply", "perhaps", "maybe",
    "sort of", "kind of",
    "thing", "things",
]

# Counters for the final summary.
pass_count = 0
fail_count = 0


def report_pass(message):
    """Print a passing check."""
    global pass_count
    pass_count = pass_count + 1
    print("PASS  " + message)


def report_fail(message):
    """Print a failing check."""
    global fail_count
    fail_count = fail_count + 1
    print("FAIL  " + message)


def report_info(message):
    """Print an informational line that does not pass or fail."""
    print("INFO  " + message)


def read_lines(path):
    """Read a text file and return its lines without line endings."""
    handle = open(path, "r", encoding="utf-8")
    text = handle.read()
    handle.close()
    return text.split("\n")


def compute_sha256(path):
    """Return the uppercase SHA-256 hex digest of a file."""
    handle = open(path, "rb")
    data = handle.read()
    handle.close()
    digest = hashlib.sha256(data).hexdigest()
    return digest.upper()


def get_links(path):
    """Return every markdown link target in a file as (line_number, target)."""
    lines = read_lines(path)
    links = []
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        search_from = 0
        while True:
            marker_pos = line.find("](", search_from)
            if marker_pos < 0:
                break
            close_pos = line.find(")", marker_pos + 2)
            if close_pos < 0:
                break
            target = line[marker_pos + 2:close_pos]
            links.append([line_number, target])
            search_from = close_pos + 1
    return links


def find_non_ascii(path):
    """Return a list of (line_number, character) for non-ASCII characters."""
    lines = read_lines(path)
    found = []
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        for ch in line:
            if ord(ch) > 127:
                found.append([line_number, ch])
    return found


def list_incoming_files():
    """Return file names in the incoming folder, sorted case-insensitively.

    Returns None when the folder does not exist. Subfolders are ignored.
    """
    if not os.path.isdir(INCOMING_DIR):
        return None
    names = []
    for name in os.listdir(INCOMING_DIR):
        full_path = os.path.join(INCOMING_DIR, name)
        if os.path.isfile(full_path):
            names.append(name)
    # Sort case-insensitively with plain loops: pair each name with
    # its lowercase form, sort the pairs, then take the names back out.
    pairs = []
    for name in names:
        pairs.append([name.lower(), name])
    pairs.sort()
    sorted_names = []
    for pair in pairs:
        sorted_names.append(pair[1])
    return sorted_names


def parse_state_file(path):
    """Read source-state.txt into a plain dict.

    Returns None when the file is missing. The dict holds:
      "hashes": dict of label to stored uppercase hash
      "reviewed_team": the reviewed-team: value, or "" when absent
      "items": dict of item name to verdict from the items: line
      "has_items_line": True when an items: line was present
      "quoted_words": recorded tier-2 entries, lowercased ([] for none)
      "has_quoted_line": True when a quoted-words: line was present
      "excluded": excluded entries as written ([] for none)
      "has_excluded_line": True when an excluded: line was present
    """
    if not os.path.isfile(path):
        return None
    lines = read_lines(path)
    state = {}
    state["hashes"] = {}
    state["reviewed_team"] = ""
    state["items"] = {}
    state["has_items_line"] = False
    state["quoted_words"] = []
    state["has_quoted_line"] = False
    state["excluded"] = []
    state["has_excluded_line"] = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("reviewed-team:"):
            value = stripped[len("reviewed-team:"):].strip()
            state["reviewed_team"] = value
        elif stripped.startswith("items:"):
            state["has_items_line"] = True
            remainder = stripped[len("items:"):].strip()
            entries = remainder.split(";")
            for entry in entries:
                entry = entry.strip()
                equals_pos = entry.find("=")
                if equals_pos > 0:
                    item_name = entry[:equals_pos].strip()
                    verdict = entry[equals_pos + 1:].strip()
                    state["items"][item_name] = verdict
        elif stripped.startswith("quoted-words:"):
            state["has_quoted_line"] = True
            remainder = stripped[len("quoted-words:"):].strip()
            if remainder != "none" and remainder != "":
                entries = remainder.split(";")
                for entry in entries:
                    entry = entry.strip().lower()
                    if entry != "":
                        state["quoted_words"].append(entry)
        elif stripped.startswith("excluded:"):
            state["has_excluded_line"] = True
            remainder = stripped[len("excluded:"):].strip()
            if remainder != "none" and remainder != "":
                entries = remainder.split(";")
                for entry in entries:
                    entry = entry.strip()
                    if entry != "":
                        state["excluded"].append(entry)
        else:
            marker_pos = stripped.find(" sha256=")
            if marker_pos > 0:
                label = stripped[:marker_pos].strip()
                stored = stripped[marker_pos + len(" sha256="):].strip()
                state["hashes"][label] = stored.upper()
    return state


def check_forbidden_words(path, quoted_words):
    """Scan the report for tier-1 and unrecorded tier-2 words.

    Returns a list of [line_number, message] pairs, one per hit.
    quoted_words holds the recorded tier-2 entries, lowercased.
    """
    lines = read_lines(path)
    hits = []
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        # Compare whole words: lowercase the line and turn every
        # character that is not a letter or digit into a space.
        normalized = ""
        for ch in line.lower():
            if ch.isalnum():
                normalized = normalized + ch
            else:
                normalized = normalized + " "
        words = normalized.split()
        for word in words:
            if word in TIER1_WORDS:
                hits.append([line_number,
                             "tier-1 word '" + word
                             + "' (never allowed in the report)"])
            elif word in TIER2_WORDS:
                if word not in quoted_words:
                    hits.append([line_number,
                                 "tier-2 word '" + word
                                 + "' not recorded on quoted-words:"])
        padded = " " + " ".join(words) + " "
        for phrase in FORBIDDEN_PHRASES:
            if " " + phrase + " " in padded:
                if phrase not in quoted_words:
                    hits.append([line_number,
                                 "tier-2 phrase '" + phrase
                                 + "' not recorded on quoted-words:"])
    return hits


def get_report_sections(path):
    """Return the '## ' heading titles of a file, in file order."""
    lines = read_lines(path)
    sections = []
    for line in lines:
        if line.startswith("## "):
            sections.append(line[3:].strip())
    return sections


def get_finding_blocks(path):
    """Parse the findings log into blocks.

    Returns a list of dicts, one per '### ' heading, each holding:
      "heading": the heading text after '### '
      "line": the heading's line number
      "fields": [name, value] pairs from the block's '- ' bullets
    A bullet with no colon becomes a pair of [whole text, ""], which
    the field-name check then reports.
    """
    lines = read_lines(path)
    blocks = []
    current = None
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        if line.startswith("### "):
            current = {}
            current["heading"] = line[4:].strip()
            current["line"] = line_number
            current["fields"] = []
            blocks.append(current)
        elif current is not None and line.startswith("- "):
            rest = line[2:]
            colon_pos = rest.find(":")
            if colon_pos > 0:
                name = rest[:colon_pos].strip()
                value = rest[colon_pos + 1:].strip()
                current["fields"].append([name, value])
            else:
                current["fields"].append([rest.strip(), ""])
    return blocks


def get_report_finding_ids(path):
    """Return every F-NN token in the report as [id, section, line_number].

    Tracks which '## ' section each token appears under. A token only
    counts when the character before "F-" is not a letter or digit, so
    text like "PDF-22" does not match.
    """
    lines = read_lines(path)
    found = []
    current_section = ""
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        if line.startswith("## "):
            current_section = line[3:].strip()
            continue
        search_from = 0
        while True:
            f_pos = line.find("F-", search_from)
            if f_pos < 0:
                break
            is_word_start = True
            if f_pos > 0:
                before = line[f_pos - 1]
                if before.isalnum():
                    is_word_start = False
            digits = ""
            j = f_pos + 2
            while j < len(line) and line[j].isdigit():
                digits = digits + line[j]
                j = j + 1
            if digits != "" and is_word_start:
                found.append(["F-" + digits, current_section, line_number])
            search_from = f_pos + 2
    return found


def count_body_words(path):
    """Count body words in the report.

    Skips the first six lines (title, blank line, and the four
    attribution lines) and every heading line, then splits the rest
    on whitespace and counts the pieces.
    """
    lines = read_lines(path)
    total = 0
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        if line_number <= 6:
            continue
        if line.startswith("#"):
            continue
        words = line.split()
        total = total + len(words)
    return total


def get_slide_numbers(path):
    """Return the N values from '## Slide N:' headings, in file order.

    A heading that does not parse contributes -1, so the caller's
    sequence check fails and points at it.
    """
    lines = read_lines(path)
    numbers = []
    for line in lines:
        if line.startswith("## Slide "):
            rest = line[len("## Slide "):]
            colon_pos = rest.find(":")
            if colon_pos > 0:
                number_text = rest[:colon_pos].strip()
                if number_text.isdigit():
                    numbers.append(int(number_text))
                else:
                    numbers.append(-1)
            else:
                numbers.append(-1)
    return numbers


def parse_time_to_seconds(time_text):
    """Parse 'M:SS' into total seconds. Returns -1 when it does not parse."""
    colon_pos = time_text.find(":")
    if colon_pos <= 0:
        return -1
    minute_text = time_text[:colon_pos].strip()
    second_text = time_text[colon_pos + 1:].strip()
    if not minute_text.isdigit():
        return -1
    if len(second_text) != 2:
        return -1
    if not second_text.isdigit():
        return -1
    minutes = int(minute_text)
    seconds = int(second_text)
    if seconds >= 60:
        return -1
    return minutes * 60 + seconds


def get_slide_times(path):
    """Return one list per slide section, each holding that section's
    parsed 'Time: M:SS' values in seconds.

    A time that does not parse contributes -1 to its slide's list.
    """
    lines = read_lines(path)
    per_slide = []
    current = None
    for line in lines:
        if line.startswith("## Slide "):
            current = []
            per_slide.append(current)
        elif current is not None:
            stripped = line.strip()
            if stripped.startswith("- "):
                stripped = stripped[2:].strip()
            elif stripped.startswith("* "):
                stripped = stripped[2:].strip()
            if stripped.startswith("Time:"):
                time_text = stripped[len("Time:"):].strip()
                seconds = parse_time_to_seconds(time_text)
                current.append(seconds)
    return per_slide


def format_finding_number(number):
    """Return NN text for a finding number: 7 becomes "07", 12 stays "12"."""
    text = str(number)
    if len(text) < 2:
        text = "0" + text
    return text


def format_seconds(total_seconds):
    """Return M:SS text for a number of seconds."""
    minutes = total_seconds // 60
    seconds = total_seconds % 60
    second_text = str(seconds)
    if len(second_text) < 2:
        second_text = "0" + second_text
    return str(minutes) + ":" + second_text


def section_for_category(category):
    """Return the report section where a log category's findings appear."""
    if category == "Strength":
        return "Strengths"
    if category == "Ambiguity":
        return "Ambiguities"
    if category == "Missing case":
        return "Missing Cases"
    if category == "Scope risk":
        return "Scope Risks"
    return ""


def scan_banned_prose(path):
    """Return [line_number, term] pairs for banned-prose hits in a file."""
    lines = read_lines(path)
    hits = []
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        normalized = ""
        for ch in line.lower():
            if ch.isalnum():
                normalized = normalized + ch
            else:
                normalized = normalized + " "
        padded = " " + " ".join(normalized.split()) + " "
        for term in BANNED_PROSE:
            if " " + term + " " in padded:
                hits.append([line_number, term])
    return hits


def main():
    # Check 1: the incoming folder exists and is non-empty.
    incoming_names = list_incoming_files()
    if incoming_names is None or len(incoming_names) == 0:
        if incoming_names is None:
            report_fail("incoming folder missing: " + INCOMING_DIR)
        else:
            report_fail("incoming folder is empty: " + INCOMING_DIR)
        print("")
        print("Place the other team's packet files (any mix of .md and"
              " .pdf) in " + INCOMING_DIR)
        print("and run /generate-review-report.")
        sys.exit(1)
    report_pass("incoming folder exists with "
                + str(len(incoming_names)) + " file(s)")

    # Check 1, continued: the spec files and the three outputs exist.
    missing = []
    spec_paths = [
        os.path.join(SKILL_DIR, "SKILL.md"),
        os.path.join(SKILL_DIR, "reference.md"),
    ]
    for path in spec_paths:
        if not os.path.isfile(path):
            missing.append(path)
    for entry in OUTPUT_TABLE:
        if not os.path.isfile(entry[1]):
            missing.append(entry[1])
    if len(missing) > 0:
        for path in missing:
            report_fail("missing file: " + path)
        print("")
        print("The review outputs or the spec files are incomplete."
              " Run /generate-review-report to build them.")
        sys.exit(1)
    report_pass("SKILL.md, reference.md, and all three outputs exist")

    # Check 2: source-state.txt parses and holds every required line.
    state = parse_state_file(STATE_FILE)
    if state is None:
        report_fail("source-state.txt is missing")
        state = {}
        state["hashes"] = {}
        state["reviewed_team"] = ""
        state["items"] = {}
        state["has_items_line"] = False
        state["quoted_words"] = []
        state["has_quoted_line"] = False
        state["excluded"] = []
        state["has_excluded_line"] = False
    else:
        state_ok = True
        if len(state["hashes"]) == 0:
            report_fail("source-state.txt holds no hash lines")
            state_ok = False
        if state["reviewed_team"] == "":
            report_fail("source-state.txt has no reviewed-team: value")
            state_ok = False
        if not state["has_items_line"]:
            report_fail("source-state.txt has no items: line")
            state_ok = False
        else:
            for item in REQUIRED_ITEMS:
                verdict = state["items"].get(item, "")
                if verdict == "":
                    report_fail("items: line has no entry for " + item)
                    state_ok = False
                elif verdict != "found" and verdict != "missing":
                    report_fail("items: entry for " + item + " is '"
                                + verdict + "', expected found or missing")
                    state_ok = False
        if not state["has_quoted_line"]:
            report_fail("source-state.txt has no quoted-words: line")
            state_ok = False
        if not state["has_excluded_line"]:
            report_fail("source-state.txt has no excluded: line")
            state_ok = False
        if state_ok:
            report_pass("source-state.txt parsed"
                        + " (reviewed team: " + state["reviewed_team"] + ")")

    # Check 3: the incoming file name set matches the stored labels.
    stored_incoming = []
    for label in state["hashes"]:
        if label.startswith("incoming/"):
            stored_incoming.append(label[len("incoming/"):])
    set_ok = True
    for name in incoming_names:
        if name not in stored_incoming:
            report_fail("incoming file not in the state file: " + name
                        + " (the review is stale)")
            set_ok = False
    for name in stored_incoming:
        if name not in incoming_names:
            report_fail("state file lists an incoming file not on disk: "
                        + name + " (the review is stale)")
            set_ok = False
    if set_ok:
        report_pass("incoming file names match the state file ("
                    + str(len(incoming_names)) + ")")

    # Check 4: every stored hash matches the file on disk.
    hashed_files = []
    for name in incoming_names:
        hashed_files.append(["incoming/" + name,
                             os.path.join(INCOMING_DIR, name)])
    hashed_files.append(["SKILL.md", os.path.join(SKILL_DIR, "SKILL.md")])
    hashed_files.append(["reference.md",
                         os.path.join(SKILL_DIR, "reference.md")])
    for entry in OUTPUT_TABLE:
        hashed_files.append([entry[0], entry[1]])
    for pair in hashed_files:
        label = pair[0]
        path = pair[1]
        current = compute_sha256(path)
        if label not in state["hashes"]:
            report_fail("no stored hash for " + label)
        elif state["hashes"][label] != current:
            if label.startswith("output/"):
                report_fail("hash mismatch for " + label
                            + " (hand edit, or stale state file)")
            else:
                report_fail("hash mismatch for " + label
                            + " (the review is stale)")
        else:
            report_pass("hash matches for " + label)

    # Check 5: the attribution block, lines 3-6, in every output.
    first_block = None
    first_file = ""
    attribution_ok = True
    for entry in OUTPUT_TABLE:
        path = entry[1]
        title = entry[2]
        name = os.path.basename(path)
        lines = read_lines(path)
        if len(lines) < 6 or lines[1] != "":
            report_fail(name + ": expected '# Title', blank line,"
                        + " then the four attribution lines")
            attribution_ok = False
            continue
        if lines[0] != "# " + title:
            report_fail(name + ": title line is '" + lines[0]
                        + "', expected '# " + title + "'")
            attribution_ok = False
        if lines[2] != ATTRIBUTION_LINE_3:
            report_fail(name + ": attribution team line differs"
                        + " from the pinned constant")
            attribution_ok = False
        if lines[3] != ATTRIBUTION_LINE_4:
            report_fail(name + ": attribution course line differs"
                        + " from the pinned constant")
            attribution_ok = False
        if lines[4] != ATTRIBUTION_LINE_5:
            report_fail(name + ": attribution members line differs"
                        + " from the pinned constant (note the trailing"
                        + " backslash)")
            attribution_ok = False
        if not lines[5].startswith(REVIEWED_TEAM_PREFIX):
            report_fail(name + ": line 6 does not start with '"
                        + REVIEWED_TEAM_PREFIX + "'")
            attribution_ok = False
        elif state["reviewed_team"] != "":
            expected_line_6 = REVIEWED_TEAM_PREFIX + state["reviewed_team"]
            if lines[5] != expected_line_6:
                report_fail(name + ": reviewed-team line does not match"
                            + " the state file value")
                attribution_ok = False
        block = lines[2] + "\n" + lines[3] + "\n" + lines[4] + "\n" + lines[5]
        if first_block is None:
            first_block = block
            first_file = name
        elif block != first_block:
            report_fail(name + ": attribution differs from " + first_file)
            attribution_ok = False
    if attribution_ok:
        report_pass("attribution block is correct and identical"
                    + " across the three outputs")

    # Check 6: every character in every output is ASCII.
    ascii_ok = True
    for entry in OUTPUT_TABLE:
        path = entry[1]
        name = os.path.basename(path)
        bad = find_non_ascii(path)
        if len(bad) > 0:
            first = bad[0]
            report_fail(name + ": " + str(len(bad))
                        + " non-ASCII character(s), first at line "
                        + str(first[0]))
            ascii_ok = False
    if ascii_ok:
        report_pass("no non-ASCII characters in any output")

    # Check 7: no HTML comments in any output.
    comments_ok = True
    for entry in OUTPUT_TABLE:
        path = entry[1]
        name = os.path.basename(path)
        lines = read_lines(path)
        line_number = 0
        for line in lines:
            line_number = line_number + 1
            if "<!--" in line:
                report_fail(name + " line " + str(line_number)
                            + ": HTML comment found")
                comments_ok = False
    if comments_ok:
        report_pass("no HTML comments in any output")

    # Check 8: no markdown links in any output.
    links_ok = True
    for entry in OUTPUT_TABLE:
        path = entry[1]
        name = os.path.basename(path)
        links = get_links(path)
        for pair in links:
            report_fail(name + " line " + str(pair[0])
                        + ": link found: " + pair[1])
            links_ok = False
    if links_ok:
        report_pass("no markdown links in any output")

    # Check 9 (report only): no ".md" mentions, no tier-1 words, and
    # no tier-2 words or phrases that are not on the quoted-words: line.
    report_name = os.path.basename(REPORT_PATH)
    words_ok = True
    lines = read_lines(REPORT_PATH)
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        if ".md" in line.lower():
            report_fail(report_name + " line " + str(line_number)
                        + ": markdown file name found")
            words_ok = False
    hits = check_forbidden_words(REPORT_PATH, state["quoted_words"])
    for hit in hits:
        report_fail(report_name + " line " + str(hit[0]) + ": " + hit[1])
        words_ok = False
    if words_ok:
        report_pass("report: no .md mentions, no tier-1 words,"
                    + " no unrecorded tier-2 words")

    # Check 10: the report has exactly the five sections, in order.
    sections = get_report_sections(REPORT_PATH)
    if sections == REPORT_SECTIONS:
        report_pass("report has exactly the five sections in order")
    else:
        report_fail("report sections are " + str(sections)
                    + ", expected " + str(REPORT_SECTIONS))

    # Check 11: the findings log blocks parse with valid fields.
    log_name = os.path.basename(LOG_PATH)
    blocks = get_finding_blocks(LOG_PATH)
    log_ok = True
    log_ids = []
    log_findings = {}
    if len(blocks) == 0:
        report_fail(log_name + ": no '### F-NN:' finding blocks found")
        log_ok = False
    block_number = 0
    for block in blocks:
        block_number = block_number + 1
        heading = block["heading"]
        heading_line = block["line"]
        colon_pos = heading.find(":")
        if colon_pos <= 0:
            report_fail(log_name + " line " + str(heading_line)
                        + ": heading does not parse as 'F-NN: title'")
            log_ok = False
            continue
        finding_id = heading[:colon_pos].strip()
        title = heading[colon_pos + 1:].strip()
        expected_id = "F-" + format_finding_number(block_number)
        if finding_id != expected_id:
            report_fail(log_name + " line " + str(heading_line)
                        + ": heading ID is '" + finding_id
                        + "', expected " + expected_id)
            log_ok = False
        if title == "":
            report_fail(log_name + " line " + str(heading_line)
                        + ": heading has no title after the colon")
            log_ok = False
        category = ""
        severity = ""
        quote = ""
        field_names = []
        for field in block["fields"]:
            field_names.append(field[0])
        if field_names != EXPECTED_FIELDS:
            report_fail(log_name + " line " + str(heading_line) + ": "
                        + finding_id + " fields are " + str(field_names)
                        + ", expected " + str(EXPECTED_FIELDS))
            log_ok = False
        else:
            category = block["fields"][0][1]
            severity = block["fields"][1][1]
            location = block["fields"][2][1]
            quote = block["fields"][3][1]
            question = block["fields"][5][1]
            if category not in ALLOWED_CATEGORIES:
                report_fail(log_name + ": " + finding_id + " Category '"
                            + category + "' is not one of "
                            + str(ALLOWED_CATEGORIES))
                log_ok = False
            if severity not in ALLOWED_SEVERITIES:
                report_fail(log_name + ": " + finding_id + " Severity '"
                            + severity + "' is not one of "
                            + str(ALLOWED_SEVERITIES))
                log_ok = False
            if category in ALLOWED_CATEGORIES and severity in ALLOWED_SEVERITIES:
                if category == "Strength" and severity != "n/a":
                    report_fail(log_name + ": " + finding_id
                                + " is a Strength but Severity is '"
                                + severity + "', expected n/a")
                    log_ok = False
                if category != "Strength" and severity == "n/a":
                    report_fail(log_name + ": " + finding_id
                                + " Severity is n/a but Category is '"
                                + category + "', n/a is for Strengths only")
                    log_ok = False
            if not quote.startswith("\"") and not quote.startswith("none"):
                report_fail(log_name + ": " + finding_id + " Quote must"
                            + " start with a double quote or 'none'")
                log_ok = False
            if question == "":
                report_fail(log_name + ": " + finding_id
                            + " Question is empty")
                log_ok = False
            elif question == "none" and category != "Strength":
                report_fail(log_name + ": " + finding_id + " Question is"
                            + " 'none' but only Strengths may skip the"
                            + " question")
                log_ok = False
        if finding_id not in log_findings:
            log_ids.append(finding_id)
            finding_info = {}
            finding_info["category"] = category
            finding_info["severity"] = severity
            finding_info["quote"] = quote
            log_findings[finding_id] = finding_info
    if log_ok and len(blocks) > 0:
        report_pass("findings log: " + str(len(blocks))
                    + " finding(s) parse with valid fields")

    # Check 12: report-to-log traceability.
    report_id_entries = get_report_finding_ids(REPORT_PATH)
    trace_ok = True
    report_id_set = []
    for entry in report_id_entries:
        report_id = entry[0]
        section = entry[1]
        line_number = entry[2]
        if report_id not in report_id_set:
            report_id_set.append(report_id)
        if report_id not in log_findings:
            report_fail(report_name + " line " + str(line_number) + ": "
                        + report_id + " is not in the findings log")
            trace_ok = False
        else:
            category = log_findings[report_id]["category"]
            if category != "":
                expected_section = section_for_category(category)
                if section != expected_section:
                    report_fail(report_name + " line " + str(line_number)
                                + ": " + report_id + " appears under '"
                                + section + "', but its log category '"
                                + category + "' belongs under '"
                                + expected_section + "'")
                    trace_ok = False
    for finding_id in log_ids:
        severity = log_findings[finding_id]["severity"]
        if severity == "High" and finding_id not in report_id_set:
            report_fail("High finding " + finding_id
                        + " does not appear in the report")
            trace_ok = False
    for category in ALLOWED_CATEGORIES:
        category_in_log = False
        for finding_id in log_ids:
            if log_findings[finding_id]["category"] == category:
                category_in_log = True
        category_in_report = False
        for finding_id in report_id_set:
            if finding_id in log_findings:
                if log_findings[finding_id]["category"] == category:
                    category_in_report = True
        if category_in_log and not category_in_report:
            report_fail("category '" + category + "' has log findings"
                        + " but none appear in the report")
            trace_ok = False
    if trace_ok:
        report_pass("report findings trace to the log: sections agree,"
                    + " every High included, every non-empty category"
                    + " represented")

    # Check 13: the report body word count sits within the hard bounds.
    body_words = count_body_words(REPORT_PATH)
    if body_words >= WORD_FLOOR and body_words <= WORD_CEILING:
        report_pass("report body word count " + str(body_words)
                    + " within hard bounds " + str(WORD_FLOOR) + "-"
                    + str(WORD_CEILING))
    else:
        report_fail("report body word count " + str(body_words)
                    + " outside hard bounds " + str(WORD_FLOOR) + "-"
                    + str(WORD_CEILING))

    # Check 14: the outline's total-time line, slide numbering, and
    # per-slide times that sum to exactly 10:00.
    outline_name = os.path.basename(OUTLINE_PATH)
    outline_lines = read_lines(OUTLINE_PATH)
    total_line_found = False
    for line in outline_lines:
        if line.strip() == "Total time: 10 minutes.":
            total_line_found = True
    if total_line_found:
        report_pass("outline has the 'Total time: 10 minutes.' line")
    else:
        report_fail(outline_name
                    + ": no 'Total time: 10 minutes.' line found")
    slide_numbers = get_slide_numbers(OUTLINE_PATH)
    numbering_ok = True
    if len(slide_numbers) == 0:
        report_fail(outline_name + ": no '## Slide N:' headings found")
        numbering_ok = False
    expected_number = 0
    for number in slide_numbers:
        expected_number = expected_number + 1
        if number != expected_number:
            report_fail(outline_name + ": slide numbering breaks at"
                        + " position " + str(expected_number)
                        + " (found Slide " + str(number) + ")")
            numbering_ok = False
    if numbering_ok and len(slide_numbers) > 0:
        report_pass("outline slides numbered sequentially 1 to "
                    + str(len(slide_numbers)))
    per_slide_times = get_slide_times(OUTLINE_PATH)
    times_ok = True
    total_seconds = 0
    slide_index = 0
    for times in per_slide_times:
        slide_index = slide_index + 1
        if len(times) != 1:
            report_fail(outline_name + ": slide " + str(slide_index)
                        + " has " + str(len(times))
                        + " 'Time: M:SS' bullet(s), expected exactly 1")
            times_ok = False
        else:
            if times[0] < 0:
                report_fail(outline_name + ": slide " + str(slide_index)
                            + " has a Time bullet that does not parse"
                            + " as M:SS")
                times_ok = False
            else:
                total_seconds = total_seconds + times[0]
    if times_ok and len(per_slide_times) > 0:
        if total_seconds == 600:
            report_pass("outline slide times sum to exactly 10:00")
        else:
            report_fail("outline slide times sum to "
                        + format_seconds(total_seconds)
                        + ", expected exactly 10:00")

    # Check 15: every required item marked missing has a matching
    # High-severity Missing case finding quoting the absence.
    missing_items = []
    for item in REQUIRED_ITEMS:
        if state["items"].get(item, "") == "missing":
            missing_items.append(item)
    absent_findings = 0
    for finding_id in log_ids:
        info = log_findings[finding_id]
        if info["category"] == "Missing case" and info["severity"] == "High":
            if info["quote"].startswith("none (item absent"):
                absent_findings = absent_findings + 1
    if len(missing_items) == 0:
        report_pass("items: line marks no required item missing")
    elif absent_findings >= len(missing_items):
        report_pass(str(len(missing_items)) + " missing item(s) covered"
                    + " by " + str(absent_findings) + " High Missing-case"
                    + " finding(s) quoting the absence")
    else:
        report_fail("items: marks " + str(len(missing_items))
                    + " item(s) missing (" + ", ".join(missing_items)
                    + ") but only " + str(absent_findings)
                    + " High Missing-case finding(s) quote"
                    + " 'none (item absent...'")

    # Informational lines. None of these pass or fail.
    report_info("report body word count " + str(body_words)
                + " (target " + str(WORD_TARGET_LOW) + "-"
                + str(WORD_TARGET_HIGH) + ")")
    category_summary = ""
    for category in ALLOWED_CATEGORIES:
        count = 0
        for finding_id in log_ids:
            if log_findings[finding_id]["category"] == category:
                count = count + 1
        if category_summary != "":
            category_summary = category_summary + ", "
        category_summary = category_summary + category + " " + str(count)
    report_info("findings by category: " + str(len(log_ids))
                + " total; " + category_summary)
    severity_summary = ""
    for severity in ALLOWED_SEVERITIES:
        count = 0
        for finding_id in log_ids:
            if log_findings[finding_id]["severity"] == severity:
                count = count + 1
        if severity_summary != "":
            severity_summary = severity_summary + ", "
        severity_summary = severity_summary + severity + " " + str(count)
    report_info("findings by severity: " + severity_summary)
    log_only_mediums = []
    low_count = 0
    for finding_id in log_ids:
        severity = log_findings[finding_id]["severity"]
        if severity == "Medium" and finding_id not in report_id_set:
            log_only_mediums.append(finding_id)
        if severity == "Low":
            low_count = low_count + 1
    if len(log_only_mediums) == 0:
        report_info("log-only Medium findings: none")
    else:
        report_info("log-only Medium findings: "
                    + ", ".join(log_only_mediums))
    report_info("Low findings (always log-only): " + str(low_count))
    if len(state["excluded"]) == 0:
        report_info("excluded incoming files: none")
    else:
        report_info("excluded incoming files: "
                    + "; ".join(state["excluded"]))
    if len(state["quoted_words"]) == 0:
        report_info("quoted-words: none")
    else:
        report_info("quoted-words: " + "; ".join(state["quoted_words"])
                    + " (hand-confirm each appears only inside quoted"
                    + " packet content in the report)")
    report_info("outline has " + str(len(slide_numbers))
                + " slide(s) (suggested 7-12)")
    banned_total = 0
    for entry in OUTPUT_TABLE:
        path = entry[1]
        name = os.path.basename(path)
        prose_hits = scan_banned_prose(path)
        for hit in prose_hits:
            banned_total = banned_total + 1
            report_info(name + " line " + str(hit[0])
                        + ": banned prose '" + hit[1]
                        + "' (allowed only inside quoted packet text;"
                        + " judge by hand)")
    if banned_total == 0:
        report_info("banned-prose scan: no hits in the three outputs")
    else:
        report_info("banned-prose scan: " + str(banned_total)
                    + " hit(s) listed above; each must sit inside a"
                    + " quote or be rewritten")

    # Summary.
    print("")
    print("Checks passed: " + str(pass_count)
          + ", failed: " + str(fail_count))
    if fail_count > 0:
        print("Fix failures by regenerating the review outputs correctly."
              " Never edit the incoming packet files.")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
