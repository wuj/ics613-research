---
name: generate-review-report
description: Review the other team's incoming Requirements Review Packet (ics613-research/peer-review/incoming-packet/) and generate or regenerate the cross-team Requirements Review Report, the internal findings log, and the 10-minute presentation outline for the ICS 613 Local Produce Exchange project. Use when the user asks to review the incoming packet, generate, build, regenerate, refresh, or update the review report, findings log, or presentation outline, or to check whether the review is stale against the incoming packet. Creates the outputs if missing; if they exist, detects incoming-file changes (content, additions, removals, renames), spec changes, or hand edits via stored hashes and regenerates all three files, overwriting them. Never modifies the incoming packet files; a missing required packet item becomes a review finding, not a blocker. Asks the user only when the incoming folder is missing or empty, a file is unreadable or does not look like packet content, the reviewed team cannot be identified or conflicts with the recorded identity, or duplicate content conflicts, or the report cannot reach its minimum length without padding.
disable-model-invocation: true
---

# Generate Requirements Review Report

## What this skill does

ICS 613's cross-team peer review has two halves. The sibling skill, generate-requirements-packet, builds OUR outgoing packet. This skill handles the INCOMING half: the other team sends us their Requirements Review Packet (user stories, acceptance criteria, user roles/personas, open questions and assumptions, known risks), and we review it and produce three files: the Requirements Review Report (the external deliverable, five sections: Summary, Strengths, Ambiguities, Missing Cases, Scope Risks), an internal findings log, and a 10-minute presentation outline.

The incoming packet may not mirror ours: different file split (maybe one combined document), different heading styles, different ID schemes, different table formats, possibly PDFs. This skill reads every file that arrives and maps the content to the five required items. A required item missing from their packet is itself a review finding, never a blocker.

Reviewers identify problems; they do not design solutions. Every finding names the issue and a clarifying question, not a fix for the other team to implement.

This skill is manual-only (`disable-model-invocation: true`): the user runs it by typing `/generate-review-report`, optionally with `force`. The model never triggers it on its own.

This skill implements the plan at `requirements-review-report-plan.md` in the workspace root. SKILL.md, `reference.md`, and `validate.py` are the operative spec, kept self-contained so the skill runs even if the plan file moves. If the user changes the plan, update the skill files to match before generating; if the plan and this skill ever disagree, ask the user which one wins.

## Files

Input, strictly READ ONLY:

- `ics613-research/peer-review/incoming-packet/`: the other team's packet files, any mix of .md and .pdf, any file split. The user drops them here. This skill never writes into this folder.
- `ics613-research/requirements.md` (the assignment definition; a pinned reference, not hashed - its review goals, suggested lenses, and five report sections are baked into this spec, the same pinned-not-hashed pattern as the sibling skill: if the assignment changes, the user edits this spec, whose hash change triggers regeneration)

Skill folder companions:

- `reference.md`: the full spec: attribution block, reviewed-team identity rule, deliverables-only rules and quoting tiers, inventory step, review methodology, the three output specs, state file format, and the verification checklist. Read it before generating.
- `validate.py`: the deterministic validator. Run from the workspace root: `python .claude/skills/generate-review-report/validate.py` (on this machine `python` is not on PATH; use `py`). Python standard library only.
- `source-state.txt`: machine state written by this skill after each generation (reviewed team, inventory verdict, hashes, quoted-words and excluded lists). It lives here, not in the outputs, so the deliverable carries no machine state.

Outputs, the ONLY files this skill may write besides its own `source-state.txt`, all in `ics613-research/peer-review/`:

- `requirements-review-report.md` (external deliverable)
- `findings-log.md` (internal)
- `presentation-outline.md` (internal)

## Hard rules

1. **Never modify the incoming packet files, the team's source artifacts, or anything outside the three outputs and this skill's own `source-state.txt`.** The incoming folder belongs to the other team's content; the user places and converts files there, never this skill.
2. **Never assume the incoming packet mirrors our packet's structure.** Derive the inventory from the files as they exist. Use THEIR IDs and terminology verbatim; if they have no IDs, cite by document title, heading, and ordinal position ("the third story under Browsing").
3. **Regeneration replaces all three outputs, every time.** No partial updates.
4. **The report is external facing and follows the deliverables-only rules**: no markdown links, no file names or ".md" mentions, no tooling words, no HTML comments, no machine state, and no reference to the findings log or any internal document. Every finding included in the report is self-contained.
5. **Quoted packet text is preserved exactly**, with the sibling skill's three mechanical changes allowed (markdown escaping repairs, ASCII normalization, minimal generalization of internal references). Tier-2 forbidden words carried inside quotes are recorded on the state file's `quoted-words:` line; tier-1 words are never carried (paraphrase around them and note it in the run report). reference.md defines the tiers.
6. **Every finding carries a precise packet location and supporting evidence** in one of three forms: a quote; a coverage statement for an absence-across-a-set finding, naming what was searched and not found and across which items (for example, "none (coverage: no acceptance criterion covers unauthorized access across US-01 through US-12)"); or "none (item absent from the packet)" for a missing required item. Missing required items become High-severity findings.
7. **Derive, never recall.** Rebuild the inventory and the findings from the incoming files at run time. Do not reuse remembered content, counts, or findings from earlier runs or from examples in reference.md.
8. **Review, do not design.** Findings name the problem and the clarifying question, not the other team's solution.

## Procedure

1. **Decide what to do.**
   - Any of the three outputs missing: generate.
   - The user passed "force" or asked to rebuild regardless: generate.
   - Otherwise list the incoming folder and compare against `source-state.txt` here in the skill folder: the incoming file name set must match the stored `incoming/` labels, and every stored hash (incoming files, SKILL.md, reference.md, three outputs) must match disk.
     - Incoming folder missing or empty: pause (see "When the incoming packet has problems").
     - State file missing or malformed, the incoming name set changed (adds, removals, renames), or any incoming or spec hash differs: regenerate.
     - Inputs and spec match but an output hash differs: hand edits. Name the edited files and ask the user: regenerate (the edits are lost) or stop.
     - Everything matches: do NOT skip validation. Run validate.py anyway (a validator fix must always take effect), report the review is current plus the validation result, and stop.

2. **Read every incoming file fresh, in full.** PDFs via the Read tool. File split, headings, IDs, and wording may all have changed since the last run.

3. **Build the inventory and identify the reviewed team.** Map each file (and each section, for combined documents) to the five required items plus the optional domain model, per reference.md. Determine the reviewed team's identity per the identity rule in reference.md. Scan for pause conditions (see "When the incoming packet has problems") and batch any questions to the user before writing anything.

4. **Run the review methodology** (the seven lenses in reference.md) **and build the findings log.** Then derive the report from the log per the report spec, and the presentation outline from the report per the outline spec.

5. **Write `source-state.txt`**: reviewed team, the `items:` inventory verdict, hashes for every incoming file plus SKILL.md, reference.md, and the three outputs as just generated, then the `quoted-words:` and `excluded:` lines. This happens before validation because validate.py checks the state file; rewrite it after any regeneration.

6. **Verify.** Run validate.py and fix any failure by regenerating correctly (never by touching the incoming files; rewrite source-state.txt after any regeneration). Then the judgment checks in reference.md: quotes faithful apart from the three mechanical changes, categories sensible, no design prescriptions, report self-contained, every absent required item present as a High finding, a present domain model used in the consistency lens, general-audience prose, and every banned-prose hit either inside a quote or rewritten.

7. **Report** (see "How to report back").

## When the incoming packet has problems

These conditions pause generation. For each: stop before writing, describe the problem in plain terms, offer at least two options, recommend one, and wait for the user's decision, then record it in the run report.

1. **Incoming folder missing or empty.** Tell the user to place the other team's files in `ics613-research/peer-review/incoming-packet/` (any mix of .md and .pdf) and run the skill again.
2. **Unreadable or unusable file** (corrupt PDF, image-only scan, unsupported format like .docx). Options: the user converts it and re-runs (name a concrete route, for example open it in Word and save as PDF, or paste the text into a markdown file in the incoming folder); skip it (recorded on the `excluded:` line); or the user supplies the content another way. This skill never writes into the incoming folder, so the user places the converted file.
3. **Reviewed-team identity not stated** in the packet and no prior `reviewed-team:` line in the state file. Ask, then record.
4. **Identity conflict**: the packet states an identity contradicting the recorded `reviewed-team:` value.
5. **Ambiguous duplicates**: two files cover the same required item with conflicting content and no version cue. Ask which is current (the other goes on `excluded:`) or whether to review both and log the conflict as a finding.
6. **A file that does not look like packet content at all** (for example, our own packet dropped in by mistake). Ask include-or-exclude.
7. **The report cannot reach the 900-word floor with substantive prose** after deepening per the report sizing rule. Ask whether to deepen further or lower the floor in the spec (a spec edit changes the hash and triggers regeneration).

Explicit NON-pauses: missing required items, malformed stories, vague criteria, contradictions, missing IDs, and odd formatting never pause generation. Reviewing those is the assignment; they become findings.

## How to report back

After generating, give a short summary:

- **Trigger:** first generation, which hashed inputs changed (including added, removed, or renamed incoming files), hand edits found, missing outputs, or forced rebuild.
- **Inventory:** the file-to-item mapping, their ID scheme as observed, required items found missing.
- **Reviewed team:** the value used and how it was determined (packet content, carried forward, or user-supplied).
- **Decisions:** pause conditions raised, what the user chose, `excluded:` entries.
- **Findings:** counts by category and severity; the High findings listed with F-IDs.
- **Report sizing:** body word count versus the 1000-1600 target; which Medium findings were included and which stayed log-only.
- **Quoting:** `quoted-words:` entries with their quotes; every ASCII normalization or generalization applied; any tier-1 word paraphrased around.
- **Verification:** the validate.py result plus the judgment checks.
- **Reminder:** hand edits to the three outputs are lost on the next regeneration.

If the review was already current, report that the hashes match and give the validate.py result.

## Writing style (matches the project CLAUDE.md)

- ASCII characters only. No em dashes, en dashes, curly quotes, ellipsis characters, or emojis. Straight quotes and plain punctuation. No double-hyphen dashes; hyphens only for real compound words.
- Plain, layman-friendly prose. Short, direct sentences.
- Findings address the reviewed team's work concretely and respectfully: state the issue and the evidence, never a judgment of the authors.
- The report and outline are written for a general audience: everyday words, short sentences, contractions allowed, no slang. Translate methodology terms into plain phrasing (write "two members claiming the same items at the same time", not "a concurrency race"; "a step that depends on a feature no story provides", not "a backlog-dependency gap"). When a technical term cannot be avoided (for example "acceptance criteria"), define it in plain words at its first use in each output.
- The project CLAUDE.md prose restrictions apply to every sentence this skill writes in all three outputs:
  - No vague praise or effort metaphors. Banned: "clean"/"cleaner"/"cleanly", "does the work"/"heavy lifting"/"carries the weight", "quietly"/"silently", "shines when", "the real payoff", "the headline benefit", "connective tissue" and other body-part metaphors, "papercuts", "pleasant"/"nice"/"neat"/"elegant", "the right call", "honest"/"pragmatic" as qualifiers, "free win", "just works". Name the concrete property or operation instead.
  - No hollow intensifiers or hedges: "actually", "really", "very", "quite", "truly", "basically", "literally", "essentially", "simply", "perhaps", "maybe", "sort of", "kind of".
  - Never "thing"/"things" as a stand-in noun. Name the actual noun: the operation, the property, the rule, the value, or the step.
- Exemption: quoted packet text is the other team's wording, preserved verbatim per the quoting rule. The restrictions govern the prose around the quotes, never the quotes themselves.
