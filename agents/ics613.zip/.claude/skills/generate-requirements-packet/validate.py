"""Validator for the Requirements Review Packet.

Run from the workspace root:

    python .claude/skills/generate-requirements-packet/validate.py

(on machines where "python" is not on PATH, use "py" instead)

Checks that the generated packet matches the current source artifacts
and the recorded state in source-state.txt. Uses only the Python
standard library, so it behaves the same under PowerShell, Git Bash,
or WSL.

If a check fails, fix it by regenerating the packet correctly.
Never fix a failure by editing the source artifacts.

Exit code 0 means every hard check passed. Exit code 1 means at least
one hard check failed, or the packet is missing.
"""

import hashlib
import os
import sys

# Folder paths, relative to the workspace root.
ARTIFACTS_DIR = os.path.join("ics613-research", "artifacts")
PACKET_DIR = os.path.join(ARTIFACTS_DIR, "requirements-review-packet")
SKILL_DIR = os.path.join(".claude", "skills", "generate-requirements-packet")
STATE_FILE = os.path.join(SKILL_DIR, "source-state.txt")

# The six packet files, in order.
PACKET_FILES = [
    "README.md",
    "01-user-stories.md",
    "02-acceptance-criteria.md",
    "03-user-roles-personas.md",
    "04-open-questions-assumptions.md",
    "05-known-risks.md",
]

# The eleven hashed files: label used in source-state.txt, then the path.
# The first five are inputs; the packet/ six detect hand edits.
HASHED_FILES = [
    ["team-charter.md", os.path.join(ARTIFACTS_DIR, "team-charter.md")],
    ["use-cases.md", os.path.join(ARTIFACTS_DIR, "use-cases.md")],
    ["user-stories.md", os.path.join(ARTIFACTS_DIR, "user-stories.md")],
    ["SKILL.md", os.path.join(SKILL_DIR, "SKILL.md")],
    ["reference.md", os.path.join(SKILL_DIR, "reference.md")],
    ["packet/README.md", os.path.join(PACKET_DIR, "README.md")],
    ["packet/01-user-stories.md",
     os.path.join(PACKET_DIR, "01-user-stories.md")],
    ["packet/02-acceptance-criteria.md",
     os.path.join(PACKET_DIR, "02-acceptance-criteria.md")],
    ["packet/03-user-roles-personas.md",
     os.path.join(PACKET_DIR, "03-user-roles-personas.md")],
    ["packet/04-open-questions-assumptions.md",
     os.path.join(PACKET_DIR, "04-open-questions-assumptions.md")],
    ["packet/05-known-risks.md",
     os.path.join(PACKET_DIR, "05-known-risks.md")],
]

# Words that must never appear in a deliverable, compared lowercase as
# whole words (so "maintain" does not trip on "ai", and "typescript"
# does not trip on "script").
FORBIDDEN_WORDS = [
    "claude",
    "anthropic",
    "ai",
    "codex",
    "openai",
    "chatgpt",
    "copilot",
    "discord",
    "github",
    "skill",
    "skills",
    "script",
    "scripts",
]

# Phrases that must never appear, compared lowercase on word boundaries.
FORBIDDEN_PHRASES = ["google doc", "google docs"]

# Counters for the final summary.
pass_count = 0
fail_count = 0


def report_pass(message):
    """Print a passing check."""
    global pass_count
    pass_count = pass_count + 1
    print("PASS  " + message)


def report_fail(message):
    """Print a failing check."""
    global fail_count
    fail_count = fail_count + 1
    print("FAIL  " + message)


def report_info(message):
    """Print an informational line that does not pass or fail."""
    print("INFO  " + message)


def read_lines(path):
    """Read a text file and return its lines without line endings."""
    handle = open(path, "r", encoding="utf-8")
    text = handle.read()
    handle.close()
    return text.split("\n")


def compute_sha256(path):
    """Return the uppercase SHA-256 hex digest of a file."""
    handle = open(path, "rb")
    data = handle.read()
    handle.close()
    digest = hashlib.sha256(data).hexdigest()
    return digest.upper()


def get_story_ids(path):
    """Return story IDs (like US-01) from #### headings, in file order."""
    lines = read_lines(path)
    ids = []
    for line in lines:
        if line.startswith("#### US-"):
            rest = line[len("#### "):]
            colon_pos = rest.find(":")
            if colon_pos > 0:
                story_id = rest[:colon_pos].strip()
                ids.append(story_id)
    return ids


def get_scenario_counts(path):
    """Return a dict of story ID to the number of scenario lines under it."""
    lines = read_lines(path)
    counts = {}
    current_story = ""
    for line in lines:
        if line.startswith("#### US-"):
            rest = line[len("#### "):]
            colon_pos = rest.find(":")
            if colon_pos > 0:
                current_story = rest[:colon_pos].strip()
                counts[current_story] = 0
        elif current_story != "":
            stripped = line.strip()
            if stripped.startswith("*Scenario"):
                counts[current_story] = counts[current_story] + 1
    return counts


def get_links(path):
    """Return every markdown link target in a file as (line_number, target)."""
    lines = read_lines(path)
    links = []
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        search_from = 0
        while True:
            marker_pos = line.find("](", search_from)
            if marker_pos < 0:
                break
            close_pos = line.find(")", marker_pos + 2)
            if close_pos < 0:
                break
            target = line[marker_pos + 2:close_pos]
            links.append([line_number, target])
            search_from = close_pos + 1
    return links


def find_non_ascii(path):
    """Return a list of (line_number, character) for non-ASCII characters."""
    lines = read_lines(path)
    found = []
    line_number = 0
    for line in lines:
        line_number = line_number + 1
        for ch in line:
            if ord(ch) > 127:
                found.append([line_number, ch])
    return found


def parse_state_file(path):
    """Read source-state.txt.

    Returns a dict of label to stored hash, and a list of omitted IDs.
    Returns (None, None) when the file is missing or holds no hashes.
    """
    if not os.path.isfile(path):
        return None, None
    lines = read_lines(path)
    stored_hashes = {}
    omitted_ids = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("omissions:"):
            remainder = stripped[len("omissions:"):].strip()
            if remainder != "none" and remainder != "":
                entries = remainder.split(";")
                for entry in entries:
                    entry = entry.strip()
                    # The ID is everything before the first space or "(".
                    id_end = len(entry)
                    space_pos = entry.find(" ")
                    if space_pos >= 0 and space_pos < id_end:
                        id_end = space_pos
                    paren_pos = entry.find("(")
                    if paren_pos >= 0 and paren_pos < id_end:
                        id_end = paren_pos
                    omitted_id = entry[:id_end].strip()
                    if omitted_id != "":
                        omitted_ids.append(omitted_id)
        else:
            marker_pos = stripped.find(" sha256=")
            if marker_pos > 0:
                label = stripped[:marker_pos].strip()
                stored = stripped[marker_pos + len(" sha256="):].strip()
                stored_hashes[label] = stored.upper()
    if len(stored_hashes) == 0:
        return None, None
    return stored_hashes, omitted_ids


def get_charter_risk_count(charter_path):
    """Count the risk bullets in the charter's risks section.

    Returns -1 when the section cannot be found.
    """
    lines = read_lines(charter_path)
    in_section = False
    count = 0
    for line in lines:
        if line.startswith("# ") and "Risks and Mitigation" in line:
            in_section = True
            continue
        if in_section and line.startswith("# "):
            break
        if in_section and line.startswith("* **"):
            count = count + 1
    if not in_section:
        return -1
    return count


def count_table_body_rows(path):
    """Count table body rows: pipe lines minus the header and separators."""
    lines = read_lines(path)
    pipe_lines = []
    for line in lines:
        if line.strip().startswith("|"):
            pipe_lines.append(line.strip())
    body_count = 0
    header_seen = False
    for line in pipe_lines:
        # A separator row contains only pipes, hyphens, colons, and spaces.
        is_separator = True
        for ch in line:
            if ch != "|" and ch != "-" and ch != ":" and ch != " ":
                is_separator = False
                break
        if is_separator:
            continue
        if not header_seen:
            header_seen = True
            continue
        body_count = body_count + 1
    return body_count


def get_table_story_ids(path):
    """Return every US-ID found inside table rows of a file."""
    lines = read_lines(path)
    found_ids = []
    for line in lines:
        if not line.strip().startswith("|"):
            continue
        search_from = 0
        while True:
            us_pos = line.find("US-", search_from)
            if us_pos < 0:
                break
            digits = ""
            j = us_pos + 3
            while j < len(line) and line[j].isdigit():
                digits = digits + line[j]
                j = j + 1
            if digits != "":
                found_ids.append("US-" + digits)
            search_from = us_pos + 3
    return found_ids


def remove_omitted(id_list, omitted_ids):
    """Return the list with omitted IDs taken out."""
    kept = []
    for item in id_list:
        if item not in omitted_ids:
            kept.append(item)
    return kept


def main():
    # Step 0: the packet and every hashed input must exist.
    missing = []
    for name in PACKET_FILES:
        path = os.path.join(PACKET_DIR, name)
        if not os.path.isfile(path):
            missing.append(name)
    for pair in HASHED_FILES:
        # Packet files were already checked by short name above.
        if pair[0].startswith("packet/"):
            continue
        if not os.path.isfile(pair[1]):
            missing.append(pair[1])
    if len(missing) > 0:
        seen = []
        for name in missing:
            if name not in seen:
                seen.append(name)
                report_fail("missing file: " + name)
        print("")
        print("The packet or its inputs are incomplete."
              " Run /generate-requirements-packet to build the packet.")
        sys.exit(1)
    report_pass("all six packet files and all hashed inputs exist")

    stored_hashes, omitted_ids = parse_state_file(STATE_FILE)
    if stored_hashes is None:
        report_fail("source-state.txt is missing or holds no hashes")
        omitted_ids = []
    else:
        report_pass("source-state.txt parsed"
                    + " (omissions: " + str(len(omitted_ids)) + ")")

    # Check 1: the eleven stored hashes match the files on disk.
    if stored_hashes is not None:
        for pair in HASHED_FILES:
            label = pair[0]
            path = pair[1]
            current = compute_sha256(path)
            if label not in stored_hashes:
                report_fail("no stored hash for " + label)
            elif stored_hashes[label] != current:
                if label.startswith("packet/"):
                    report_fail("hash mismatch for " + label
                                + " (hand edit, or stale state file)")
                else:
                    report_fail("hash mismatch for " + label
                                + " (the packet is stale)")
            else:
                report_pass("hash matches for " + label)

    # Check 2: attribution lines 3-5 are byte-identical across all files.
    first_block = None
    first_file = ""
    attribution_ok = True
    for name in PACKET_FILES:
        path = os.path.join(PACKET_DIR, name)
        lines = read_lines(path)
        if len(lines) < 5 or not lines[0].startswith("# ") or lines[1] != "":
            report_fail(name + ": expected '# Title', blank line,"
                        + " then the three attribution lines")
            attribution_ok = False
            continue
        block = lines[2] + "\n" + lines[3] + "\n" + lines[4]
        if first_block is None:
            first_block = block
            first_file = name
        elif block != first_block:
            report_fail(name + ": attribution differs from " + first_file)
            attribution_ok = False
    if attribution_ok and first_block is not None:
        report_pass("attribution block is identical across all six files")

    # Check 3: every character is ASCII.
    ascii_ok = True
    for name in PACKET_FILES:
        path = os.path.join(PACKET_DIR, name)
        bad = find_non_ascii(path)
        if len(bad) > 0:
            ascii_ok = False
            first = bad[0]
            report_fail(name + ": " + str(len(bad)) + " non-ASCII character(s),"
                        + " first at line " + str(first[0]))
    if ascii_ok:
        report_pass("no non-ASCII characters in any packet file")

    # Check 4: no HTML comments and no forbidden words in the packet.
    clean_ok = True
    for name in PACKET_FILES:
        path = os.path.join(PACKET_DIR, name)
        lines = read_lines(path)
        line_number = 0
        for line in lines:
            line_number = line_number + 1
            if "<!--" in line:
                report_fail(name + " line " + str(line_number)
                            + ": HTML comment found")
                clean_ok = False
            if ".md" in line.lower():
                report_fail(name + " line " + str(line_number)
                            + ": markdown file name found")
                clean_ok = False
            # Compare whole words: lowercase the line and turn every
            # character that is not a letter or digit into a space.
            normalized = ""
            for ch in line.lower():
                if ch.isalnum():
                    normalized = normalized + ch
                else:
                    normalized = normalized + " "
            words = normalized.split()
            for word in words:
                if word in FORBIDDEN_WORDS:
                    report_fail(name + " line " + str(line_number)
                                + ": forbidden word '" + word + "'")
                    clean_ok = False
            padded = " " + " ".join(words) + " "
            for phrase in FORBIDDEN_PHRASES:
                if " " + phrase + " " in padded:
                    report_fail(name + " line " + str(line_number)
                                + ": forbidden phrase '" + phrase + "'")
                    clean_ok = False
    if clean_ok:
        report_pass("no HTML comments and no forbidden words in the packet")

    # Check 5: story IDs in 01 and 02 match the source, in source order.
    source_stories_path = os.path.join(ARTIFACTS_DIR, "user-stories.md")
    source_ids = get_story_ids(source_stories_path)
    expected_ids = remove_omitted(source_ids, omitted_ids)
    for name in ["01-user-stories.md", "02-acceptance-criteria.md"]:
        path = os.path.join(PACKET_DIR, name)
        packet_ids = get_story_ids(path)
        if packet_ids == expected_ids:
            report_pass(name + ": " + str(len(packet_ids))
                        + " stories match the source")
        else:
            report_fail(name + ": story IDs do not match the source"
                        + " (source has " + str(len(expected_ids))
                        + " after omissions, packet has "
                        + str(len(packet_ids)) + ")")

    # Check 6: per-story scenario counts in 02 match the source.
    source_counts = get_scenario_counts(source_stories_path)
    packet_counts = get_scenario_counts(
        os.path.join(PACKET_DIR, "02-acceptance-criteria.md"))
    scenario_ok = True
    for story_id in expected_ids:
        source_n = source_counts.get(story_id, 0)
        packet_n = packet_counts.get(story_id, 0)
        if source_n != packet_n:
            report_fail("02: " + story_id + " has " + str(packet_n)
                        + " scenario(s), source has " + str(source_n))
            scenario_ok = False
    if scenario_ok:
        report_pass("02: scenario counts match the source for every story")

    # Check 7: the role-to-story table in 03 covers every story exactly once.
    table_ids = get_table_story_ids(
        os.path.join(PACKET_DIR, "03-user-roles-personas.md"))
    roles_ok = True
    for story_id in expected_ids:
        appearances = 0
        for found in table_ids:
            if found == story_id:
                appearances = appearances + 1
        if appearances != 1:
            report_fail("03: " + story_id + " appears " + str(appearances)
                        + " time(s) in the role table, expected exactly 1")
            roles_ok = False
    for found in table_ids:
        if found not in expected_ids:
            report_fail("03: " + found + " is in the role table"
                        + " but not in the source (or it was omitted)")
            roles_ok = False
    if roles_ok:
        report_pass("03: role table covers every story exactly once")

    # Check 8: the risk row count in 05 matches the charter.
    charter_path = os.path.join(ARTIFACTS_DIR, "team-charter.md")
    charter_risks = get_charter_risk_count(charter_path)
    omitted_risk_count = 0
    for omitted_id in omitted_ids:
        if omitted_id.startswith("RISK"):
            omitted_risk_count = omitted_risk_count + 1
    if charter_risks < 0:
        report_fail("could not find the Risks and Mitigation section"
                    + " in the charter; check it by hand")
    else:
        expected_risks = charter_risks - omitted_risk_count
        packet_risks = count_table_body_rows(
            os.path.join(PACKET_DIR, "05-known-risks.md"))
        if packet_risks == expected_risks:
            report_pass("05: " + str(packet_risks)
                        + " risk rows match the charter")
        else:
            report_fail("05: " + str(packet_risks) + " risk rows, charter has "
                        + str(charter_risks) + " risks ("
                        + str(omitted_risk_count) + " omitted)")

    # Check 9: the packet contains no markdown links at all.
    links_ok = True
    for name in PACKET_FILES:
        path = os.path.join(PACKET_DIR, name)
        links = get_links(path)
        for pair in links:
            line_number = pair[0]
            target = pair[1]
            report_fail(name + " line " + str(line_number)
                        + ": link found: " + target)
            links_ok = False
    if links_ok:
        report_pass("no markdown links in any packet file")

    # Informational counts for 04 (judged by a person, not by this script).
    rows_04 = count_table_body_rows(
        os.path.join(PACKET_DIR, "04-open-questions-assumptions.md"))
    use_cases_text = "\n".join(
        read_lines(os.path.join(ARTIFACTS_DIR, "use-cases.md")))
    assumption_parens = use_cases_text.count("(Assumption:")
    marker_lines = 0
    for line in read_lines(source_stories_path):
        lower = line.lower()
        if line.strip().startswith("-") and (
                "confirm" in lower
                or "assumption" in lower
                or "not yet defined" in lower):
            marker_lines = marker_lines + 1
    report_info("04 has " + str(rows_04) + " row(s);"
                + " use-cases.md has " + str(assumption_parens)
                + " '(Assumption:' parenthetical(s);"
                + " user-stories.md has " + str(marker_lines)
                + " note line(s) with confirm/assumption markers."
                + " Judge 04's completeness against these by hand.")

    # Summary.
    print("")
    print("Checks passed: " + str(pass_count) + ", failed: " + str(fail_count))
    if fail_count > 0:
        print("Fix failures by regenerating the packet correctly."
              " Never edit the source artifacts.")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
