# Reference: packet generation spec

This file holds the full spec for generating the six packet files. Everything here is a derivation rule applied to the sources as they exist at run time. Where an example names specific IDs or counts, it is a dated example, never a target; re-derive from the current sources every run. Story order follows the source, which is topical, not numeric ID order.

## Attribution header

Every packet file opens with the same attribution block, byte-for-byte identical except for the document title on the first line. The block occupies lines 3 through 5 of every file: line 1 is the title, line 2 is blank, lines 3 to 5 are the attribution. validate.py compares those exact lines.

```
# <Document title>

**Team:** Team 4 | Local Produce Exchange, "Surplus"\
**Course:** ICS 613 Software Engineering | University of Hawai'i at Manoa | Summer 2026\
**Members:** Kennan Kaneshiro, Shea Stevens, Matt Ong, Kim Cates, Jeff Wu
```

- Lines 3 and 4 end with a single backslash, the markdown hard line break, so the three lines render one per line instead of collapsing into one paragraph. Line 5 has no trailing backslash.
- Label format and project-name wording (Local Produce Exchange, "Surplus") chosen by the user on 2026-06-07.
- The school name uses the ASCII spelling: straight apostrophe in "Hawai'i", no macron in "Manoa". The official spelling uses non-ASCII characters, which the project's ASCII-only rule forbids.
- These facts come from the title slide of the Project Initiation Presentation PDF and are pinned constants here. If the user says the team facts changed, update this block in this file first, then regenerate; that edit changes this file's hash, which triggers the rebuild.

## Deliverables-only rules

The packet files are the deliverables and nothing else:

- No reference to any file outside the packet: no links to other folders, no source file names, no repo paths.
- No markdown links anywhere in the packet, not even between the six packet files. US-IDs and UC-IDs are plain text everywhere.
- No file names anywhere in the packet, not even the packet's own file names. Packet documents are referred to by title only ("the acceptance criteria document"). validate.py fails on any ".md" mention.
- No mention of tooling or team channels: nothing about Claude, AI, skills, scripts, generation, Discord, Google Docs, or GitHub.
- No HTML comments and no machine state in any packet file; state lives in `source-state.txt` in this skill folder.
- The README does not mention the source documents or any file name.

## Source fidelity

Carried-over content preserves source wording exactly, with exactly three permitted mechanical changes:

1. **Markdown escaping repairs:** `PICKED_UP` not `PICKED\_UP`, plain hyphens not `\-`.
2. **ASCII normalization:** curly quotes and apostrophes become straight quotes, in body text and headings alike. A long dash (em or en) becomes the nearest meaning-preserving ASCII punctuation: a comma, a colon, parentheses, or a sentence break; never a hyphen or a double hyphen, per the project prose rule. No word changes.
3. **Minimal generalization of internal references:** carried text that points at a source document's internal section, a course document, a team tool, or internal documentation is trimmed minimally (dated examples: "follow the escalation steps in Section 11" becomes "follow the team's escalation steps"; the charter's "in the README" becomes "in the setup guide"; US-07's "in this slice" is trimmed; the US-08 note "models the requirements Sample User Story #1" is dropped as pure traceability). List every such edit in the run report.

Malformed teammate content (missing Given/When/Then keywords, meaning-changing typos, garbled grammar) carries through verbatim after those three changes, listed in the run report as FYI. It never pauses generation. Only structural problems pause; SKILL.md defines the bar.

## File-by-file spec

### README.md (cover page)

- Title: `Requirements Review Packet`. Attribution block.
- One short paragraph: this packet is for the ICS 613 cross-team requirements peer review, where the reviewing team looks for ambiguity, missing requirements, unrealistic scope, inconsistent workflows, unclear user roles, and missing edge cases.
- A numbered list of the five packet documents in assignment order, each the document title alone, plain text, no links and no file names (e.g., `User stories`).
- Nothing else: no assembly or provenance note, no machine state, no HTML comments.

### 01-user-stories.md

Source: `user-stories.md`.

- Title: `User Stories`.
- Short intro: these are the team's user stories; each story's acceptance criteria are in the acceptance criteria document under the same US-ID (named in plain words, not linked).
- Mirror the source's section groupings, whatever they are at run time.
- For every story heading in the source, in source order, one entry:
  - Heading: `#### US-NN: <title>` exactly as the source titles it, after ASCII normalization.
  - The story statement ("As a..., I want..., so that...") per source fidelity.
  - Metadata bullets from the source: source use case or use cases as plain-text UC-IDs (a story may cite more than one; keep any parenthetical the source attaches), priority, actor, milestone.
- No scenarios in this file, and no per-story pointer to 02; the intro covers that once.

### 02-acceptance-criteria.md

Source: `user-stories.md`.

- Title: `Acceptance Criteria`.
- Short intro: criteria for every user story, keyed by US-ID; story statements are in the user stories document (named in plain words, not linked).
- Same section groupings and story order as 01.
- For every story:
  - Heading: `#### US-NN: <title>` (normalized). No "Story:" line; the statement is in 01 under the same US-ID.
  - Every scenario from the source, per source fidelity. No paraphrasing; malformed steps carry as written.
  - Notes from the story's notes block, classified per the rule below.

### 03-user-roles-personas.md

Source: `use-cases.md`, the actors-and-roles section.

- Title: `User Roles and Personas`.
- The role context from the source intro: contextual roles (a Member acting as Poster or Recipient), the meaning of "exchange", quantity available versus remaining quantity, the suspended-account rule.
- Every role the source defines, with its definition, per source fidelity.
- A role-to-story coverage table derived from each story's Actor metadata: one row per role, that role's US-IDs in plain text. Every story appears exactly once.

### 04-open-questions-assumptions.md

Sources: the per-story "Notes / open questions / assumptions" blocks in `user-stories.md` and the parenthetical "(Assumption: ...)" notes in `use-cases.md`.

- Title: `Open Questions and Assumptions`.
- Short intro: these items are not yet team-approved; each should be confirmed or changed before the requirements are locked.
- One table: ID (OQA-NN, numbered in document order), Type (Open question, Assumption, or both), Item (plain restatement of the source note, trimmed of internal planning guidance such as how the team should reprioritize stories), Affected stories and use cases, Status (Open).
- Affected-items rule: each row lists the story ID(s) whose notes raised the item plus each such story's source use case ID(s) from its metadata. For a parenthetical that appears only in a use case, the row lists that UC-ID plus the story IDs that cite the UC as their source use case (equivalently, the use case's related-stories line). US-IDs and UC-IDs are plain text.
- Deduplicate: when a story note and a use-case parenthetical record the same item, one row covers both, listing all the affected IDs.

### 05-known-risks.md

Source: `team-charter.md`, the risks-and-mitigation section.

- Title: `Known Risks`.
- Short intro: risks the team identified, with the planned mitigations.
- One table: Risk, Mitigation. One row per charter risk, wording per source fidelity (the "Section 11" reference is the known generalization example).
- When a risk names business rules that specific stories enforce, name those US-IDs in plain text after the rule name. Derivation rule: take each rule the risk names (e.g., over-claim prevention, allowed status transitions, no cancellation after pickup) and name every story whose scenarios test that rule, found by searching the scenarios for the rule's terms (quantity exceeding, status changes and wrong-status rejections, cancel and withdraw guards). This is a judgment call re-derived each run; list the mapping chosen in the run report.

## Note classification rule (02 versus 04 versus dropped)

Each story's notes block can hold three kinds of items:

- **Goes to 04:** a note that asks the team to confirm or decide something, is labeled ASSUMPTION, or records a rule the team has not approved. Markers: "confirm", "not yet defined", "ASSUMPTION".
- **Stays in 02:** a note that states a settled rule or a scope boundary (dated examples: "a denial is final", "only a pending request can be withdrawn", "email or SMS notifications are out of scope for this story set", "photos are covered by US-25").
- **Dropped:** a note that is purely internal traceability, a process reference (a course document, a chat channel, another document's section), or authoring rationale about how the story set is structured (dated examples: US-08's "models the requirements Sample User Story #1"; US-10's "Approve and deny are two outcomes of one decision, so they are scenarios in this one story, not separate stories"). The packet is external facing; internal grounding does not carry. List every drop in the run report.
- A note that mixes kinds splits accordingly.

The parenthetical "(Assumption: ...)" notes in use cases always go to 04.

## No-links rule

The packet contains no markdown links at all (user decision, 2026-06-07, replacing the earlier linking design). Every US-ID and UC-ID mention is plain text. Cross-references name a document in plain words ("the acceptance criteria document") or give an ID, and the README lists the packet documents by title only. validate.py fails on any link syntax or ".md" mention in a packet file.

## Source-state file format

`source-state.txt` in this skill folder, written right after generating and before validating (the validator checks it), and rewritten after any regeneration. Plain lines, no markers:

```
team-charter.md sha256=<HASH>
use-cases.md sha256=<HASH>
user-stories.md sha256=<HASH>
SKILL.md sha256=<HASH>
reference.md sha256=<HASH>
packet/README.md sha256=<HASH>
packet/01-user-stories.md sha256=<HASH>
packet/02-acceptance-criteria.md sha256=<HASH>
packet/03-user-roles-personas.md sha256=<HASH>
packet/04-open-questions-assumptions.md sha256=<HASH>
packet/05-known-risks.md sha256=<HASH>
omissions: none
```

- The first five are the inputs (three sources, two spec files); the `packet/` six detect hand edits. validate.py is not hashed: it checks output without shaping it, and it runs on every invocation, including when the packet is current.
- Hashes are uppercase hex (SHA-256).
- `omissions:` is `none`, or semicolon-separated entries, each starting with the omitted ID followed by a short reason in parentheses, e.g., `omissions: US-31 (left out per user decision 2026-06-08)`. ID forms: US-NN, UC-NN, OQA-NN, or RISK-N, where RISK-N counts the charter's risk bullets top to bottom (risks have no IDs of their own). validate.py exempts these IDs from its coverage checks.

## Verification

Run the deterministic validator first, from the workspace root:

```
python .claude/skills/generate-requirements-packet/validate.py
```

On this machine `python` is not on PATH; use `py` instead.

It checks: all six packet files exist; all eleven stored hashes match the files on disk; story IDs in 01 and 02 match the source exactly (source order), minus recorded omissions; per-story scenario counts in 02 match the source, minus omissions; the role table in 03 covers every source story exactly once, minus omissions; the risk row count in 05 matches the charter, minus omissions; attribution lines 3-5 are byte-identical across the six files; zero non-ASCII characters; zero HTML comments; no forbidden tooling words on word boundaries, case-insensitive (claude, anthropic, ai, codex, openai, chatgpt, copilot, discord, github, skill, skills, script, scripts, and the phrase "google doc(s)"); no ".md" file-name mentions; and no markdown links anywhere in the packet. Subtler tooling mentions are judgment checks. It also prints informational counts for 04 without passing or failing them.

Fix any failure by regenerating correctly, never by editing sources, and rewrite source-state.txt after any regeneration.

Then the judgment checks the script cannot do:

1. Every open question and assumption from the source notes appears in 04, deduplicated per the affected-items rule; nothing flagged that the sources treat as settled; no known exception raised as a new item.
2. Settled-rule notes are in 02 with the right story; dropped notes and generalized references are listed for the run report.
3. Carried wording matches the source apart from the three mechanical changes; suspected malformations are listed as FYIs.
4. Connecting prose follows the deliverables-only rules.
