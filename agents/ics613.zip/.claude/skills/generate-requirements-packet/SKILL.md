---
name: generate-requirements-packet
description: Generate or regenerate the cross-team Requirements Review Packet (ics613-research/artifacts/requirements-review-packet/) from the team charter, use cases, and user stories for the ICS 613 Local Produce Exchange project. Use when the user asks to generate, build, regenerate, refresh, or update the requirements review packet, or to check whether the packet is stale against its sources. Creates the packet if missing; if it exists, detects source changes, spec changes, or hand edits via stored hashes and regenerates all six files, overwriting them. Never modifies the source artifacts; when sources contain errors, inconsistencies, or contradictions, asks the user how to handle them in the packet.
disable-model-invocation: true
---

# Generate Requirements Review Packet

## What this skill does

ICS 613 requires each team to submit a Requirements Review Packet for the cross-team peer review: user stories, acceptance criteria, user roles/personas, open questions and assumptions, and known risks. All content comes from three team artifacts; the packet extracts and reformats it, one file per item, plus a README cover page.

Teammates keep editing the source artifacts (on 2026-06-07 they added five stories and two use cases, inserted topically rather than in ID order), so the packet must be regenerable. Running this skill rebuilds the packet from whatever the sources say right now. The packet folder is output: hand edits to packet files are lost on regeneration.

This skill is manual-only (`disable-model-invocation: true`): the user runs it by typing `/generate-requirements-packet`, optionally with `force`. The model never triggers it on its own.

This skill implements the plan at `requirements-review-packet-plan.md` in the workspace root. SKILL.md, `reference.md`, and `validate.py` are the operative spec, kept self-contained so the skill runs even if the plan file moves. If the user changes the plan, update the skill files to match before generating; if the plan and this skill ever disagree, ask the user which one wins.

## Files

Sources, strictly READ ONLY:

- `ics613-research/artifacts/team-charter.md` (risks for file 05)
- `ics613-research/artifacts/use-cases.md` (roles for file 03, use-case assumptions for file 04)
- `ics613-research/artifacts/user-stories.md` (stories for file 01, scenarios for file 02, story notes for files 02 and 04)
- `ics613-research/requirements.md` (the assignment definition; a pinned reference, not hashed - its 5-item packet list is baked into this spec)

Skill folder companions:

- `reference.md`: the per-file generation spec, the attribution block, the deliverables-only rules, the note classification rule, the no-links rule, the state file format, and the verification checklist. Read it before generating.
- `validate.py`: the deterministic validator. Run from the workspace root: `python .claude/skills/generate-requirements-packet/validate.py` (on this machine `python` is not on PATH; use `py`). Python standard library only.
- `source-state.txt`: machine state written by this skill after each generation (eleven hashes plus recorded omissions). It lives here, not in the packet, so the deliverables carry no machine state.

Output, the ONLY packet files this skill may write, all in `ics613-research/artifacts/requirements-review-packet/`:

- `README.md`
- `01-user-stories.md`
- `02-acceptance-criteria.md`
- `03-user-roles-personas.md`
- `04-open-questions-assumptions.md`
- `05-known-risks.md`

## Hard rules

1. **Never modify the source artifacts** or anything else outside the packet folder and this skill's own `source-state.txt`. Teammates own the sources; this skill cannot fix them.
2. **When a structural problem blocks extraction, do not guess and do not silently resolve it.** Ask the user. See "When sources have problems".
3. **Regeneration replaces all six packet files, every time.** No partial updates.
4. **The packet adds no new requirements content and contains deliverables only.** No markdown links, no file names (not even the packet's own), and no reference to any file outside the packet (US-IDs and UC-IDs are plain text); no mention of Claude, AI, skills, scripts, generation, Discord, Google Docs, or GitHub; no HTML comments; no machine state. Connecting prose reads as if a person assembled the documents.
5. **Source wording is preserved exactly**, with exactly three mechanical changes allowed: markdown escaping repairs (`PICKED_UP` not `PICKED\_UP`), ASCII normalization of non-ASCII punctuation (curly quotes to straight; a long dash becomes the nearest meaning-preserving punctuation such as a comma, colon, parentheses, or a sentence break, never a hyphen; headings included), and minimal generalization of internal references (each edit listed in the run report). Malformed teammate content (missing Given/When/Then keywords, meaning-changing typos, garbled grammar) carries through verbatim and is listed in the report as FYI; it never pauses generation.
6. **Derive, never recall.** Build every list, count, table, and ID from the sources as they exist at run time. Story order follows the source (topical, not numeric ID order). Do not reuse remembered content or counts from earlier runs or from examples in reference.md.

## Procedure

1. **Decide what to do.**
   - Packet folder or any of the six files missing: generate.
   - The user passed "force" or asked to rebuild regardless: generate.
   - Otherwise compute SHA-256 hashes of eleven files: the three sources, SKILL.md, reference.md, and the six packet files. Compare to `source-state.txt` here in the skill folder.
     - State file missing or malformed, or any source or spec hash differs: generate.
     - Source and spec hashes match but a packet hash differs: hand edits. Name the edited files and ask the user: regenerate (the edits are lost) or stop.
     - All eleven match: do NOT skip validation. Run validate.py anyway (a validator fix must always take effect), report the packet is current plus the validation result, and stop.

2. **Read all three source artifacts fresh, in full.** Headings, IDs, groupings, order, and wording may all have changed.

3. **Scan for structural problems** (see "When sources have problems"). Ask the user before writing anything, batching questions. Record any user-approved omissions for step 6. Malformed content is NOT a structural problem; collect it for the report instead.

4. **Generate all six files** per `reference.md`.

5. **Write `source-state.txt`**: the eleven hashes (sources and spec as read in step 1; packet files as just generated) and the `omissions:` line (`none`, or semicolon-separated entries, each starting with the omitted ID, reason in parentheses). This happens before validation because validate.py checks the state file; rewrite it after any regeneration.

6. **Verify.** Run validate.py and fix any failure by regenerating correctly (never by editing sources; remember to rewrite source-state.txt after any regeneration). Then the judgment checks: every open question and assumption from the source notes appears in 04 (deduplicated per the affected-items rule), settled-rule notes sit in 02 with the right story, dropped traceability notes and generalized references are listed for the report, carried wording matches the source apart from the three mechanical changes, and no known exception was raised as a new item.

7. **Report** (see "How to report back").

## When sources have problems

Structural problems block faithful extraction and pause generation: an unparseable story or use-case heading, a duplicate US or UC ID, a story with no scenarios at all, a missing metadata field (source use case, priority, actor, milestone), or a story citing a use case that does not exist. When found:

1. Stop before writing.
2. Describe each problem in plain terms, quoting or citing the source lines.
3. Offer at least two options. The usual three: carry through verbatim as best the structure allows; record the problem in 04 as an open question; or omit the item, recorded on the `omissions:` line so verification accounts for it.
4. Recommend one option.
5. Wait for the user's decision, then proceed and record the decision in the run report.

Everything below the structural bar carries through verbatim without asking. That includes malformed scenario steps, typos, and grammar errors (current examples: "Restaurants the quantity back" in US-26, "can then longer log in" in US-27, steps missing Then in US-26/US-28). List each suspected malformation in the run report as an FYI the user can raise with the team. We cannot change what other people wrote.

**Known deliberate patterns. Do NOT flag these as problems.** The team reviewed them and chose to keep them:

- The assumptions and open-questions tables at the bottom of `use-cases.md` and `user-stories.md` are empty on purpose; the content lives in the inline notes and parentheticals, which file 04 aggregates.
- A use case may state a condition as a precondition and also include an exception flow for its violation. That is the chosen authoring pattern, not a contradiction.
- US-10/UC-10 describe the poster handling requests in the order received as a poster convention, not a system-enforced rule. It still appears in file 04 as an assumption, because the sources frame it as one; that is content, not a flag.

**Known wording gaps the user reviewed and left unfixed.** Carry these through verbatim and do not ask about them again (raise only if the user asks):

- R1 stories depend on R2 features (listing creation, notifications).
- US-07/US-08 say "available" where the use cases check "remaining".
- US-18 Scenario 1 lacks "for this exchange".
- US-25's benefit clause promises photo display that no story provides.
- "Open request" (US-08) versus "pending request" (UC-08).

If a teammate later edits one of these passages, the gap may be gone or changed; judge the new wording on its own.

## How to report back

After generating, give a short summary:

- **Trigger:** first generation, which hashed files changed, hand edits found, missing packet files, or forced rebuild.
- **Decisions:** structural problems raised, what the user chose, omissions recorded.
- **Sanitization:** every internal reference generalized or dropped (e.g., a "Section 11" phrase, a traceability note).
- **Malformations (FYI):** suspected malformed or typo'd source content carried verbatim, with story IDs and quotes, for the user to raise with the team.
- **Verification:** the validate.py result plus the judgment checks.
- **Reminder:** hand edits to packet files are lost on the next regeneration.

If the packet was already current, report that the eleven hashes match and give the validate.py result.

## Writing style (matches the project CLAUDE.md)

- ASCII characters only. No em dashes, en dashes, curly quotes, ellipsis characters, or emojis. Straight quotes and plain punctuation. No double-hyphen dashes; hyphens only for real compound words.
- Plain, layman-friendly prose. Short, direct sentences. Connecting prose stays minimal: the packet reformats source content, it does not rewrite it.
