---
name: reconcile-team-charter
description: Reconcile and align the backup team charter (ics613-research/artifacts/team-charter.md) with the read-only current-state team charter for the ICS 613 Local Produce Exchange project. Use when the user asks to reconcile, sync, align, refresh, update, or backfill the backup team charter against the current state, or to get the backup charter ready for an 11th-hour submission. Reads the current-state charter but never modifies it; edits only the backup charter.
---

# Reconcile Team Charter

## What this skill does

The user is on a five-person team in ICS 613 (Advanced Software Engineering). The team must submit a Team Charter. There are two copies of that charter:

- The **current-state charter** is the shared team document. The whole team is supposed to fill it in together. It is usually incomplete.
- The **backup charter** is the user's own complete version, written in case the team contributes nothing and the user has to submit something to avoid a poor grade.

The plan: near the deadline, if the team still has not contributed, the user will copy content out of the finished backup and paste it into the current-state document **by hand**. So the backup must always be (1) complete and (2) shaped exactly like the current-state document, so that the hand paste is a quick, section by section drop-in.

This skill updates the backup so it absorbs every real team contribution from the current-state document and backfills everything else. The skill never pastes into current-state; the user does that themselves.

## Files

- Backup charter, the ONLY file this skill may edit:
  `ics613-research/artifacts/team-charter.md`
- Current-state charter, strictly READ ONLY:
  `ics613-research/current-state/current-state-team-charter.md`
- Blank template, reference for the section list and structure:
  `ics613-research/templates/team-charter-template.md`
- Course requirements, reference for what the charter must cover:
  `ics613-research/requirements.md`

For deeper project context and the reconciliation decisions already agreed with the user, read `reference.md` in this skill folder.

## Hard rules (do not break these)

1. **Never modify the current-state document.** Treat it as read-only. Read it, never write to it, even at the last minute. The user does all backfilling into current-state by hand.
2. **Only modify the backup document** at `ics613-research/artifacts/team-charter.md`.
3. **Keep everything that is already in the current-state document.** Every item already written there counts as a real contribution from a teammate and must survive in the backup. Where the two documents express the same item, use the current-state wording, so a later paste does not overwrite a teammate's words.
4. **Backfill every gap** so all sections and all lists in the backup are complete and could be submitted on their own.
5. **Flag and ask on anything significant.** If you are unsure how to reconcile, or there is a real conflict (not just wording), stop, explain it, give a suggestion, and ask the user how to resolve it. Do not silently resolve a significant difference.

## Procedure

1. **Read all four files** listed above, plus `reference.md` in this folder. Read current-state fresh every time, because the team may have added new content since the last run. Read the backup too, since it may already hold a prior reconciliation.

2. **Align the structure first.** Make the backup's skeleton match the current-state document so a paste is section by section:
   - Section headings in the same style as current-state (bold, with an escaped period, like `# **1\. Team Purpose**`). Subsection headings bold too.
   - Keep the template's short italic prompt under each heading that has one in current-state (for example, the line under In Scope). Having the same prompts in both files means they do not show up as false differences when comparing.
   - Match table shapes. The member table (Section 3) and the signature table (Section 15) must list all five members in the same order as current-state.
   - Match the milestone table (Section 13) to the current-state row breakdown.

3. **Reconcile content section by section.** For each of the 15 sections:
   - Pull in every item the current-state document has, in its wording.
   - Keep the backup's extra items as backfill.
   - Fill any remaining blanks, so nothing is left as a placeholder except the items only a real person can fill (see below).
   - Watch for the recurring decisions captured in `reference.md` and handle them the same way. If the situation is new or has changed, flag it.

4. **Collect the flags as you go.** Track three kinds of items: significant differences that need the user's decision, minor calls you made on your own, and cells that must stay placeholders.

5. **Write the backup in one pass, then report.**

If current-state has no new content since the last reconciliation (the backup already covers everything), do not churn the file. Say so plainly and confirm the backup is already aligned and ready.

## Things that stay as placeholders

Some cells cannot be filled by any document, because they need real people to act. Leave these as clear placeholders and say so in the report:
- The role assignments in the Section 3 table are proposals only.
- Signatures and dates (Section 15).
- Milestone owners (Section 13), left as TBD.

## How to report back

After writing the backup, give the user a short, scannable summary with these groups:
- **Pulled in from current-state:** the team contributions you carried into the backup, so the user can trust nothing was lost.
- **Proposals to confirm:** anything you drafted that needs sign-off, especially the Section 3 role mapping.
- **Decisions that need the user:** the significant differences, each with your suggestion and a clear question.
- **Minor calls you made:** small choices the user can reverse.
- **Still placeholders:** the people-only items above.

End by asking which flagged items to change, and confirm the backup is ready to paste by hand if it is ever needed.

## Writing style (matches the project CLAUDE.md)

- ASCII characters only. No em dashes, en dashes, curly quotes, ellipsis characters, or emojis. Use straight quotes and plain punctuation. Do not use a pair of hyphens as a dash. Use hyphens only for real compound words (for example, "read-only").
- Plain, layman-friendly prose. Short, direct sentences.
- Keep the charter's existing voice and reading level.
