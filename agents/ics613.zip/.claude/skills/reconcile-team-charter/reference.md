# Reconcile Team Charter: project context and decisions

This file holds background and the reconciliation decisions already agreed with the user, so a future run stays consistent with past ones. These are starting points and defaults; the user can override any of them.

## Project context

- Course: ICS 613, Advanced Software Engineering, Summer 2026.
- Team: Team 4. Five members: Kennan Kaneshiro, Shea Stevens, Matt Ong, Kim Cates, and Jeff Wu (the user).
- Project: Local Produce Exchange. An invite-only web app where a trusted community shares surplus food before it goes to waste. Members post listings, others claim a quantity, the claim moves through a lifecycle (REQUESTED, APPROVED, PICKED_UP, COMPLETED, with DENIED and CANCELLED paths), each exchange has a private message thread, and both sides can review after completion. There is a member dashboard and an admin role.
- Stack required by the course: React and TypeScript for the front end; Python with FastAPI, SQLAlchemy, and Pydantic for the backend; PostgreSQL for the database.
- The charter is due in early June 2026. The "11th hour" means just before that deadline.
- This skill is one of three siblings: reconcile-team-charter, reconcile-use-cases, and reconcile-user-stories. All three share the same goal and the same hard rules; only the reconciliation mechanics differ, because the documents differ.

## The 15 charter sections

1. Team Purpose
2. Project Scope and Objectives (Project Vision, Goals, In Scope, Out of Scope)
3. Team Members and Roles
4. Team Values
5. Communication Plan
6. Working Agreements
7. Decision-Making Process
8. Development Workflow
9. Quality Standards
10. Project Artifacts
11. Conflict Resolution and Accountability
12. Risks and Mitigation
13. Milestones and Timeline
14. Team Commitment Statement
15. Signatures

## Role mapping (proposed, built from current-state)

Current-state gave real responsibilities for three people and left two blank. The agreed proposal maps the five members onto lead roles:

- Kennan Kaneshiro: Backend Lead (from his backend, SQL, and connection work).
- Shea Stevens: Database Lead (from her stated database administration).
- Matt Ong: Frontend Lead (proposed; he was blank in current-state).
- Kim Cates: Team Lead and Scrum Master (proposed; she was blank in current-state).
- Jeff Wu: QA and DevOps Lead (from his Docker, Make, and GitHub Actions work).

Notes:
- The template's original framework had a single combined "Backend and Database Lead." It was split into "Backend Lead" and "Database Lead," because current-state clearly puts Kennan on backend and Shea on database. This gives one clean lead per person.
- Matt, Kim, and the Team Lead slot are guesses, since current-state has nothing for Matt or Kim. The user may swap these, and may choose to take Team Lead.
- Keep these as proposals. The section intro says roles get confirmed at the first meeting.

## Recurring reconciliation decisions

- Section 1: an early backup draft said "Team X." Current-state says "Team 4." Use "Team 4."
- Goals and Values can run over the template's suggested counts (Goals 3 to 5, Values 4 to 6) once you keep the current-state items and add the backfill. Keep them all, but flag the count. If the user wants to trim to the range, the suggested cuts are "Process discipline" from Goals and "Build work we can demo" from Values, since both are covered elsewhere.
- In Scope has two current-state items that read more like design notes than user features: a "request queue" and a "database schema as single source of truth." Keep both, since the team wrote them. Flag the request queue, because it may overlap with the over-claim protection already in the claim lifecycle, and ask whether it is meant to be a separate feature.
- Section 8, pull request approvals: current-state floated "two to three approvals?"; the backup uses "at least one." Default to at least one for a five-person class team, and flag it. Offer the options of two approvals, or one normally and two for changes that touch core business rules.
- Section 8, branch name: current-state said "master"; the backup uses "main." Standardize on "main" and note it.
- Section 13 milestones: use the current-state 11-row breakdown. Map the backup's richer notes into the matching rows. Owners stay TBD.
- The June 15 milestone is labeled "Cross-Team Requirements Review Packet" in current-state. The backup note mentions the review being presented June 16. The packet and the report are two related items around that date; keep the team's label and flag if separation is wanted.
- Section 14 commitment statement: current-state keeps the template's formal wording; the backup uses a plainer rewrite that means the same thing. The user approved keeping the plain rewrite. Flag it as a minor item.
- The real GitHub repo link and Google Drive folder link live in current-state's Communication Plan. Always carry them into the backup.

## Communication Plan links (from current-state)

- Code repository: https://github.com/kennank27/ICS613_Summer2026_FinalProject_Team4
- Meeting notes (Google Drive folder): https://drive.google.com/drive/folders/1s7VIsUajSrPqejtY_euqD7INBDaIAaNj?usp=drive_link

## Reminder

These are starting points from earlier sessions. Read both live documents every time. If current-state has changed, the team may have added new content. Preserve all of it, and flag anything new that conflicts with these defaults.
